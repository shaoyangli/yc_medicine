USE [ProjectYJK]
GO

/****** Object:  Table [dbo].[INRUD_baseinfo]    Script Date: 04/16/2015 12:03:59 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[INRUD_baseinfo](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[num] [nvarchar](50) NULL,
	[name] [nvarchar](50) NULL,
	[age] [int] NULL,
	[sex] [nvarchar](10) NULL,
	[weight] [nvarchar](10) NULL,
	[height] [nvarchar](10) NULL,
	[RBC] [nvarchar](20) NULL,
	[TBIL] [nvarchar](20) NULL,
	[ALT] [nvarchar](20) NULL,
	[AST] [nvarchar](20) NULL,
	[flag] [int] NULL,
	[visible] [int] NULL,
	[user_group] [nvarchar](50) NULL,
 CONSTRAINT [PK_INRUD_baseinfo] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO


