#NONMEM TABLE FILES
flagNM<-TRUE

#COPLOT ASPECT
flagLATTICE<-TRUE

#COPLOT if lattice SAME SCALES OR NOT
flagSAME<-TRUE

#CUSTOMIZE
flagCUSTOM<-FALSE

#TIGHTEN UP SPACING AND MARGINS
flagMARGINS<-T
############################ DO NOT MODIFY ################################
#RESERVED

cat("\nFor WFN.nmgo users")
cat("\nIndicate runname (without ext.) then SPECIFIC TABLE")
cat("\nIf only runname, the .fit file will be opened by default\n")
cat("\nExample, Filename [ ]  theoph1 pkcovtable1")
cat("\nExample, Filename [ ]  theoph1\n")

options(warn=-1)
rr<-rn_opt(T,T);rfsp1<-rr[[1]];rfski<-rr[[2]];hd1<- rr[[3]];rm(rr)

#READ FILES. ASK SPLIT VAR
rfsr1 <- rn_dir(rfsr1);rffn1 <- rn_f11("",rffn1)
d<-rn_ddd(rfsr1,rffn1,hd1,rfski,rfsp1);rm(hd1)
####END READ FILES

cat("\n")
rfxy[1] <- rn_h22(d,"for abscissa x",rfxy[1])
rfxy[2] <- rn_h22(d,"for ordinate y",rfxy[2])
rfxy=rfxy[1:2];ixy<-as.integer(rfxy)
rfizs <- rn_h22(d,"for conditioning values",rfizs)
lxx<-names(d)[ixy[1]]
lyy<-names(d)[ixy[2]]

i0 <- readline(paste("\n\nDelete zeros for",lxx,"(y/n)? y "))
if (i0 == "") i0<-"y"
if (i0 == "y") d<-subset(d, d[,ixy[1]] != 0)
i0 <- readline(paste("\nDelete zeros for",lyy,"(y/n)? y "))
if (i0 == "") i0<-"y"
if (i0 == "y") d<-subset(d, d[,ixy[2]] != 0)

i0 <- readline(paste("\n0.Points\n1.Spline\n2.Interpol\n3.y=x\n4.y=0\n5.Points/Interp\n6.y=a + bx\n[",rftr1,"] "))
if (i0 != "") rftr1<-i0

i0 <- readline(paste("\n0.NoTransf\n1.Log(y)\n2.Log(x)\n3.Log(x,y)\n[",rfrp1,"] "))
if (i0 != "") rfrp1<-i0

if (flagCUSTOM) {
i0 <- readline(paste("\nSymbols\n1-25.Symbols\n28. '.'\n33.Differents\n[",rfpo1,"] "))
if (i0 != "") rfpo1<-i0
if (is.integer(as.integer(rfpo1))) {
   px<-as.integer(rfpo1)
   if (px == 28) rfpo1<-"."
   else rfpo1<-as.integer(rfpo1)
   rm(px)
}
i0 <- readline(paste("\nLine Type\n1.Solid\n2.Dashed\n3.Dotted\n[",rfli1,"] "))
if (i0 != "") rfli1<-i0
rfli1<-as.integer(rfli1)
i0 <- readline(paste("\nLine Color\n1.black\n2.red\n3.green\n4.blue\n5.lightblue\n6.purple\n7.yellow\n8.lightgray\n33.Differents\n[",rfco1,"] "))
if (i0 != "") rfco1<-i0
rfco1<-as.integer(rfco1)

i0 <- readline(paste("\nX axix Legend [",lxx,"]\n"))
if (i0 != "") lxx<-i0
i0 <- readline(paste("Y axis Legend [",lyy,"]\n"))
if (i0 != "") lyy<-i0
}
if (!flagCUSTOM) { 
   rfpo1<-1
   rfco1<-2
   rfli1<-1
}

coplot1f <- function() {
    tac<-as.integer(rftr1)
    if (!flagLATTICE) par(mar=c(0,0,0,0),oma=c(0,0,0,0))
    iz<-rn_ints(rfizs);    niz<-length(iz)
    ilg=""; if (rfrp1==1) ilg="y";if (rfrp1==2) ilg="x"; if (rfrp1==3) ilg="xy"

    pan1<-function(u, v, col,pch){
        if (tac!=2) {
           co0="black"
           rfpo1=1
           points(u,v,pch=rfpo1,col=1)
        }  
        if (tac==1) lines(u,v,col=0,panel.smooth(u,v,span=0.5,col.smooth=rfco1))
        if (tac==2) lines(u,v,col=rfco1)
        if (tac==3) abline(0,1,col=rfco1)
        if (tac==4) abline(h=0,col=rfco1)
        if (tac==5) lines(u,v,col=rfco1)
        if ((tac==6) & (ilg == "" | ilg == "xy")) {
               mod<-lm(v~u);a<-coef(mod)[1]; b<-coef(mod)[2]
               mu<-a+b*u; vv<-var(v)               
               abline(a,b,col=rfco1)
               if (FALSE) {
                  vv<-var(v)
                  qlow<-qnorm(.05,mu,sqrt(vv)); qhig<-qnorm(.95,mu,sqrt(vv))
               }
               if (FALSE) {
                  pp=predict.lm(mod,interval=c("confidence"),level=.95)
                  qlow<-pp[,2]; qhig<-pp[,3]
               }
               lines(u,v,col=0,panel.smooth(u,v,span=0.5,col.smooth=Csl))
               if (FALSE) {lines(u,qlow,col=Cqt);lines(u,qhig,col=Cqt)}  
        }
        #text(minx,maxy,unique(z[subscripts]),cex=1,pos=4)
    }#pan1
    ly0 <- subset(d,select=ixy)
    ly0 <- names(subset(ly0,select=-1))
    co2<-1:length(ly0) 
    ly0 <- paste(ly0,"",collapse="+") 

    for (ii in 1:niz) d[,iz[ii]] <- paste(names(d[iz[ii]]),d[,iz[ii]])
    d1<-paste(ly0,"~",lxx,"|",sep="")
    d2<-paste(names(d[iz]),collapse="*")
    dx<-paste(d1,d2,sep="")
    dx<-formula(dx)   

    if (!flagLATTICE) coplot(dx,panel=pan1,xlab=c(lxx,""),ylab=c(lyy,""),show.given=T,data=d)
    
    if (flagLATTICE) {
       r11<-"same"  
       if (!flagSAME) r11<-"free"
       if (ilg=="")   sc1<-list(relation=r11)  
       if (ilg=="y")  sc1<-list(relation=r11,y=list(log=TRUE))
       if (ilg=="x")  sc1<-list(relation=r11,x=list(log=TRUE))
       if (ilg=="xy") sc1<-list(relation=r11,x=list(log=TRUE),y=list(log=TRUE))
      
       cc<-xyplot(dx ,data=d,scales=sc1,
                  xlab=lxx,ylab=lyy,col=1,par.strip.text=list(cex=.75),
                  panel=function(x,y,subscripts) {
                    if (tac!=2) tp1<-c("p")
                    if (tac==1) tp1<-c("p","smooth")
                    if (tac==2) tp1<-c("l")
                    if (tac==5) tp1<-c("p","l")
                    #strip=strip.custom( )
                    try(panel.xyplot(x,y,type=tp1,pch=rfpo1,
                                 col.line=c(rfco1),col=1))             
                    if (tac==3) panel.abline(0,1,col.line=Cid)                                   
                    if (tac==4) panel.abline(h=0,col.line=Cid)
                    if (tac==6) {
                       panel.lmline(x,y,col.line=rfco1)
                       if (length(x)>2) {
                       try(panel.loess(x,y,add=T,col.line=Csl))
                       mod<-lm(y~x);a<-coef(mod)[1];b<-coef(mod)[2]
                       mu<-a+b*x;vv<-var(y)
                       if (FALSE) {qlow<-qnorm(.05,mu,sqrt(vv)); qhig<-qnorm(.95,mu,sqrt(vv))}
                       if (FALSE) {
                          pp=predict.lm(mod,interval=c("confidence"),level=.95)
                          qlow<-pp[,2]; qhig<-pp[,3]
                       } 
                       if (FALSE) {
                         panel.xyplot(x,qlow,type="l",add=T,col.line=Cqt)   
                         panel.xyplot(x,qhig,type="l",add=T,col.line=Cqt)                           
                       }  
                       }

          }  
       } )
       if (!flagMARGINS) print(cc)
       if ( flagMARGINS) print(cc, pos = c(-.01, -.01, 1.01, 1.01))
    }#flagLATTICE
}


if (flagLATTICE)  {
   library(lattice)
   trellis.device(new=F,color=flagCOLOR)
   background=trellis.par.get("background")
   background$col="white"
   trellis.par.set("background",background)
   rm(background)
}


coplot1f()

rm(coplot1f)
rm(i0,ixy,lxx,lyy,ilg)
rm(flagCUSTOM,flagNM,flagSAME,flagMARGINS)
par(mar=c(4.1,3.1,3.1,1.1),oma=c(0,0,0,0))
