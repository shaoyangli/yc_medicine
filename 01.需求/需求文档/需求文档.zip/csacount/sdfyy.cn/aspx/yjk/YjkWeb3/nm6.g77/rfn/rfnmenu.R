
#old<-getwd()
#setwd(rfndir)

if  (!exists("rn_titles",mode="function")) {
    cat("\nFirst use, Initialisation of RfN...\n")
    cat("Location of RfN file (ex : c:/nmvi/run/_rfn or d:/nmvi/wfn/_rfn etc...)\n")
    dir1<-readline("RfN Location ? ")
    dir1<-paste(dir1,"init1.R",sep="/")
    try(source(dir1,prompt.echo=T))
    dir1<-readline("\nRe-enter RfN Location ")
    rfndir<-dir1;rm(dir1);cat("\nIMPORTANT")
    cat("\nIt is recommended to verify the init1.R file for various appropriate settings")
    cat("\nEspecially for WINGS for Nonmem users (Wings default settings)")
    cat("\nTo take modifications into account, you will have to run the init1.R program again\n")
    readline("\nPress key to continue...")
}

repeat {

cat("\nRfN MENU")

p1 <- c("nmPLOT4","nmPLOT1",
"nmID_t_DVPRED","nm_t_DVPRED",
"nmVPC","nmVPC2","nmPDE",
"nmCOMPRES",
"nmCOPLOT","nmCORREL","nmSTATS","nmGRF",
"nmWBS","nmWRT","nmWLLP","nmWSHRK")

i1<-1

affich<-function(ti,its,i1) {
i2<-i1-1+length(its)
p001<-paste(i1:i2,its,sep=".")
p001<-paste(p001,collapse="\n ")
p001<-cat("\n\n",ti,"\n",p001)
i1<-i2+1
cat(p001)
return(i1)
}

p0 <- c("Basic diagnostic plots [DV,PRED,WRES,TIME]",
"PRED vs DV, detailled analysis",
"Individual plots, time vs. DV,PRED,IPRED",
"Time vs. DV,PRED plot � data splitting")
ti<-"BASIC DIAGNOSTIC PLOTS USING ITEMS 'TIME,DV,PRED,WRES'"
i1<-affich(ti,p0,i1);rm(ti,p0)

p0<-c("Visual Predictive Check",
"Visual Predictive Check with confidence intervals on percentiles",
"normalized predictive distribution errors 'npde' ")
ti<-"VALIDATION TOOLS USING SIMULATION, Visual Pred Check etc"
i1<-affich(ti,p0,i1);rm(ti,p0)

p0<-c("Visual comparisons of WRES and [PRED vs DV] from various models")
ti<-"VISUAL COMPARISON TOOLS"
i1<-affich(ti,p0,i1);rm(ti,p0)

p0<-c("Y vs X plots with data splitting",
"Y vs X(s) CORRELATION tests (look for correlations between params and covariates...)",
"STATISTIC utilities, distribution of variables etc...",
"CUSTOMIZED graphics,Y vs X with labels...")
ti<-"VARIOUS PLOTS, STATISTICS"
i1<-affich(ti,p0,i1);rm(ti,p0)

p0<-c("nmbs , Analysis of BOOTSTRAP results",
"nmrt , Analysis of the RANDOMIZATION test results",
"nmllp, LLP, Log Likelihood Profile",
"nmxx , Shrinkage")
ti<-"SPECIFIC WINGS APPLICATIONS"
i1<-affich(ti,p0,i1);rm(ti,p0,i1)

i0 <- readline(paste("\n\nSELECT (0 to quit, 99 to change options) [",rfpp2,"] "))
if (i0 != "") rfpp2<-i0
rfpp2<-as.integer(rfpp2);rm(i0)
if (rfpp2==0) break
if (rfpp2==99) {
 cat("\nMODIFY USER GLOBAL OPTIONS\n") 
 rfnUSER<-rn_sdef("WHO (print user name on graphs)",rfnUSER)
 rfnWHAT<-rn_sdef("WHAT (print which file/runname on graphs)",rfnWHAT)
 if (rfnUSER=="..") rfnUSER<-""
 if (rfnWHAT=="..") rfnWHAT<-""
 #flagLATTICE<-"y"==rn_sdef("Lattice/Treillis graphics (y/n)",flagLATTICE)
 flagID<-"y"==rn_sdef("ID values printed on graphs (y/n)",flagID)
 flagIDLINK<-"y"==rn_sdef("Same ID data linked by dashed line (y/n)",flagIDLINK)
 flagPTS<-"y"==rn_sdef("Draw symbols as 'o' (=n) or '.' (=y) (y/n)",flagPTS)
 i0<-readline("\nMODIFY TYPICAL LINE COLOR AND TYPE OPTIONS (99) [] ") 
 if (i0=="99") {
  cat("\nLine colors\n1.black\n2.red.\n3.green\n4.blue\n5.lightblue\n6.purple\n7.yellow\n8.grey\n")
  Cid<-as.integer(rn_sdef("Identity",Cid))
  Crg<-as.integer(rn_sdef("Regression",Crg))
  Cmd<-as.integer(rn_sdef("Median",Cmd))
  Cqt<-as.integer(rn_sdef("Quantile",Cqt))
  Csl<-as.integer(rn_sdef("Spline",Csl))
  cat("\nLine styles\n1.solid\n2.dashed.\n3.dotted\n4.dashed-dotted\n")
  Lid<-as.integer(rn_sdef("Identity",Lid))
  Lrg<-as.integer(rn_sdef("Regression",Lrg))
  Lmd<-as.integer(rn_sdef("Median",Lmd))
  Lqt<-as.integer(rn_sdef("Quantile",Lqt))
  Lsl<-as.integer(rn_sdef("Spline",Lsl))
 } 
 #cat("\nWings for Nonmem options\n")
 r1<-r2<-0; if (rfnUSER!="") r1<-1;if (rfnWHAT!="") r2<-1; rn_ma1<-r1+r2;rm(r1,r2)
}

pr222<-paste(p1[rfpp2],"R",sep=".");pr222<-paste(rfndir,pr222,sep="/")
rm(p1)
try(source(pr222,prompt.echo=T))
rm(pr222)
#setwd(old)

}   