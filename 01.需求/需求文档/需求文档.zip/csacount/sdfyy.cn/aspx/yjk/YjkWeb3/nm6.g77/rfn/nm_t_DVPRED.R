#NONMEM STYLE TABLE FILES
flagNM<-TRUE

#ID LINES, COLOR PRED IPRED
col.pre="red"
#IPRE LINES NOT DRAWN=DEFAULT
col.ipr=0
#col.ipr="blue"

#SELECT COLOR, LINESTYLE
flagCUSTOM<-FALSE

#ONLY ONE SCREEN=TRUE
flagCOPL<-TRUE

############################ DO NOT MODIFY ################################
#RESERVED

options(warn=-1)
rr<-rn_opt(T,T);rfsp1<-rr[[1]];rfski<-rr[[2]];hd1<- rr[[3]];rm(rr)

#READ FILES. ASK SPLIT VAR
rfsr1 <- rn_dir(rfsr1);rffn1 <- rn_f11("",rffn1)
d<-rn_ddd(rfsr1,rffn1,hd1,rfski,rfsp1);rm(hd1)
####END READ FILES

if (flagDELDV0) d<-rn_zero(d)

ixy<-as.numeric(rfxy)
ixy[1] <- rn_h22(d,"TIME",ixy[1])
ixy[2] <- rn_h22(d,"DV",ixy[2])
ixy[3] <- rn_h22(d,"PRED",ixy[3])
ixy[4]<-0
#ixy[4] <- rn_h22(d,"IPRE",ixy[4])
rfxy<-ixy
ixy<-as.numeric(ixy)
bip <- (ixy[4]>0)

i0 <- readline(paste("\n\n0.No Transf\n1.Log(y)\n2.Log(x)\n3.Log(x,y)\n[",rfrp1,"] "))
if (i0 != "") rfrp1<-i0

if (flagCUSTOM)       {
i0<-readline(paste("\n\nHEADERS for X (time),Y (DV), Y(PRED)\nHEADERS [",rfxy,"] "))
print(paste(1:length(names(d)),names(d),sep='.'))
if (i0 != "") rfxy<-i0
i0<-strsplit(rfxy,split=" ");ixy<-as.integer(i0[[1]])  
}
    
i0 <- readline(paste("\n1.Spline\n5.Points/Interp\n[",rftr1,"] "))
if (i0 != "") rftr1<-i0 

if (!flagCUSTOM) {rfli1<-1; rfco1<-2; rfpo1<-1 }

if (flagCUSTOM)     {
 i0 <- readline(paste("\nLine Type\n1.Solid\n2.Dashed\n3.Dotted\n[",rfli1,"] "))
 if (i0 != "") rfli<-i0; rfli1<-as.integer(rfli1)
 i0 <- readline(paste("\nLine Color\n1.black\n2.red\n3.green\n4.blue\n5.lightblue\n6.purple\n7.yellow\n8.lightgray\n[",rfco1,"] "))
 if (i0 != "") rfco1<-i0
 rfco1<-as.integer(rfco1) 
}
ncs<-length(d)
for (ii in 1:ncs) {d[,ii] <- as.vector(d[,ii]); d[,ii] <- as.double(d[,ii])}
d <- subset(d,!is.na(d[,1]));rm(ncs,ii)

fp1 <- function(res) {
    d <- subset(d,!is.na(d[,1]))  
    par(mar=c(2.4,2.1,1.2,0.2),oma=c(1.1+rn_ma1,1.1,0,0))
    nnn<-length(res[[1]]);ntt<-0 
    for (jj in 1:nnn) {td<-res[[1]][jj][[1]]
                       if (length(td[,1])>0) ntt<-ntt+1}
    rm(td,nnn) 
    if (!flagCOPL) layout( 1 )
    if ( flagCOPL) {
           nc11<-ceiling(sqrt(ntt))
           nr11<-ceiling(ntt/nc11)
           n<-nr11*nc11
           layout( matrix (1:n,nr11,nc11) ) 
    }
    tac<-as.integer(rftr1 )
    if (!flagCUSTOM) {co1<-col.pre;   co4<-col.ipr }
    
    fp<-function(dd,lzi) {
        ilg="";if (rfrp1==1) ilg="y";if (rfrp1==2) ilg="x";if (rfrp1==3) ilg="xy"
        if (F) { maxy<-max(subset(dd,select=-1))
                 miny<-min(subset(dd,setect=-1)) }
        o <-order(dd[,1]);  dd<-dd[o,]
        tt1<-which(names(dd)=="ID"); if ( length(tt1)>0) id1<-(dd$ID)
        if (flagID & !is.na(id1)) po1<-"." 
        #plot(dd[,1],dd[,2], type="n",ylim=c(miny,maxy),xlab="",ylab="",log=ilg)
        plot(dd[,1],dd[,2], type="n",xlab="",ylab="",log=ilg)
        if (flagID & !is.na(id1)) text(dd[,1],dd[,2],as.character(id1),cex=.75)
        if (tac!=2) points(dd[,1],dd[,2],pch=rfpo1)
        if (tac==1) {
           #lines(dd[,1],dd[,3],panel.smooth(x,pred,span=0.5,col=rfco1))
           lines(col=rfco1,lowess(dd[,1],dd[,3]))
           if (bip) lines(col=co4,lowess(dd[,1],dd[,4]))
           }
        if (tac==2 | tac==5 ) {
           lines(dd[,1],dd[,3],col=rfco1,lty=rfli1)
           if (bip) lines(dd[,1],dd[,4],col=co4,lty=rfli1)
        }
        if (tac==3) abline(0,1,col=rfco1,lty=rfli1)
        if (tac==4) abline(h=0,col=rfco1,lty=rfli1)
        if (flagIDLINK & !is.na(id1)) {
              id<-unique(id1)               
              for (jj in 1:length(id)) {
                  di<-subset(dd,dd$ID==id[jj])
                  if ( length(di[,1]) >1) lines(di[,1],di[,2],col=5,lty=3)
              }
        }
        mtext(lzi,side=3,line=.1,cex=.9) 
        mtext(lxx,side=1,line=-.1,outer=T)
        mtext(lyy,side=2,line=-.1,outer=T)    
        rn_titles(rfsr1,rffn1,1,2)
    }
    for (jj in 1:length(res[[1]])) {
      d<-res[[1]][jj][[1]]
      lzn<-res[[2]] ; lzi<-"" 
      if (lzn!="") lzi<-paste(lzn,res[[3]][jj],sep=".")    
      if (length(d[,1])==0) next 
      lxx = names(d)[ixy[1]]
      lyy = names(d)[ixy[2]]
      sel1<-ixy; tt1<-which(names(d)=="ID")
      if ( length(tt1)>0) sel1<-c(ixy,tt1[1])
      fp(subset(d,select=sel1),lzi)
      if (!flagCOPL) {
         cd<-rn_savenm("nmtDVPRED","GRAPH",rfsr1,rffn1[1],as.character(jj),"pdf")
         pdf(cd,onefile=T)
         t_DVPRED(res)
         dev.off()
         readline(paste("Press ENTER for next plot"))
      }
    }#jj
}

cat("\nData splitting ?")
rfizs<-rn_h22(d,"variable for data splitting (0 if none)",rfizs)
res<-rn_zi123(d,rfizs)
fp1(res)
if (flagCOPL) {
 cd<-rn_savenm("nmtDVPRED","GRAPH",rfsr1,rffn1[1],"","pdf")
 pdf(cd,onefile=T)
 fp1(res)
 dev.off()
}
rm(fp1,i0,ixy,bip,res,cd)
rm(flagCOPL,flagNM,flagCUSTOM)
rm(col.pre,col.ipr)
par(mar=c(4.1,3.1,3.1,1.1),oma=c(0,0,0,0))


