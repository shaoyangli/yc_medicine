
#ASK FOR X HEADER
flagASKx<-FALSE

#LINE.COLORS QT-QT,GAUSS,ZEROLINE 
#LCLR<-    c("red"   ,"red",   "red")
#LCLR<-    c("red"   ,"blue",   "red")
#LCLR<-    c("black"   ,"black",   "black")

############################### DO NOT MODIFY ################################
#RESERVED
cat("\nMETRICS FOR MODEL EVALUATION\nPREDICTION DISTRIBUTION ERRORS")
cat("\nBrendel et al. Pharm Res 23:2036-49, 2006\n")
cat("\nIn collaboration with Inserm U738, Emmanuelle Comets, Karl Brendel & France Mentr�")

cat("\nThe program requires the SIMULATION file PLUS the file with ORIGINAL DV")
cat("\nIDV or TIME, DV, ID, MDV  header indices will be required\n")
cat("\nOriginal data file = NONMEM file created by $TABLE containing original DV\n")

cat("\nThe computation can be time-consuming...")
cat("\nTo follow the process, Click on the R window\n\n")

options(warn=-1)
rr<-rn_opt(T,T);rfsp1<-rr[[1]];rfski<-rr[[2]];hd1<- rr[[3]];rm(rr)

#READ FILES. ASK SPLIT VAR
rfsr1 <- rn_dir(rfsr1)

rffn1[2] <- rn_f11("SIMULATION DATA FILE",rffn1[2])
ds<-rn_ddd(rfsr1,rffn1[2],hd1[2],rfski[2],rfsp1)
cat("SIMULATION Table Header for x\n")
if (!flagASKx) cat("TIME is selected by default\n")
if ( flagASKx) rfxy[1] <- rn_h22(ds,"X or TIME",rfxy[1])
if (!flagASKx) rfxy[1] <- rn_h22(ds,"TIME",rfxy[1])
rfxy[2] <- rn_h22(ds,"DV",rfxy[2])
rfxy[3] <- rn_h22(ds,"ID",rfxy[3])
ixy<-as.integer(rfxy)

rffn1[1] <- rn_f11("\nOBSERVATION DATA FILE",rffn1[1])
 da<-rn_ddd(rfsr1,rffn1[1],hd1[1],rfski[1],rfsp1)
 cat("OBSERVATION Table Header for x\n")
 if (!flagASKx) cat("TIME is selected by default\n")
 if ( flagASKx) ix <- rn_h22(da,"X or TIME",ix)
 if (!flagASKx) ix <- rn_h22(da,names(ds[ixy[1]]),ix)
 iy<-rn_h22(da,"DV",iy)
 ids<-rn_h22(da,"ID",ids)
 ix<-as.integer(ix); iy<-as.integer(iy)
####END READ FILES

if (T) {
   ncs<-length(ds)
   for (ii in 1:ncs) {
       ds[,ii] <- as.vector(ds[,ii])
       ds[,ii] <- as.double(ds[,ii])
   }
   ds <- subset(ds,!is.na(ds[,1]))  
} 
       
if (flagDELDV0) ds <-rn_zero(ds)
if (flagDELDV0) da<-rn_zero(da)


#*******************************************************************
fp1<-function () {

po1<-20; if (!flagPTS) po1=1; ilg="" 

fp<-function(x,y,xl,yl,tr1,sl1,id1) {
        nn<-length(y);co1<-Crg
        if (tr1<10) plot(x,y, type="n",xlab="",ylab="",log=ilg)
        if (tr1==4) {
           if (!is.na(id1)) text(x,y,as.character(id1),cex=.75)
           else points(x,y,pch=po1)
           #co1<-LCLR[3]; abline(h=sl1,col=co1,lty=2)
           abline(h=sl1,col=co1,lty=Lrg)
           title(xlab=xl,ylab=yl,line=2.1)
        }
        if (tr1==11) {
           df<-data.frame(x,y)
           boxplot(y~x,data=df,xlab="",ylab="",main="")
           abline(h=0.5,lty=Lrg);title(xlab=xl,ylab=yl,line=2.1)
        }
}

plot4<-function(x,npde,ypred,id1) {
     par(mfrow=c(2,2),mar=c(3.5,3.5,1,1),oma=c(0,0,0,0))
     #layout(matrix(1:4,2,2))
     po1<-20; if (!flagPTS) po1=1; ilg="" ;co1<-Csl
     #co1<-LCLR[1]
     nn<-length(npde)
     qqnorm(sort(npde),main="",xlab="",ylab="")
     qqline(sort(npde),col=co1)
     title(xlab="Sample Quantiles",ylab="Theoretical Quantiles",line=2.1,cex=.9)

     co1<-Csl #co1<-LCLR[2]
     xx<-seq(min(npde),max(npde),le=100);yy<-dnorm(xx,0,1)
     hist(npde,nclass=10,proba=T,main="",xlab="",ylab="")
     #hist(npde,nclass=10,proba=T,main="",xlab="",ylab="",ylim=c(0,max(yy)*1.1))
     lines(xx,yy,col=co1)
     title(xlab="npde",ylab="frequency",line=2.1)
     co1<-Cid #co1<-LCLR[3]
     plot(x,npde, type="n",xlab="",ylab="",log=ilg)
     if (!is.na(id1)) text(x,npde,as.character(id1),cex=.75)
     else points(x,npde,pch=po1)
 
     abline(h=0,col=co1,lty=2)
     title(xlab=names(da[ix]),ylab="npde",line=2.1)   
     #co1<-LCLR[3]
     plot(ypred,npde, type="n",xlab="",ylab="",log=ilg)
     if (!is.na(id1)) text(ypred,npde,as.character(id1),cex=.75)
     else points(ypred,npde,pch=po1)
     abline(h=0,col=co1,lty=2)
     title(xlab="PRED",ylab="npde",line=2.1)   
}
        
plot21<-function(x,npde,ypred,li,id1) {
     if (li[1]=="") par(mfrow=c(2,1),mar=c(3.5,3.5,1,1),oma=c(0,0,0,0))
     if (li[1]!="") par(mfrow=c(2,2),mar=c(3.5,3.5,1,1),oma=c(0,0,0,0))
     po1<-20; if (!flagPTS) po1=1; ilg="" 
     nn<-length(npde);co1<-Cid #co1<-LCLR[1]
     qqnorm(sort(npde),main="",xlab="",ylab="")
     qqline(sort(npde),col=co1)
     title(xlab="Sample Quantiles",ylab="Theoretical Quantiles",line=2.1,cex=.9)
     co1<-Csl #co1<-LCLR[2]
     xx<-seq(min(npde),max(npde),le=100);yy<-dnorm(xx,0,1)
     hist(npde,nclass=10,proba=T,main="",xlab="",ylab="")
     #hist(npde,nclass=10,proba=T,main="",xlab="",ylab="",ylim=c(0,max(yy)))
     lines(xx,yy,col=co1)
     title(xlab="npde",ylab="frequency",line=2.1)
     if (li[1]!="") {
        plot(0,0, type="n",xlab="",ylab="", axes=F)
        for (ii in 11:17) mtext(li[ii],side=3,line=8-ii,adj=0,family="mono",cex=.75) 
        plot(0,0, type="n",xlab="",ylab="", axes=F)
        for (ii in 1:2) mtext(li[ii],side=3,line=-ii,adj=0,family="mono",cex=.75) 
        for (ii in 3:5) mtext(li[ii],side=3,line=-2-ii,adj=0,family="mono",cex=.75) 
        for (ii in 6:9) mtext(li[ii],side=3,line=-3-ii,adj=0,family="mono",cex=.75) 
     }
}

plot22<-function(x,npde,ypred,id1) {
     par(mfrow=c(2,1),mar=c(3.5,3.5,1,1),oma=c(0,0,0,0))
     plot(x,npde, type="n",xlab="",ylab="",log=ilg)
     if (!is.na(id1)) text(x,npde,as.character(id1),cex=.75)
     else points(x,npde,pch=po1)
     co1<-Cid; abline(h=0,col=co1,lty=2)
     title(xlab=names(da[ix]),ylab="npde",line=2.1)   
     plot(ypred,npde, type="n",xlab="",ylab="",log=ilg)
     if (!is.na(id1)) text(ypred,npde,as.character(id1),cex=.75)
     else points(ypred,npde,pch=po1)
     #co1<-LCLR[3]; abline(h=0,col=co1,lty=2)
     abline(h=0,col=co1,lty=2)
     title(xlab="PRED",ylab="npde",line=2.1)   
}


fnp<-function() {

   calcnpde<-function(jj,msuj,matsim,nrep){
       ypred<-apply(matsim,1,mean)
       varsim<-cov(t(matsim))
       moysim<-apply(matsim,1,mean)
       #V-1/2 Cholevsky
       xerr<-0
       xmat<-try(chol(varsim))
       if (is.numeric(xmat)){
          ymat<-try(solve(xmat))
          if (!is.numeric(ymat)) 
              xerr<-2
          } else 
            xerr<-1
       if (xerr==0) {
          #DECORRL SIMS
          decsim<-t(ymat)%*%(matsim-moysim)
          decobs<-t(ymat)%*%(msuj$y-moysim)
          ydsim<-c(decsim)
          #DECORRL OBS
          ydobs<-decobs
          #COMPUTE THE PDE
          tcomp<-apply(decsim,2,"<",decobs)
          bb<-is.matrix(tcomp)
          if ( bb) ycal<-apply(tcomp,1,mean)
          if (!bb) ycal<-mean(tcomp)
          ycal[ycal==0]<-1/nrep
          ycal[ycal==1]<-1-1/nrep
          pde<-ycal
       }
       return(list(xerr,pde,ydsim,ydobs,ypred))    
   }

    ptm<-proc.time()
    bWRES<-(T | length(which(names(da)=="WRES"))>0)
    xobs<-da[,as.integer(ix)]
    yobs<-da[,as.integer(iy)]
    id  <-da[,as.integer(ids)]
    nobs<-length(yobs)
    tabo<-data.frame(ID=id,x=xobs,y=yobs)
    xsim <-ds[,ixy[1]]
    ysim <-ds[,ixy[2]]
    idsim<-ds[,ixy[3]]
    nrep<-length(ysim)/nobs
    irsim<-rep(1:nrep,each=nobs) 
    tabs<-data.frame(ID=idsim,x=xsim,y=ysim,ir=irsim)
    rm(xobs,yobs,id,xsim,ysim,idsim,irsim)
    
    #COMPUTE npde
    bb<-unique(tabo$ID) ; id1<-bb
    nid<-length(unique(tabo$ID))
    nobs<-dim(tabo)[1]
    nrep<-dim(tabs)[1]/nobs
    ypred<-ydobs<-pde<-tabo$y
    ydsim<-tabs$y
    #COMPUTE PDE 
    for (jj in bb){   #FOR EACH ID
        cat("\n.Computing... ID",jj,"of",nid)
        msuj<-tabo[tabo$ID==jj,]
        matsim<-matrix(tabs$y[tabs$ID==jj],ncol=nrep)
        x<-calcnpde(jj,msuj,matsim,nrep)
        xerr<-x[[1]];pde[tabo$ID==jj]<-x[[2]]
        ydsim[tabs$ID==jj]<-x[[3]];ydobs[tabo$ID==jj]<-x[[4]]
        ypred[tabo$ID==jj]<-x[[5]]      
        if (xerr>0) {
           cat("\n\nERROR",xerr)
           if (xerr==1) cat("\nCholesky decomposition of the cov. matrix of sim. data has failed")
           if (xerr==2) cat("\nInversion of cov. matrix of sim. data has failed")
           cat("\nThe covariance matrix is not positive definite")
           cat("\nprobably because the simulations are significantly different from observations")
           cat("\nCheck the model by using a 'visual predictive check'")
           stop("ERROR")
        }
    } 
    cat("\n\nCPU TIME",(proc.time()-ptm)[1]/60,"min\n\n")
    idv<-names(da[ix])
    npde<-qnorm(pde)

po1<-46; if (!flagPTS) po1=1;if (!flagID) id1<-NA 
#if (!flagID) points(x,y,col=1,pch=po1)
#if (flagID & !is.na(id1)) text(x,y,as.character(id1),cex=.75)
  
    plot4(tabo$x,npde,ypred,id1)
    cd<-rn_savenm("nmPDE","GRAPH4",rfsr1,rffn1[2],"","pdf")
    pdf(cd, onefile=T)
    plot4(tabo$x,npde,ypred,id1)
    dev.off()

#PREDICT.TABLE
   dw<-cbind(tabo,npde=npde,Y.PRED=ypred)
   cd<-rn_savenm("nmPDE","DATA",rfsr1,rffn1[2],"","txt")
   write.table(dw,file=,cd,sep="\t",row.names=F)
  
   rr<-numeric(4)     
   tt<-wilcox.test(npde);   rr[1]<-tt$p.val
   tt<-shapiro.test(npde);  rr[3]<-tt$p.val
   semp<-sd(npde)
   n1<-length(npde)
   chi<-(semp**2)*(n1-1)
   tt<-2*min(pchisq(chi,n1-1),1-pchisq(chi,n1-1)); rr[2]<-tt
   xcal<-3*min(rr[1:3]);    rr[4]<-min(1,xcal)   
   li0<-character()    
   li0[1]<-sprintf("\n\n%-16s, %s","Observation file",rffn1[1])
   li0[2]<-sprintf("\n%-16s, %s","Simulation file",rffn1[2])
   names(rr)<-c("Wilcoxon signed rank test","Fisher variance test",
                "SW test of normality","Global adjusted p-value")
   li0[3]<-sprintf("\n\n%-14s%s\n","Data, N.obs","Sim., N.rep")
   li0[4]<-"--------------------------\n"
   li0[5]<-sprintf("%-14g%g\n",nobs,nrep)
   li0[6]<-"\nDistribution of npde\n"
   li0[7]<-"--------------------------\n"
   li0[8]<-sprintf("%-10s = %.3g\n","mean",mean(npde))
   li0[9]<-sprintf("%-10s = %.3g\n","variance",var(npde))
   li0[10]<-"--------------------------\n"
   li0[11]<-"\n\nStatistical tests\n"
   li0[12]<-"---------------------------------\n"
   for (ii in 1:4) li0[12+ii]<-sprintf("%-25s: %.3g\n",names(rr[ii]),rr[ii])
   li0[17]<-"---------------------------------\n"
   cat(li0)

   readline("Next...")
   plot21(tabo$x,npde,ypred,"",id1) 
   readline("Next...")
   plot22(tabo$x,npde,ypred,id1) 
   cd<-rn_savenm("nmPDE","GRAPH2HQ",rfsr1,rffn1[2],"","pdf")
   pdf(cd, onefile=T)
   plot21(tabo$x,npde,ypred,li0,id1)
   dev.off()
   cd<-rn_savenm("nmPDE","GRAPH2xy",rfsr1,rffn1[2],"","pdf")
   pdf(cd, onefile=T)
   plot22(tabo$x,npde,ypred,id1)
   dev.off()  
   if (bWRES) {
       readline("Next...")
       layout(matrix(1:2,1,2))
       fp(tabo$x,npde,idv,"npde",4,0,id1)
       fp(da[,ix],da$WRES,idv,"WRES",4,0,id1)
   }
   readline("Next...")
   layout(matrix(1:1,1,1))
   fp(tabo$x,npde,idv,"npde",4,0,id1)
   readline("Next...")
   fp(ypred,npde,"PRED","npde",4,0,id1) #x,y
}
fnp()
}
fp1()

par(mar=c(4.1,3.1,3.1,1.1),oma=c(0,0,0,0))
rm(fp1,ixy,ds,da,flagASKx)

