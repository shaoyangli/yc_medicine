rm(list=ls())

#USER DEFINED GLOBAL VARIABLES #CHECK THESE 

#LOCATION OF RfN SCRIPTS
rfndir <- "/nmvi/run/_rfn"

#WHO (user) & WHEN 
#ADDS THE USER NAME AND DAY TIME TO THE PLOTS IF STATED
#rfnUSER <- "Saik Urien"
rfnUSER <- ""

#WHAT 
#ADDS THE DATA FILE NAME IF NOT EMPTY : ex. rfnWHAT <-"File "
rfnWHAT <- "File "
rfnWHAT <- ""

#ID IDENTIFIED BY ITS VALUE NUMBER
flagID<-FALSE

#LGHTBLUE DASHED LINE IS DRAWN BETWEEN SAME ID DATA
flagIDLINK<-TRUE

#LATTICE/TRELLIS COLOR Y or N, USEFULL FOR PUBLICATION
flagCOLOR<-FALSE

#NONMEM TABLE FILES, DUPLICATE ROWS REDUCED TO ONE OCCURENCE
flagUNI<-TRUE

#DELETE ZERO DV VALUES, MDV=1 ROWS DELETED (OR IF NOT PRESENT, DV=0 ROWS DELETED)
flagDELDV0<-TRUE


################### DEFAULT WINGS OPTIONS *** MODIFY IF NECESSARY
#NMCTL
wfnCTL<-"ctl" 

#NMTBL
wfnTBL<-"fit"

#NMDIR
#wfnDIR<-"df"
#wfnDIR<-"std"
wfnDIR<-"g77"


#################### DEFAULT RfN OPTIONS  *** MODIFY IF NECESSARY

# the optFLIST option :

#LISTING ALL FILENAMES OR WfN RUNNAMES OR USER-DEFINED FILE NAMES
#UNCOMMENT OR COMMENT '#' LINES OR WRITE AN optFLIST<-"something" line
#   INDICATE A SPECIFIC PATTERN OF THE FILES TO BE LISTED

#      WfN USERS
optFLIST<-paste(".",wfnDIR,sep="")   #WfN USERS


#      OTHER USERS
#optFLIST<-""     #ALL FILES
#optFLIST<-".txt" #FILES WITH .txt


#FOR nmPLOT4, nmPLOT1
#OPTION: DV(ordinate)   vs. PRED(abscissa)  T
#OPTION: PRED(ordinate) vs. DV(abcsissa)    F
flagDVPRED<-FALSE

#DRAWING OF SYMBOLS  T=.  F=o, DEFAULT=F
#IF TOO MANY POINTS, PREFER T
flagPTS<-FALSE


#ASK FOR SPLITTING THE DATA ACCORDING TO A CATEGORICAL VARIABLE
flagSPLIT<-FALSE

#VPCs, CHANGE SMOOTH FUNCTION IN CASE OF DRAWING PROBLEM
#lowess=1, loess=2, smooth.spline=3
flagSMOOTH<-1

#VPCs, INCREASE THE SMOOTHING FOR SIMULATED DATA (1 = same, >1 more smoothing)
factSIM <- 1


#RESERVED ####### DO NOT MODIFY ###########################################
#LATTICE GRAPHICS DRAWS TRELLIS S+ TYPE PLOTS IF TRUE FOR SOME PROGRAMS
#DEFAULT=FALSE
#flagLATTICE<-FALSE

#COLOR LINES : IDENTITY, REGRESSION, QT, CI, SPLINE, 0= NO LINE
Cid<-1 #black
Crg<-2 #red
Cmd<-2
Cqt<-4 #"blue"  "lightblue"
Csd<-"darkolivegreen"
Csl<-4 #"blue"
#LINES TYPES: 1=solid, 2=dashed, 3=dotted
Lid<-1
Lrg<-1
Lmd<-1
Lqt<-2
Lsd<-2
Lsl<-1

rfpp2<-1
rfsr1<-""
rffn1<-""
rfsp1<-""
rfski<-1
rfco1<-"1"
rfli1<-"1"
rfpo1<-"1"
rfrp1<-"1"
rftr1<-"1"
rfpr2<-"1"
rfids<-"0"
rfizs<-"0"
rfigs<-"0"
rfxy<-c("1","2")
rfy<-"2"
rfx<-"1"
rfn1<-c(1,1)
rflx<-"0"
rfly<-"0"
rfqt<-c(.05,.5,.95)
rfBOOT<-30
rf_pn1<-""
rfSMOOTH=.5

#RESERVED ####### DO NOT MODIFY ###########################################

rn_dir <- function(sr1) {
 cd1 <- getwd()
 cat("\nWorking directory",cd1,"\n")
 i0 <- readline(paste("\nPath (c:/../..) or Relative dir. [",sr1,"] "))
 if (i0 != "") sr1 <- i0
 tst1 <- length(grep(":",sr1))>0
 if (!tst1) sr01<-sr1
 if (tst1 ) {sr01<-paste(sr1,sep="/"); cdd<-sr01}
 if (i0 == "..") sr01<-getwd()    
 if (i0 == "..") cdd<-paste(cd1,sep="/") else if (!tst1) cdd<-paste(cd1,sr01,sep="/")

 bw<-length(grep(wfnDIR,optFLIST))>0
 if (!bw) cat("\nFiles found in directory",cdd,"\n")
 if ( bw) cat("\nWfN folders found in directory",cdd,"\n")
 print(dir(cdd,pattern=optFLIST))
 cat("\n")
 return(sr01)
}

rn_dir2 <- function(sr1,bb) {
 sr01<-rn_dir(sr1)
 cdd<-paste(getwd(),sr01,sep="/")
 cat("\nWfN folders '*.bs' found in directory",cdd,"\n")
 print(dir(cdd,pattern="bs"))
 cat("\n")
 return(sr01)
}

rn_f11<-function(nm1,f12) {
      if (nm1 != "") cat(nm1,"\n")
      i0 <- readline(paste("Filename/Runname ? [",f12,"] "))
      if (i0 != "") f12<-i0
      return(f12)
}
rn_sdef<-function(txt1,def) {
      if (is.logical(def)) {if (def) def<-"y" else def<-"n" }
      i0 <- readline(paste(txt1," [",def,"] ",sep=""))
      if (i0 != "") def<-i0
      return(def)
}


rn_h22<- function(d,nm1,ix) {
    tt1<-which(names(d)==nm1)
    if ( length(tt1)==0) 
    { #cat("\n\n") 
      print(paste(1:length(names(d)),names(d),sep='.'))
      i0<-readline(paste("Header number, ",nm1,"[",ix,"] "))
      if (i0 != "") ix<-i0
      tt1<-ix
      if (is.na(tt1)) tt1 <-0
    }
    return(tt1)
}

#NONMEM TABLES=FALSE
rn_opt <- function(flagnm,flag1hd) {
 if (!flagnm) {
   i0 <- readline(paste("\nField separator (' '='..',';','\t')? [",sep1,"] "))
   if (i0 != "") sep1<-i0
   if (i0 == "..") sep1<-""
   if (i0 == " ") sep1<-""
   i0 <- readline(paste("Skip line(s) ? [",ski1,"] "))
   if (i0 != "") ski1<-i0
   if (ski1 != "") ski1<-as.integer(ski1)
 }
 if (flagnm) {
   sep1<-""
   ski1<-c(1,1)
   if (!flag1hd) ski1<-c(1,0)
 }
 hd1<-c(T,T)
 if (!flag1hd) hd1<-c(1,0)
 return(list(sep1,ski1,hd1))
}



rn_cd1<-function( sr1,fn1 ) {
   cd<-fn1 
   cd<-paste(sr1,fn1,sep="/")
   return(cd) 
}

rn_cd2<-function( sr1,fn1,fn2 ) {
      cd3<-paste(fn1,wfnDIR,sep=".")
      cd4<-paste(fn1,wfnTBL,sep=".")
      if (!is.na(fn2)) cd4<-paste(fn2)
      cat("\nWFN option[",wfnDIR,wfnTBL,wfnCTL,"] Try opening",cd3,cd4," files ...")
      cd<-paste(sr1,cd3,cd4,sep="/")          
      return(cd) 
}


rn_fty<-function(sr1, fn1,fn2 ) {
      vv<-0
      if (vv==0) {
        cd3<-paste(fn1,wfnCTL,sep=".")
        if (file.exists(cd3)) vv<-2 
        if (vv==0) {if (file.exists(fn1)) vv<-1}
        if (vv==0) {
          cd3<-paste(fn1,wfnDIR,sep=".")
          if (file.exists(cd3)) vv<-2 
          if (vv==0) {
             cd3<-paste(fn1,wfnDIR,sep=".")
             if (!is.na(fn2)) {cd4<-paste(cd3,fn2,sep="/")
                               if (file.exists(cd4)) vv<-3
             } 
          }   
        }
      }
      if (vv==0) {
         cat("\n\nERROR\n\nFiles in the selected directory\n") 
         print(dir(sr1,full.names=TRUE))
         stop("\n\nFILE NOT FOUND: ",fn1,fn2,"\n\n") 
      }
      return(vv)
}

rn_ddd <- function(sr1,fn1,hd1,ski1,sep1) {
    fn2<-character(2)
    fn2<-strsplit(fn1,split=" ")
    fn2<-fn2[[1]]
    fn1<-fn2[1]
    cd<-rn_cd1(sr1,fn1)
    vv<-rn_fty(sr1,cd,fn2[2])
    if (vv==1) cat("\nOpen file",cd,"\n")
    if (vv==1) da<-try(read.table(cd,header=hd1,skip=ski1,sep=sep1,fill=T),silent=T)
    if (vv> 1) {
      flagWFN<-T
      cd<-rn_cd2(sr1,fn1,fn2[2])
      cat("\nOpen file",cd,"\n")
      da<-try(read.table(cd,header=hd1,skip=ski1,fill=T),silent=T)
    }
    if (!is.data.frame(da)) {
       stop("\nError in data frame creation\n\n")
    }
    return(da)
}


#DELETE ITEM=0
rn_zero <- function(d) {
       ds<-d
       tt1<-which(names(d)=="MDV")
       lg <- length(tt1)
       if (lg>0) d <- subset(d,d$MDV == 0)
       if (lg==0) { 
          tt1<-which(names(d)=="WRES")
          lg <- length(tt1)
          if (lg>0) d <- subset(d,d$WRES != 0)
          if (lg==0) {
             tt1<-which(names(d)=="DV")
             lg <- length(tt1)
             if (lg>0) d <- subset(d,d$DV != 0) 
          }
          if (lg==0) cat("\nWARNING:\nNo WRES, MDV or DV item is present in the table\n")
       }
       if (lg>0) cat("\n\nDeletion of rows containing MDV=1 values\n\n")
       if (length(d[,1])==0) {d<-ds; cat("\nNo row deletion or the table is empty\n")} 
       return(d)
}     

#GET SPLITTING HEADERS VECTOR iz
rn_izs<-function(d,ttt,izs) {
    if (ttt=="") ttt<-"Header nb."
    print(paste(1:length(names(d)),names(d),sep='.'))
    i0<-readline(paste(ttt," [",izs,"] ",collapse=" "))
    if (i0 != "") izs<-i0
    return(izs)
}

 
#rn_ a vector of int from a character with ints sep by spaces or :     
rn_ints<-function(i0) {
 if (i0 != "") izs<-i0
 if (i0 == "0") iz<-0
 if (i0 != "0") {
    i0<-strsplit(izs,split="-")
    if (length(i0[[1]])<2) i0<-strsplit(izs,split=":")
    if (length(i0[[1]])>1) {
       i0<-as.integer(i0[[1]])
       n1<-as.integer(i0[1])
       n2<-as.integer(i0[2])
       iz<-n1:n2
       rm(n1,n2)
    } else
    { 
       i0<-strsplit(izs,split=" ")
       iz<-as.integer(i0[[1]])
    }
 }
return(iz)
}

#FUNCTIONS FOR DATA SPLITTING LIST INDEX AFTER A VECTOR iz
rn_zi123<-function(d,izs) {
 ntt<-1; lzz<-""; lzi <- NULL
 izs<-paste(as.character(izs),collapse=" ") 
 iz<-strsplit(izs,split=" ")
 iz<-as.integer(iz[[1]])
 niz<- length(unique(iz)); bb<-(niz > 0) & (iz>0)
 ex<-list(niz)
 dd<-list(d)
 if (bb) {
   for (ii in 1:niz) {
       lz0 = names(d)[iz[ii]]
       ww0<-unique(d[,iz[ii]])
       #cat("\nCondition[",ii,"] is",lz0,"Values",ww0)
       ntk<-length(ww0)
       #cat("\n",lz0,"Nb. of modalities",ntk)
       ntt<-ntt*ntk
       lzz<-paste(lzz,lz0,sep=".")#lzz<-c(lzz,lz0) 
       ex[ii]<-list(d[,iz[ii]])
   }
   #cat("\n","Total nb. of modalities",ntt,"\n\n")
   dd<-split(d,ex)
   lzi<-names(dd)
 }
 return(list(dd,lzz,lzi)) 
}

rn_smooth0<-function(typ1,t11,x,y) {
       if (typ1==1) res<-lowess(x,y,f=t11)
       if (typ1==2) res<-loess(y~x,span=t11)
       if (typ1==3) res<-smooth.spline(x,y, spar=t11)
       if (is.character(res)) 
          stop("\n**************************************\nSmoothing of OBS impossible, use nmVPC\n**************************************\n\n") 
       return(res)
}

rn_smooth1<-function(typ1,t11,x,y,co1,li1,pt1,lw1) {
    res<-fsmooth0(typ1,t11,x,y)
    lines(res, col=co1,lty=li1,pch=pt1,lwd=lw1)         
    return(res)
}

rn_ma1<-sum(rfnUSER != "")
rn_ma1<-rn_ma1+sum(rfnWHAT != "")

rn_titles<-function(sr1,fn1,nf1,li1) {
     tt<-"";ti1<-"";ti2<-"";ti3<-""
     if (rfnUSER!="") {ti1<-sprintf("%s, %s",rfnUSER,date()); tt<-ti1}
     if (rfnWHAT!="") {
        sr0<-getwd()
        fn12<-strsplit(fn1,split=" ")
        fn11<-fn12[[1]][1]
        bWFN <- file.exists(paste(paste(sr1,fn11,sep="/"),wfnDIR,sep="."))
        sr2<-sr1; 
        if (bWFN) sr2<-paste(paste(sr1,fn11,sep="/"),wfnDIR,sep=".")
        bb<-(fn1[1]=="" | fn1[1]=="NA" | fn1[1]=="..") 
        if (!bb) ti2<-sprintf("%s %s/%s/%s",rfnWHAT,sr0,sr2,fn1[1])
        if (!bb) tt<-sprintf("%s\n%s",tt,ti2) 
        if (nf1>1) {
            bb<-(fn1[2]=="" | fn1[2]=="NA" | fn1[2]=="..") 
            if (!bb) ti3<-sprintf("%s %s/%s/%s",rfnWHAT,sr0,sr2,fn1[2])
            if (!bb) tt<-sprintf("%s\n%s",tt,ti3)    
        }
     }
     mtext(tt,cex=.7,side=1,outer=T,line=li1)
}


#SAVING DATA FIGURES, GET FULL FILE NAMES
rn_savenm<-function(pr,DATGRF,sr1,fn0,nm1,ext) {
         fn12<-strsplit(fn0,split=" ")
         fn1<-fn12[[1]][1]
         bWFN <- file.exists(paste(paste(sr1,fn1,sep="/"),wfnDIR,sep="."))
         sr2<-sr1; 
         if (bWFN) sr2<-paste(paste(sr1,fn1,sep="/"),wfnDIR,sep=".")
         if (pr=="nmWBS") sr2<-paste(paste(sr1,fn1,sep="/"),"bs",sep=".")
         cd<-paste(sr2,sprintf("%s_%s_%s.%s",DATGRF,nm1,pr,ext),sep="/")
         cat("\n*** ",DATGRF," saved in file",cd,"***\n") 
         return(cd)
}         

cat("\nINITIALISATION OF THE R WORKSPACE FOR RfN\n")
cat("\nThe following variables and functions are reserved names\n")
print(ls())
if (rfnUSER!="") cat("\nThe following user name (+date time) will be added to the graphs\n",rfnUSER,"\n")
if (rfnWHAT!="") cat("\nThe file(s) name(s) will be added to the graphs\n")

cat("\nUser defined location of RfN scripts is ",rfndir,"\n(this option allows the use of rfnmenu)\n")

cat("\nThe following WfN default extensions are")
cat(sprintf("\n%-8s : for control stream files",wfnCTL))
cat(sprintf("\n%-8s : for NONMEM table files",wfnTBL))
cat(sprintf("\n%-8s : for the run directory",wfnDIR))
cat(sprintf("\n\nFiles with the pattern *** %s *** will be listed by the programs\n",optFLIST))
cat("\n\nFor any query regarding RfN")
cat("\nSa�k Urien\nURC Hopital Tarnier\nF75006 Paris\nsaik.urien@svp.aphp.fr\n")

#readline("\nPress ENTER to run 'rfnmenu'\n")
#try(source(paste(rfndir,"rfnmenu.R",sep="/"),prompt.echo=T))
cat("\nYou can access all of the programs by the rfnmenu.R script\nProvided you indicated the path in init1.R\n")
#END.RESERVED



