############################### DO NOT MODIFY ################################
#RESERVED
flagWFN<-TRUE
flagLATTICE<-F
#END.RESERVED


#2 FILE NAMES.FNS FOR WFN.nmrt
cd1<-getwd()
cat("\nWorking directory",cd1,"\n")
cat("\nIndicate the path to the directory containg the .bs directory")
cat("\nPath (c:/../..) or Relative dir.")
i0 <- readline(paste("\n[",rfsr1,"] "))
if (i0 != "") rfsr1<-i0

cat("\nIndicate the WFN randomization test runname followed by COV name")
cat("\nNo file extension. EXAMPLE : theopdsex2 sex")
i0 <- readline(paste("\nRunname COV? [",rffn1,"]\n"))
if (i0 != "") rffn1<-i0
i0<-strsplit(rffn1,split=" ")
fns<-as.character(i0[[1]])

if (flagWFN) { rfsp1<-"";rfski<-0 }

tst1<-length(grep(":",rfsr1))>0
if (!tst1) sr01<-rfsr1
if (tst1 ) sr01<-paste(rfsr1,sep="/")
cd3<-paste(fns[1],".rt_",fns[2],sep="")
cd4<-paste(fns[1],"txt",sep=".")
cat("\nWFN OPTION, Try opening",cd3,cd4," files ...\n")
cd<-paste(sr01,cd3,cd4,sep="/")    
cat("\nOpen file",cd,"\n\n")
d<-try(read.table(cd,header=T,skip=rfski,sep=rfsp1,comment.char="",fill=T),silent=T)
rm(cd1,cd3,cd4,tst1,sr01,fns,hd1)

fp1 <- function(rfids,rfizs,rftr1) {

d<-subset(d,select=c(Obj,Min,Cov))
tot<-length(d[,1])
d1<-logical(tot)

    sok<-sprintf("\n%-10s%-10s%s\n","Total","Cov.OK.0","Min.SUCCESSFUL")
    nok<-length(d$Cov[d$Cov=="OK"])
    if (nok==0) sok<-sprintf("%s%-10i%-10i%i\n",sok,tot,length(d$Cov[d$Cov=="NONE"]),length(d$Min[d$Min=="MINIMIZATION_SUCCESSFUL_"]))
    if (nok> 0) sok<-sprintf("%s%-10i%-10i%i\n",sok,tot,length(d$Cov[d$Cov=="OK"]),  length(d$Min[d$Min=="MINIMIZATION_SUCCESSFUL_"]))
    infx<-"n";    supx<-"n";    rp1<-0;    po<-1;    tr0<-0

    gr1 <- function(X,z01) {
        nx<-length(X);  rx<-X[X>z01]; p <- length(rx)/nx
        lxx<-"delta.Obj" ; lyy<-"probability" ; lti<-"Null Distribution"
        dxx<-(max(X)-min(X)) ; zx1<-z01/dxx  
        if (zx1<.2) zx1<-.5
        zx1<-(0+zx1)*dxx/2 + min(X)
        cat(sprintf("\n\ndOBJ = %.4g\np =%.4g",z01,p))
        r<-hist(X,proba=T,xlab="",ylab="",main="")
        arrows(zx1,0.6*max(r$density),z01,min(r$density),col="red")
        #text(zx1,0.7*max(r$density), sprintf("p =%.4g",p), adj=c(.5, -.5), col='red')
        #legend(zx1,0.7*max(r$density), sprintf("d.OBJ = %.4g\np =%.4g",z01,p),xjust =.5,yjust=.5,text.col=2)
        if (p>.005) legend(zx1,0.7*max(r$density), sprintf("dOBJ = %.4g\np =%.6g",z01,p),adj = c(0,.25),text.col=2)
        if (p<.005) legend(0.6*max(X),0.7*max(r$density), sprintf("dOBJ = %.4g\np =%f",z01,p),adj = c(0,.25),text.col=2)
        mtext(lxx,side=1,line=2); mtext(lyy,side=2,line=2); mtext(lti,side=3,line=-1)  
        text(r$mids, r$density, r$counts, adj=c(.5, -.5), col=4)       
        #mtext(lxx,side=2,line=0,outer=T)
    }#gr1

    out1 <- function(id,d1,z00,z01) {
      for (ii in 1:length(id)) {
          X<-z00 - d1[,id]
          X<-sort(X, decreasing=T )
          #if (del0 == "y") X<-X[X != 0]
          if (infx != "n") X<-X[X > infx]
          if (supx != "n") X<-X[X < supx]
          nm<-names(d[id[ii]])
          gr1(X,z01)  
      }#ii loop
      cat("\n\nN =",length(X)," / total permutations =",tot,"\n") 
    }#out1           

    q1<-T
    repeat {
      rfids<-1; id<-1 
      if (rfids == "0") break
      dm<-as.character(unique(d$Min))
      ii<-length(dm);      s1<-0;      sdm<-as.character(d$Min)
      if (ii>10) {
         cat("\nMinimization types for analysis are too numerous",ii)
         cat("\nTypes will be limited to")
         cat("\nMINIMIZATION_TERMINATED")
         cat("\nMINIMIZATION_SUCCESSFUL\n")
         s1<-nchar("MINIMIZATION_TERMINATED")
         dm<-substr(dm, 1, s1)
         d$Min<-substr(d$Min, 1, s1)
      }
      
      cat(sok); cat(sprintf("\n%-6s%-6s%s","Ref.","N","Response"))     
      for (ii in 1:length(dm)) {
          d0<-length(d$Min[d$Min==dm[ii]]) 
          cat(sprintf("\n%-6i%-6i%s",ii,d0,dm[ii]))
      }

      #del0 <- readline(paste("\nDelete zeros (y/n)? y "))
      #if (del0 == "") del0<-"y"
      iz0 <- readline(paste("\n\nAnswer 0 to STOP\nSelect Minimization types for analysis (all=999)\n[",rfizs,"] "))
      if (iz0 == "0") break
      if (iz0 != "") rfizs<-iz0
      if (iz0 == "999") {
         rfizs<-""
         for (ii in 1:length(dm)) rfizs<-paste(rfizs,as.character(ii))
      }
      i0<-strsplit(rfizs,split=" ")
      i0<-as.integer(i0[[1]]) 
      d1<-FALSE 
      for (ii in 1:length(i0)) {
          d1<-(d1 | d$Min==dm[i0[ii]])
      }

      d<-cbind(d,TEST=d1)
      d1<-subset(d,d$TEST,select=-c(Cov,Min))
      if (q1) {z00<-max(d1$Obj) ; q1<-FALSE;  z01<-4  }  
      i0 <- readline(paste("\nOBJ value from the NULL model\n[",z00,"] "))
      if (i0 != "") z00<-as.numeric(i0) 
      i0 <- readline(paste("\nDELTA.OBJ between NULL and ALTERNATE models\n[",z01,"] "))
      if (i0 != "") z01<-as.numeric(i0) 

      par(mar=c(3.5,2.5,1.1,.1),oma=c(0,1.5,.1,.1))
      layout( 1 ); out1(id,d1,z00,z01)
      d$Min<-sdm;  rm(sdm)  
      d<-subset(d,select=c(-TEST)) 
    }#repeat

    par(mar=c(4.1,4.1,3.1,1.1),oma=c(0,0,0,0))
    return(list(rfids,rfizs,rftr1))
}

rps<-fp1(rfids,rfizs,rftr1)
rfids<-rps[[1]];rfizs<-rps[[2]];rftr1<-rps[[3]]

rm(fp1,rps,flagWFN)

