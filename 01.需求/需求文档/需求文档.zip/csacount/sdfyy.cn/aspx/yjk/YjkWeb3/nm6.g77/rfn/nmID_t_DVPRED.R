#nmID_t_DVPRED

#COPLOT if LATTICE same scales or not
flagSAME<-FALSE

#ID LINES, COLOR PRED IPRED
col.pre="red"
col.ipr="blue"
#IPRED NOT DRAWN:
#col.ipr=0 

#SELECT COLOR, LINESTYLE, LABELS
flagCUSTOM<-FALSE

#TIGHTEN UP SPACING AND MARGINS
flagMARGINS<-TRUE

############################ DO NOT MODIFY ################################
#RESERVED
flagNM<-TRUE

options(warn=-1)
rr<-rn_opt(T,T);rfsp1<-rr[[1]];rfski<-rr[[2]];hd1<- rr[[3]];rm(rr)

#READ FILES. ASK SPLIT VAR
rfsr1 <- rn_dir(rfsr1);rffn1 <- rn_f11("",rffn1)
d<-rn_ddd(rfsr1,rffn1,hd1,rfski,rfsp1);rm(hd1)
####END READ FILES
if (TRUE) d<-rn_zero(d);

rfids <- rn_h22(d,"ID",rfids)
ixy<-as.numeric(rfxy)
ixy[1] <- rn_h22(d,"TIME",ixy[1])
ixy[2] <- rn_h22(d,"DV",ixy[2])
ixy[3] <- rn_h22(d,"PRED",ixy[3])
ixy[4] <- rn_h22(d,"IPRE",ixy[4])
rfxy<-ixy
ixy<-as.numeric(ixy)
bip <- (ixy[4]>0)
bb<-unique(d[,as.integer(rfids[1])])
nid<-length(bb)

rfizs <- rn_h22(d,"for SPLITTING variables",rfizs)
#COPLOT ASPECT, if flagLATTICE=TRUE, plots are 1 ID in 1 screen for all factors
# write on R prompt >flagLATTICE<-FALSE
# or                >flagLATTICE<-TRUE
flagLATTICE<-FALSE
flagLATTICE <- (strsplit(rfizs,split=" ")[[1]][1]!="0") 
#flagLATTICE<-FALSE

i0 <- readline(paste("\n0.NoTransf\n1.Log(y)\n2.Log(x)\n3.Log(x,y)\n[",rfrp1,"] "))
if (i0 != "") rfrp1<-i0
if (!flagCUSTOM) {rfli1<-1; rfco1<-2; rfpo1<-1}

if (flagCUSTOM) {
 i0 <- readline(paste("\nDelete zeros for Y (y/n)? y "))
 if (i0 == "") i0<-"y"
 if (i0=="y") d<-subset(d, d[,ixy[2]] != 0)
 i0 <- readline(paste("Delete zeros for X (y/n)? n "))
 if (i0 == "") i0<-"n"
 if (i0=="y") d<-subset(d, d[,ixy[1]] != 0)
 i0 <- readline(paste("\n1.Spline\n5.Points/Interp\n[",rftr1,"] "))
 if (i0 != "") rftr1<-i0
 i0 <- readline(paste("\nSymbols\n1-25.Symbols\n28. '.'\n33.Differents\n[",rfpo1,"] "))
 if (i0 != "") rfpo1<-i0
 if (is.integer(as.integer(rfpo1))) {
   px<-as.integer(rfpo1)
   if (px == 28) rfpo1<-"."
   else rfpo1<-as.integer(rfpo1)
 }
 i0 <- readline(paste("\nLine Type\n1.Solid\n2.Dashed\n3.Dotted\n[",li1,"] "))
 if (i0 != "") li1<-i0
 li1<-as.integer(li1)
 i0 <- readline(paste("\nLine Color\n1.black\n2.red\n3.green\n4.blue\n5.lightblue\n6.purple\n7.yellow\n8.lightgray\n33.Differents\n[",rfco1,"] "))
 if (i0 != "") rfco1<-i0
 rfco1<-as.integer(rfco1)
}

if (!flagLATTICE) {
 n1<-as.integer(rfn1[1]); n2<-as.integer(rfn1[2])
 cat("\nNumber of plots [Total=",nid,"]") 
 i0 <- readline(paste("\n - per page [",n1,"] "))
 if (i0 != "") n1<-as.integer(i0)
 n2<-ceiling(sqrt(n1))
 if (n2==0) n2<-1
 i0 <- readline(paste(" - per row  [",n2,"] "))
 if (i0 != "") n2<-i0
 rfn1<-as.integer(c(n1,n2))
 rm(n1,n2,i0)
}
cat("\n")

if (!flagCUSTOM) {
  lxx = names(d)[ixy[1]]
  if (!bip) lyy = sprintf("*%s ___%s(%s)",names(d[ixy[2]]),names(d[ixy[3]]),col.pre)
  if (bip) lyy = sprintf("*%s ___%s(%s) ___%s(%s)",names(d[ixy[2]]),names(d[ixy[3]]),col.pre,names(d[ixy[4]]),col.ipr)
  rftr1<-"5" ; rfco1<-col.pre
}



fp1<-function() {

    tac<-as.integer(rftr1);co4<-col.ipr     
    ilg=""; if (rfrp1==1) ilg="y"; if (rfrp1==2) ilg="x"; if (rfrp1==3) ilg="xy"
    nc11<-rfn1[2]
    if (rfn1[1]>nid) rfn1[1]<-nid
    nr11<-ceiling(rfn1[1]/nc11)
    if (nc11*nr11<rfn1[1]) nr11<-nr11+1
    nn<-nc11*nr11

fp11 <- function(d,lzi,lx1,ly1) {
    id1<-as.integer(rfids[1]);
    lzi<-paste(lzi,names(d),sep=".")
    d<-d[[1]]; bb<-unique(d[,id1]);idm = length(bb)
    layout( matrix (1:nn,nr11,nc11) )
    fp<-function(dd, ii, ig) {
        maxy<-max(subset(dd,select=-1))
        miny<-min(subset(dd,select=-1)); bMIN1<-FALSE; bMIN2<-FALSE
        if (ilg=="y" & miny<=0) {
            bMIN1<-TRUE 
            d3<-dd[,3]; y0<-which(d3<=0)# t dv pred ipre(bip)
            miny<-min(d3[d3>0])/10; dd[y0,3]<-miny; rm(d3)
            #cat("\nsome PRED values are <= 0, they are replaced by ",miny)  
            if (bip) { bMIN2<-TRUE; d3<-dd[,4]; y00<-which(d3<=0)
                       miy<-min(d3[d3>0])/10 ; dd[y00,4]<-miy 
                       #cat("\nsome IPRED values are <= 0, they are replaced by ",miy)  
                       miny<-min(miny,miy); rm(d3)}
        }
        o <-order(dd[,1]); dd<-dd[o,] 
        if (ilg=="") plot(dd[,1],dd[,2], type="n",ylim=c(miny,maxy),xlab="",ylab="",log=ilg)
        if (ilg!="") plot(dd[,1],dd[,2], type="n",ylim=c(miny,maxy),xlab="",ylab="",log=ilg)
        if (length(dd[,1])==1) points(dd[,1],dd[,3],col=2)
        if (bip & length(dd[,1])==1) points(dd[,1],dd[,4],col=4)
        if (tac==1) {
           #lines(dd[,1],dd[,3],panel.smooth(x,pred,span=0.5,col=rfco1),lty=rfli1)
           lines(col=rfco1,lowess(dd[,1],dd[,3]),lty=rfli1)
           if (bip) lines(col=co4,lowess(dd[,1],dd[,4]),lty=rfli1)
        }
        if (tac==5 | tac==2) {
           lines(dd[,1],dd[,3],col=rfco1,lty=rfli1)
           if (bip) lines(dd[,1],dd[,4],col=co4,lty=rfli1)
        }
        if (tac==3) abline(0,1,col=rfco1,lty=rfli1)
        if (tac==4) abline(h=0,col=rfco1,lty=rfli1)
        if (bMIN1) points(dd[,1],dd[,3],col=rfco1,bg=rfco1) 
        if (bMIN2) points(dd[,1],dd[,4],col=co4,bg=co4) 
        points(dd[,1],dd[,2],pch=rfpo1,col=1)
        mtext(side=3,paste("ID",ii),cex=.75,adj=0,line=.1)
    }  
    ii0=1
    layout( matrix (1:nn,nr11,nc11) )
    par(mar=c(3,3,.5,.5),oma=c(1+rn_ma1*1.1,1,.5,.5))
    fgk<-function(bb1) {
        for (kk in 1:nid) {
            if (kk > idm) break
            dk<-subset(d,d[,id1] == bb[kk], select=ixy)
            #if (length(dk[,1])==0) plot(0,0,type="n",xlab="",ylab="")
            if (length(dk[,1])>0)  fp(dk, bb[kk],ig)       
            if (!flagCUSTOM) {lx1<-paste(lxx,"[",lzi,"]");ly1<-paste(lyy)}
            mtext(lx1,side=1,line=-.5,outer=T)
            mtext(ly1,side=2,line=-.5,outer=T)
            rn_titles(rfsr1,rffn1,1,1.85)
            if (kk >= nn*ii0) #if (kk < nid & kk >= nn*ii0) 
            { #if (bb1!="pdf") cat("\n")
              if (bb1!="pdf") cc<-readline(paste("Next... "))
              ii0<-ii0+1
             }
      }#loop KK id
    }
    fgk("0")
    cd<-rn_savenm("nmIDtDVPRED","GRAPH",rfsr1,rffn1,lzi,"pdf")
    pdf(cd, onefile=TRUE)
    layout( matrix (1:nn,nr11,nc11) )
    par(mar=c(3,3,.5,.5),oma=c(1+rn_ma1*1.1,1,.5,.5))
    fgk("pdf")
    rn_titles(rfsr1,rffn1,1,1.85)
    dev.off()
    cat("\nSome PRED and/or IPRED values can be <= 0\nThey are replaced by 1/10 of non-zero min value") 
    cat("\nThe corresponding points are indicated\nin the same color as the PRED or IPRED line") 
    cc<-readline(paste("\n\nNext sorting condition... "))
    par(mar=c(4.1,3.1,3.1,1.1),oma=c(0,0,0,0))
}


if (!flagLATTICE) {
 res<-rn_zi123(d,rfizs)
 for (jj in 1:length(res[[1]])) {
      if (flagCUSTOM) {
        if (sum(ls()=="lxx")==0) lxx<-names(d)[ixy[1]]
        if (sum(ls()=="lyy")==0) lyy<-names(d)[ixy[2]]
        i0 <- readline(paste("\nX axix Legend [",lxx,"]\n"))
        if (i0 != "") lxx<-i0
        i0 <- readline(paste("Y axis Legend [",lyy,"]\n"))
        if (i0 != "") lyy<-i0
      }
      fp11(res[[1]][jj],res[[2]],lxx,lyy)
 }
 rm(res,jj,nc11,nr11,nn)
}
if (flagLATTICE) {
       bMIN1<-TRUE 
       cat("\nO are OBS\nA are PRED\n+ are IPRED\n\n")
       library(lattice)
       trellis.device(new=F)
       background=trellis.par.get("background")
       background$col="white"
       trellis.par.set("background",background)
       rm(background)
       iz<-rn_ints(rfizs)
       for (kk in 1:nid) {
          dd<-subset(d, d$ID==bb[kk],select=c(ixy,iz))
          xx<-dd[,1]
          nx<-length(xx)             
          if (nx==0) next             
          yy<-dd[,2]
          y2<-dd[,3]
          y3<-rep(0,nx)
          if (bip) y3<-dd[,4]
          di  <-c(dd[,1],dd[,1],dd[,1]) 
          ixy2<-1:length(ixy)
          dzz <-subset(dd,select=-ixy2) 
          diz<-rbind(dzz,dzz,dzz)
          g<-factor(rep(c("DV","PRED","IPRE"),each=nx ))
          d2<-data.frame(x=c(xx,xx,xx),y=c(yy,y2,y3),GRP=g,diz)     
          iz2<-(4:(length(iz)+3))
          lz1<-paste(names(d2[iz2]),collapse="*")
          f11<-formula(paste("y ~ x",lz1,sep="|"))
          r11<-"same"  
          if (!flagSAME) r11<-"free"
          if (ilg=="")   sc1<-list(relation=r11)  
          if (ilg=="y")  sc1<-list(relation=r11,y=list(log=TRUE))
          if (ilg=="x")  sc1<-list(relation=r11,sc1,x=list(log=TRUE))
          if (ilg=="xy") sc1<-list(relation=r11,sc1,x=list(log=TRUE),y=list(log=TRUE))
          lx<-paste("( ID",bb[kk],")   ",lxx) 
          cols<-c(0,rfco1,co4)
          cc<-xyplot(f11,data=d2,groups=GRP,scales=sc1,par.strip.text=list(cex=.75),
                   strip=strip.custom(strip.levels=c(T,T)),
                   panel=panel.superpose.2,
                   type=c("p","b","b"),             
                   pch=c(1,2,3),
                   col.line=c(0,rfco1,co4),
                   #key=list(columns=2,line=0,
                   #         text=list(as.character(unique(g))),col=c("red","blue"),line=-1),
                   xlab=lx,ylab=lyy,col=1)                   
        if (!flagMARGINS) print(cc)
        if ( flagMARGINS) print(cc, pos = c(-0.01, -0.01, 1.01, 1.01))
       cc<-readline(paste("ID Next? (y/n) y "))
       if (cc=="") cc<-"y"
       if (cc!="y") break
    }#kk.ID loop   
}#LATTICE TRUE
}

fp1()
rm(fp1,bip,bb,nid)
rm(flagNM,flagCUSTOM,flagSAME)
rm(col.pre,col.ipr)


