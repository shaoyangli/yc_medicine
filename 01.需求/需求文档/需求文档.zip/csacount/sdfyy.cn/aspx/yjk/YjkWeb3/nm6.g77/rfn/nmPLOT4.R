
#Retransform LOG values to NATURAL values (DV,PRED,RES,IPRE,IRES)
#NAT LOGS (Ln(e)=1)
flagLtoN  <-FALSE
#LOG10 (log(10)=1)
flagL10toN<-FALSE

############################ DO NOT MODIFY ################################
#RESERVED

options(warn=-1)
rr<-rn_opt(T,T);rfsp1<-rr[[1]];rfski<-rr[[2]];hd1<- rr[[3]];rm(rr)

#READ FILES. ASK SPLIT VAR
rfsr1 <- rn_dir(rfsr1);rffn1 <- rn_f11("",rffn1)
d<-rn_ddd(rfsr1,rffn1,hd1,rfski,rfsp1);rm(hd1)
####END READ FILES

rfxy[1] <- rn_h22(d,"TIME",rfxy[1])
rfxy[2] <- rn_h22(d,"DV",rfxy[2])
if (TRUE) d<-rn_zero(d)
rfigs<-rn_h22(d,"variable for data splitting (0 if none)",rfigs)


fp1<-function() {

dplot4 <- function(d,lzi,bQU) {

    fp<-function(x, y, id1, xl,yl, slope) {
        po1<-46; if (!flagPTS) po1=1;if (flagID & !is.na(id1)) po1<-"." 
        plot(x,y,xlab="",ylab="",pch=po1)
        if (flagID & !is.na(id1)) text(x,y,as.character(id1),cex=.75)
        title(xlab=xl,ylab=yl,line=2)
        abline(0,slope,col=Cid)
        if (flagIDLINK & !is.na(id1)) for (ii in 2:length(x)) 
           if (d$ID[ii]==d$ID[ii-1]) segments(x[ii-1],y[ii-1],x[ii],y[ii],col=5,lty=2)
        mod<-lm(y~x);a<-coef(mod)[1];b<-coef(mod)[2]; vv<-var(y)
        if (FALSE) { 
           q.05<-qnorm(.05,a+b*x,sqrt(vv));q.95<-qnorm(.95,a+b*x,sqrt(vv))
           lines(x,q.05,col=Cqt,lty=2);lines(x,q.95,col=Cqt,lty=2)
        }
        #if (flagSPL) lines(x,y,panel.smooth(x,y,span=0.5,col=Csl))
        lines(col=Csl,lowess(x,y))
        if (!is.na(a) & !is.na(b)) abline(mod,col=Crg,lty=Lrg)
        ss<-sprintf("\ny= %.3g + %.3g*x   r %.3g   N %i\n",a,b,cor(x, y),length(x) )
        title(ss,cex.main=0.75,font.main=1,adj=0)
    }

    pp1<-function(i, vv,pred) {
        it<-c("BIAS","VARIAB.","PRECIS.")
        pc=c("( )","(%)")
        cat(sprintf("\nN = %d, FILE: %s",length(vv),rffn1))
        cat(sprintf("\n%-16s%-10s%-10s%-10s%-10s%s\n","Item","Mean","SD","Median","Min","Max"))
        #cat(sprintf("\n%-16s%-10s%-10s%-10s%-10s%s\n",ni,"Mean","SD","Median","Min","Max"))
        for (hh in 1:1) {
        for (ii in 1:3) {
            if (hh==2) vv=vv/pred
            if (ii==2) vv=abs(vv)
            if (ii==3) vv=vv*vv
            mm<-mean(vv); ss<-sd(vv); md<-median(vv); mi<-min(vv); ma<-max(vv)
            cat(sprintf("%-10s%-6s%-10.3g%-10.3g%-10.3g%-10.3g%.3g\n",it[ii],pc[hh],mm,ss,md,mi,ma))
        }
        } 
    }
    ppwre<-function(v) {
           n1<-length(v[v< -2])
           n2<-length(v[v>  2])
           n0<-length(v)
           cat(sprintf("\n%-16s%-10s%-10s%s\n","WRES"," <-2","[-2,+2]",">+2"))
           cat(sprintf("%-16s%-10i%-10i %i\n","N",n1,n0-n1-n2,n2))
           cat(sprintf("%-16s%-10.3g%-10.3g%.3g\n","%",n1/n0*100,100*(n0-n1-n2)/n0,100*n2/n0))
    }
    par(mar=c(3.1,3.1,1.5,1.),oma=c(rn_ma1,0,1,0))
    ti1<-as.integer(rfxy[1]);ti2<-as.integer(rfxy[2])
    lzi<-paste(lzi,names(d),sep=".")
    d<-d[[1]]
    if (length(d[,1])>1) { 
      layout(matrix(1:4,2,2))  
      if (bQU) cat(sprintf("\n\n%-16s %-16s\n","BIAS","mean(OBS - PRED)"))
      if (bQU) cat(sprintf("%-16s %-16s\n","VARIABILITY","mean|OBS - PRED|"))
      if (bQU) cat(sprintf("%-16s %-16s\n","PRECISION","SquareRoot(mean(OBS - PRED))"))
      if (flagL10toN) {
         d[,ti2]<-10**d[,ti2]   
         d$PRED<-10**d$PRED ; d$RES <-10**d$RES   
      }
      if (flagLtoN) {
         d[,ti2]  <-exp(d[,ti2])
         d$PRED<-exp(d$PRED) ; d$RES <-exp(d$RES) 
      }
      p1<-which(names(d)=="PRED")
      u1<-ti2;v1<-p1; if (flagDVPRED) {u1<-p1;v1<-ti2}
      vv<-d[,u1]-d[,v1]
      id1<-NA; tt1<-which(names(d)=="ID"); if ( length(tt1)>0) id1<-d$ID
      fp(d[,u1],d[,v1],id1,names(d[u1]),names(d[v1]),1)    
rn_titles(rfsr1,rffn1,1,.5)                
      if (bQU) pp1(0,vv,d[,v1])  
      fp(d$PRED,d$RES,id1, "PRED","RES", 0)
      fp(d$PRED,d$WRES,id1,  "PRED","WRES", 0)
      if (bQU) ppwre(d$WRES)    
      fp(d[,ti1],d$WRES,id1, "TIME","WRES", 0)
      mtext(side=3,outer=T,lzi)     
      p2<-which(names(d)=="IPRE")
      if (length(p2)>0) {
         q1<-"y" 
         if (bQU) q1 <- readline(paste("\n","See IPRED... plots (y/n) [y] "))
         if (q1 == "y" | q1 == "") {
           if (flagL10toN) {d$IPRE<-10**d$IPRE;d$IRES<-10**d$IRES }
           if (flagLtoN) {d$IPRE<-exp(d$IPRE);d$IRES<-exp(d$IRES) } 
           u2<-ti2;v2<-p2
           if (flagDVPRED) {u2<-p2;v2<-ti2}
           vv<-d[,u2]-d[,v2]
           fp(d[,u2],d[,v2],id1,names(d[u2]),names(d[v2]), 1)    
           if (bQU) cat("\n\n","BIAS, VARIABILITY, PRECISION on IPREDs","\n")
           if (bQU) pp1(0,vv,d[,v2])  
           if (length(d$IRES)==0) plot(0,0,type="n")
            else fp(d$IPRE,d$IRES,id1, "IPRE","IRES", 0)
           if (length(d$IWRE)==0) plot(0,0,type="n")
            else fp(d$IPRE,d$IWRE,id1, "IPRED","IWRES", 0)
           if (length(d$IWRE)==0) plot(0,0,type="n")
            else fp(d[,ti1],d$IWRE,id1, "TIME","IWRES", 0)
           mtext(side=3,outer=T,lzi)     
rn_titles(rfsr1,rffn1,1,.5)                
         }
      }
  }
  if (bQU) readline("Next condition...")
}

res<-rn_zi123(d,rfigs)
for (jj in 1:length(res[[1]])) {
    dplot4(res[[1]][jj],res[[2]],TRUE)
    cd<-rn_savenm("nmPLOT4","GRAPH",rfsr1,rffn1[1],as.character(jj),"pdf")
    pdf(cd, onefile=TRUE)
    dplot4(res[[1]][jj],res[[2]],FALSE)
    dev.off()
}
}
fp1()

rm(fp1,ti1,ti2)
rm(flagLtoN,flagL10toN)
par(mar=c(4.1,3.1,3.1,1.1),oma=c(0,0,0,0))

