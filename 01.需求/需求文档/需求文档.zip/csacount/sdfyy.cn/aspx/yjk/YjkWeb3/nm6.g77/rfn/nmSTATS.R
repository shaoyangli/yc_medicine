#NONMEM TABLE FILES
flagNM<-T

############################ DO NOT MODIFY ################################
#RESERVED
flagLATTICE<-F

cat("\nFor WFN.nmgo users")
cat("\nIndicate runname (without ext.) then SPECIFIC TABLE")
cat("\nIf only runname, the .fit file will be opened by default\n")
cat("\nExample, Filename [ ]  theoph1 pkcovtable1")
cat("\nExample, Filename [ ]  theoph1\n")

cat("\nThe TABLE data is reduced to 1 UNIQUE occurence of each specific data row")
cat("\ni.e, duplicate rows are deleted")
cat("\nTo disable this, turn the flagUNI to FALSE\n")

options(warn=-1)
rr<-rn_opt(T,T);rfsp1<-rr[[1]];rfski<-rr[[2]];hd1<- rr[[3]];rm(rr)

#READ FILES. ASK SPLIT VAR
rfsr1 <- rn_dir(rfsr1);rffn1 <- rn_f11("",rffn1)
d<-rn_ddd(rfsr1,rffn1,hd1,rfski,rfsp1);rm(hd1)
####END READ FILES


if (flagDELDV0) d<-rn_zero(d)
if (flagUNI) d<-unique(d)

i0 <- "\nDESCRIPTIVE STATISTICS\n1.DISTRIBUTION"
i0 <- paste(i0,"\n\nCONTINGENCY TABLE\n5.Analysis")
i0 <- paste(i0,"\n\nREGRESSION TESTS\n21.MULTIPLE REGRESSION\n22.LOGISTIC REGRESSION\n26.TREE REGRESSION")
i0 <- paste(i0,"\n\nCOMPARISON TESTS\n31.KRUSKAL-WALLIS TEST\n32.ANOVA\n35.ANOVA, REPEATED MEASURES\n[")
i0 <- readline(paste(i0,rfpr2,"] "))
if (i0 != "") rfpr2<-i0
pac<-as.integer(rfpr2)
if (pac==35) cat("\nThe 'nlme' library must be installed\n")

cat("\n")
print(paste(1:length(names(d)),names(d),sep='.'))
if (pac>10) {
 if (pac<30) cat("\nHEADER number for Y (DV)\n")
 i0 <- readline(paste("VARIABLE HEADER [",rfy,"] "))
 if (i0 != "") rfy<-i0
 rfy<-as.integer(rfy)
}

if (pac<30) cat("\nHEADER number for X variable(s)\n")
if (pac>30) cat("\nHEADER number for FACTOR variable(s)\n")
i0 <- readline(paste("HEADERS [",rfigs,"] "))
if (i0!="") rfigs<-i0
ig<-rn_ints(rfigs)
if (pac==35) {
 cat("\nHEADER number for REPEATED measures\n")
 i0 <- readline(paste("HEADERS [",rfids,"] "))
 if (i0!="") rfids<-i0
 id1<-rn_ints(rfids)
}

if (pac<10 ) d<-subset(d,select=c(ig) )
if (pac>10 & pac!=35) d<-subset(d,select=c(rfy,ig) )
if (pac==35 ) d<-subset(d,select=c(rfy,ig,id1) )
nig<-length(ig)+1; ig<-2:nig ; ly0<-names(d[1]); rm(id1)
if (pac>10 & pac<30) for (i0 in 1:nig) d<-subset(d,!is.na(d[,i0])) 

i0<-"n"
if ( (pac>10) & (length(ig)>1) ) i0<-readline("\nTest INTERACTION ? (y/n) [ n ] ")
bINTER<-(i0=="y")

i0 <- "\n1.Histogram\n2.Histogram-Smooth\n3.Hist/Normal\n5.normal quantile-quantile plot\n21.Boxplots\n22.Dotcharts\n["
#if (pac>10 & pac<30) cat("\nHEADER number for X variable(s)\n")
if (pac<10 | pac>30) {i0 <- readline(paste(i0,rftr1,"] "));if (i0 != "") rftr1<-i0}
  

fp1 <- function () {

tac<-as.integer(rftr1)
po1<-1; rp1<-0 ; li1<-1 ; co1<-2 ; cat("\n")

#DELETE SOME 0 VALUES
for (ii in 1:length(d)) {
    i0<-"n" ; 
    if (sum(d[,ii]==0)>0) i0<-readline(paste(names(d[ii]),", Delete 0 values y/n? [n] "))
    if (i0=="y") d<-subset(d,d[,ii]>0) 
}
cat("\n"); rm(ii,i0)

#determine if continuous (0) or BINARY (n.classes) data
flook<-function(d) {
  nr1<-length(d[,1]) 
  z<-numeric(length(d))
  for (ii in 1:length(d)) {
    nu1<-length(unique(d[,ii])); 
    bCONT <- (nu1 > 7) & (nu1/nr1 > 0.5)
    z[ii]<-0; if (!bCONT) z[ii]<-nu1
  }
  return (z)
} 


#REGRESS.FIX BINARY or CONTINUOUS + CORR or CHISQ between columns
fscreen1<-function(d) {
  z<-flook(d)
  nr1<-length(d[,1]) 
  for (ii in 1:length(z)) {
    if (z[ii]>0) {
     i0<-readline(sprintf("%-12s is categorical data. Confirm (y/n) [y] ",names(d[ii])))
     if (i0!="" & i0!="y") z[ii]<-0
    }
  }
  layout( matrix (1:1,1,1) )
  plot(d)
  if (sum(z==0)>1) {
   readline("\nCorrelation between continuous variables")
   par(mar=c(4.5,4.9,1.5,0.5),oma=c(0,0,0,0))
   layout( matrix (1:1,1,1) )
   dd<-subset(d,select=which(z==0))
   cat("\nCorrelation matrix [N=",nr1,"]\n")     
   plot(dd)
   cc<-try(cor(dd))
   try(print(cc,digits=3))
  }
  if (sum(z>0)>1) {
   readline("\nRelationships between categorical variables\nPress ENTER to go on...")
   dd<-subset(d,select=which(z!=0))
   plot(dd)
   cat("\nChi-squared test\n")
   cat(sprintf("%-10s%-10s%-10s%s\n","X-squared","df","p.value","Data"))
   for (ii in 1:(length(dd)-1)) for (jj in (ii+1):(length(dd))) {
     cc<-chisq.test(dd[,ii],dd[,jj])
     nw<-sprintf("%s vs %s",names(dd[ii]),names(dd[jj]))
     cat(sprintf("%-10.3g%-10.3g%-10.3g%s\n",cc$statistic[[1]],cc$parameter[[1]],cc$p.value[[1]],nw))
   }
  if (sum(z==0)>0 & sum(z>0)>0) {
   readline("\nRelationships between continuous and categorical variables")
   db<-subset(d,select=which(z!=0))
   dc<-subset(d,select=which(z==0))
   par(mar=c(3.5,3.5,.5,.5),oma=c(0,0,0,0))
   n<-length(dc)*length(db)
   n1<-ceiling(sqrt(n)); n2<-ceiling(n/n1); n<-n1*n2
   layout( matrix (1:n,n1,n2))
   for (cc in 1:length(dc)) for (bb in 1:length(db)) {
       boxplot(dc[,cc]~db[,bb])  
       title(ylab=names(dc[cc]),xlab=names(db[bb]),line=2)
   }
  }
  readline("\nPress ENTER to go on...")
  }
  return (z)
} 


treereg<-function() {
 nmtree<-function() {
    d1<-paste(ly0,"~")
    ex<-list(d[,ig])
    d2 <- paste(names(d[ig]),"",collapse="*")
    d3<-paste(d1,d2) 
    dx<-formula(d3)
    print(dx)
    #rpart.control(minsplit=20, minbucket=round(minsplit/3), cp=0.01, 
    #                 maxcompete=4, maxsurrogate=5, usesurrogate=2, xval=10,
    #                 surrogatestyle=0, maxdepth=30, ...)
    nsplit<-2
    repeat {
      tree<-rpart(dx,minsplit=nsplit,data=d)
      layout(1)
      plot(tree)
      text(tree,cex=.75,use.n=F)
      mtext(paste("tree regression analysis for",names(d[1])),line=1)
      summary(tree)
      nsplit0 <- readline(paste("\nAnswer 0 to STOP\nMinimum number of observations in a node [",nsplit,"] "))
      if (nsplit0 != "") nsplit<-as.integer(nsplit0)
      if (nsplit<3) break
   }
 }
 library(rpart)
 par(mar=c(3,1.8,2.5,1.1),oma=c(0,0,0,0))
 nmtree()
 par(mar=c(4.1,4.1,3.1,1.1),oma=c(0,0,0,0))
}

#PLOT FREQ vs VAR EXPLIC FOR LOGISTIC REG
plot.freq.grad<-function(xobs,yobs,lx,ly,bCONT) {
  if (!is.numeric(xobs)) return("Numeric data needed")
  if (sum(is.na(xobs))>0) return("NA values included, no plot") 
  ncla<-bCONT #nb categ 
  if (bCONT==0) ncla <- floor(length(xobs)/10)
  if (bCONT==0) repeat {
   if (ncla<11) break
   ncla <- ncla-1   
  }
  #gradient splitted in ncla classes
  xmin<-min(xobs); xmax<-max(xobs)
  if (bCONT==0) {
   q0 <- quantile(xobs,probs=seq(0, 1, 1/ncla), na.rm=F)
   c.cla<-quantile(xobs,probs=seq(0+1/2/ncla, 1-1/2/ncla, 1/ncla), na.rm=F)
  #freq / cla
   q1 <- cut(xobs, q0, include.lowest=T)
   t0<-table(q1,yobs)
  } else { 
    c.cla<-unique(xobs)
    t0<-table(xobs,yobs) 
  }  
  t0[,1]<-(t0[,1]+t0[,2])
  freq<-t0[,2]/t0[,1]
  #int conf of freq / cla
  lobar <- rep(0, ncla) ; hibar<-rep(0,ncla)
  for (i in 1:ncla) {
    succes<-t0[i,2]; essai<-t0[i,1]
    if (essai>10) {
      a0<-prop.test(succes,essai)$conf.int
      lobar[i]<-a0[1];hibar[i]<-a0[2]
      if (a0[1]>freq[i]) lobar[i] <- NA
      if (a0[2]<freq[i]) hibar[i] <- NA
    } else {
      lobar[i] <- NA; hibar[i] <- NA
    }
  }
  #PLOT
  ymin<-min(lobar,na.rm=T);ymax<-max(hibar,na.rm=T)
  plot(xmin,0,xlab="",ylab="",ylim=c(0,1),xlim=c(xmin,xmax),type="n")
  title(xlab=lx,ylab=ly,line=2.1)
  points(c.cla,freq,pch=16)
  for (i in 1:ncla) {
    if (!is.na(lobar[i])) {
       sige.bar <- par("cxy")[1]/2
       segments(c.cla[i],lobar[i],c.cla[i],hibar[i])
       segments(c.cla[i]-sige.bar,hibar[i],c.cla[i]+sige.bar,hibar[i])
       segments(c.cla[i]-sige.bar,lobar[i],c.cla[i]+sige.bar,lobar[i])
    }
    #sep classes
    if (bCONT==0 & i>1) abline(v=q0[i],lty=2)
  }#for i
}
  
 
regmul <- function() {
    fscreen1(d); zc1<-flook(d); nn<-length(d[,1]) 
    getf<-function(d,ig) { 
       nz<-paste(names(d[ig]),collapse=".")
       cat("\nY.OBS =",ly0,"\nFactor(s) =",nz,"\n\n")
       d1<-paste(ly0,"~")
       d2 <- paste(names(d[ig]),"",collapse="+")
       if (bINTER) d2 <- paste(names(d[ig]),"",collapse="*")
       d3<-paste(d1,d2) 
       dx<-formula(d3)
       print(dx)
       return(dx)
    }
    par(mar=c(3.5,3.5,1.5,0.5),oma=c(0,0,0,0))
    if (pac == 22) {
       cat("\n#Frequency plots for each explicative variable")
       nc11<-ceiling(sqrt(nig-1));nr11<-ceiling((nig-1)/nc11)
       nn1<-nc11*nr11;layout(matrix(1:nn1,ncol=nc11,nrow=nr11))
       dd<-d[1:100,] 
       for (ii in 1:(nig-1)) { 
         xx<-d[,ig[ii]]
         plot.freq.grad(xx,d[,1],names(d[ig[ii]]),ly0,zc1[ig[ii]])
         dy<-formula(paste(ly0,"~",names(d[ig[ii]])))
         g1<-glm(dy,family="binomial",data=d)
         cat("\n\n");print(dy)
         #print(summary(g1))
         print(summary(g1)$coefficients)  
         x1<-seq(min(xx),max(xx),len=100)
         dd[,ig[ii]]<-x1
         y1<-predict(g1,newdata=dd,type="response")
         lines(x1,y1)
       }
    } 
    if (pac == 21) i0 <- readline(paste("\n","Do regression (y/n)? [y] "))
    if (i0 == "") i0<-"y"
    if (i0 != "n") {
       dx<-getf(d,ig)
       if (pac == 21) reg<-glm(formula=dx,data=d) 
       if (pac == 22) reg<-glm(formula=dx,family=binomial,data=d)
       cat("\nSample sige, N=",nn,"\n")     
       print(summary(reg))
       slm1<-step(reg)  
       print(summary(slm1))

#CONFIRM FINAL REGRESSION       
       if (length(ig>1)) {
        ig2<-paste(as.character(ig),collapse=" ")
        print(paste(1:length(names(d)),names(d),sep='.'))
        i0<- readline(paste("*** CONFIRM explic. vars. for final regression [",ig2,"] "))
        if (i0!="") ig2<-i0
        ig<-rn_ints(ig2)
        dx<-getf(d,ig)
       }
       if (pac==21) reg<-glm(formula=dx,data=d)    
       if (pac==22) reg<-glm(formula=dx,family=binomial,data=d)    
       print(summary(reg))
       i0 <- readline(paste("\n","See OBS.PRED.RES plots (y/n)? [y] "))
       if (i0 == "") i0 <-"y"
       if (i0=="y" & pac == 21) { 
         layout( matrix (1:2,1,2) )
         plot(reg$fitted.values,d[,1],xlab="",ylab="")
         abline(0,1,col=co1)
         title(xlab="PREDICTED",ylab=ly0,line=2.1)
         plot(reg$fitted.values,reg$residuals,xlab="",ylab="")
         abline(h=0,col=co1)
         title(xlab="PREDICTED",ylab="RESIDUALS",line=2.1)
       }
       if (pac == 22) { 
#PREDICT.TABLE
         y1<-predict(reg,type="response")
         dw<-subset(d,select=c(1,ig))#rfy=1
         dw<-cbind(dw,PROB=y1,ODD.RATIO=y1/(1-y1))
         n1<-sprintf("DATA%s_nmSTAT.txt","");cd<-paste(sr1,n1,sep="/")
         cd<-getsavenm("nmSTATS","DATA",rfsr1,rffn1,"","txt")
         write.table(dw,file=cd,sep="\t",row.names=F)
#PREDICT.CURVES
         if (i0=="y") {
          zz<-numeric(length(ig))
          for (ii in 1:length(ig)) if (length(grep(names(d[ig[ii]]),reg$formula[3]))>0) zz[ii]<-ig[ii]
          zz<-zz[zz>0]; ig<-zz
          nc11<-ceiling(sqrt(length(ig)));nr11<-ceiling((length(ig))/nc11)
          nn1<-nc11*nr11;layout(matrix(1:nn1,ncol=nc11,nrow=nr11))
          rp1<-100; dd<-d[1:rp1,] 
          for (ii in 1:length(ig)) { 
           xx<-d[,ig[ii]]
           plot.freq.grad(xx,d[,1],names(d[ig[ii]]),ly0,zc1[ig[ii]])
           x1<-seq(min(xx),max(xx),len=rp1)
           dd[,ig[ii]]<-x1;nw<-""
           for (jj in 1:length(ig)) if (jj!=ii) {
              x2<-rep(median(d[,ig[jj]]),rp1)
              dd[,ig[jj]]<-x2
              nw<-paste(nw,sprintf("%s:%.3g ",names(d[ig[jj]]),x2[1]))
           }
           y1<-predict(reg,newdata=dd,type="response")
           lines(x1,y1)
           if (length(ig)<3) mtext(side=3,nw,cex=.9)
           cat("\n",ii,names(d[ig[ii]]),"vs.",ly0,"\n",nw)
          }
         }
        }#pac22
    }   
    if (pac==21) {
       #i0 <- readline(paste("\n","See diagnostic plots (y/n)? [n] "))
       #if (i0 == "") i0<-"n"
       #if (i0 != "n") {
       #   par(mar=c(4.1,4.1,3.1,.4),mfrow = c(2,2), oma = c(0, 0, 0, 0))
       #   plot(reg,main=d3)
       #}
#PREDICT.TABLE
         y1<-predict(reg)
         dw<-subset(d,select=c(1,ig))#rfy=1
         dw<-cbind(dw,PRED=y1)
         n1<-sprintf("DATA%s_nmSTAT.txt","");cd<-paste(sr1,n1,sep="/")
         cd<-getsavenm("nmSTATS","DATA",rfsr1,rffn1,"","txt")
         write.table(dw,file=cd,sep="\t",row.names=F)
    }
    cat("\n\n")
    par(mar=c(4.1,3.1,3.1,1.1),oma=c(0,0,0,0))
    readline("Continue...")
}

fpdist<-function(tac,d,xl,yl) {
        par(mar=c(3.5,3.5,1.1,0.2),oma=c(0,0,0,0))
        if (tac==5) par(mar=c(4.1,4.1,1.1,0.2),oma=c(0,0,0,0))
        nc<-length(d); nc11<-ceiling(sqrt(nc)); nr11<-ceiling(nc/nc11)
        n<-nr11*nc11;layout( matrix (1:n,nc11,nr11))
        for (ii in 1:length(d)) {
            x<-d[,ii]   
            nm<-names(d[ii])
            if (tac <5) hist(x,proba=T,xlab="",ylab="",main="")
            if (tac==5) {qqnorm(x);qqline(x)}
            if (tac==2) lines(density(x),col="blue")
            if (tac==3) curve( dnorm(x,mean(x),sd(x)),col="red",add=T)
            if (tac==22) stripchart(x,ylab="")
            if (tac==21 ) boxplot(x,ylab="")
            if (tac>10) title(xlab="",ylab=nm,line=2)         
            if (tac<5) title(xlab=nm,ylab="freq. / prob.",line=2.2)         
        }       
        par(mar=c(4.1,3.1,3.1,1.1),oma=c(0,0,0,0))
}

#plot.ANOVA     (tac,d,dx,dd,nz,ly0)
fpcomp<-function(tac,d,dx,da,xl,yl) {
        par(mar=c(2.5,2.5,1.5,0.1),oma=c(1.5,1.5,.5,.2))
        layout( 1 )
 
        if (tac<10)  {
           nc<-length(unique(d[,ig])); nc11<-ceiling(sqrt(nc)); nr11<-ceiling(nc/nc11)
           n<-nr11*nc11;layout( matrix (1:n,nc11,nr11) )
           for (ii in 1:length(da)) {
            X<-da[ii]   
            nm<-names(X)
            x <-da[[ii]][1]
            x<-x[,1] 
            n<-length(x)
            if (tac==1) hist(x,proba=F,xlab="",ylab="",main="")
            if (tac >1) hist(x,proba=T,xlab="",ylab="",main="")
            if (tac==2) lines(density(x),col="blue")
            if (tac==3) curve( dnorm(x,mean(x),sd(x)),col="red",add=T)
            mtext(side=3,paste(xl,names(da[ii])),cex=.75,adj=0,line=.1)
           }
        }
        if (tac==22) {
            with (d,stripchart(dx,ylab=""))
            mtext(xl,side=2,line=0,outer=T)
            mtext(yl,side=1,line=0,outer=T)         
        }
        if (tac==21 ) {
           boxplot(dx,ylab="",data=d)
           mtext(yl,side=2,line=0,outer=T)
           mtext(xl,side=1,line=0,outer=T)
        }
        if (tac<10) {
             mtext(yl,side=1,line=0,outer=T)
             if (tac==1) mtext("frequency",side=2,line=0,outer=T)
             else mtext("probability",side=2,line=0,outer=T)
        }
        par(par(mar=c(4.1,3.1,3.1,1.1),oma=c(0,0,0,0)))
}
   

fplatt<-function(tac,d,ig,nig,ly0) {
        d1 <- paste("~",ly0,sep="")
        d2 <- paste(names(d[,ig]),collapse="+")
        #for (ii in 2:nig) d[ii] <- factor(d[,ii],labels=paste(names(d[ii]),"",sep=" "))
        for (ii in 2:nig) d[ii] <- paste(names(d[ii]),d[,ii],sep=" ")
        d2 <- paste(names(d[ig]),"",collapse="+")
        d1 <- paste(d1,d2,sep="|")
        dp<-formula(d1)
        if (tac==10) cc<-dotplot(dp,data=d,col="black")
        if (tac==21) cc<-bwplot(dp,data=d) 
        if (tac==22) cc<-stripplot(dp,data=d,col="black")
        if (tac<7) {
           cc<-histogram(dp,data=d,type=c("density"),add=T,
                         xlab=ly0,
                         panel=function(x) {                                                     
                           panel.histogram(x,breaks=NULL)
                           if (tac==2)
                           panel.densityplot(x,col="darkolivegreen",plot.points=F) 
                           if (tac==3) 
                           panel.mathdensity(dmath=dnorm,args=list(mean=mean(x),sd=sd(x)),col="red",plot.points=F)
                           if (tac==4) 
                           panel.mathdensity(dmath=dpois,args=(mean=mean(x)),col="red",plot.points=F)
                           if (tac==5) 
                           panel.mathdensity(dmath=dlnorm,args=list(mean=mean(x),sd=sd(x)),col="red",plot.points=F)
                         }                         
                         )
        }
        print(cc) 
}

#ANOVA...
compar <- function() { 
    ntt<-length(interaction(unique(d[,ig])))
    cat("\nTotal nb. of modalities",ntt,"\n")
    nz<-paste(names(d[ig]),collapse=".")
    dd<-split(d,f=d[ig])
    cat(sprintf("\nN = %d, FILE: %s, VARIABLE: %s",length(d[,1]),rffn1,names(d[1])))
    cat(sprintf("\n%-16s%-12s%-12s%-12s%-12s%s\n",nz,"Mean","SD","Median","Min","Max"))
    for (kk in 1:length(dd)) {
        vv<-dd[[kk]][,1]
        mm<-mean(vv)
        ss<-sd(vv)
        md<-median(vv)
        mi<-min(vv)
        ma<-max(vv)
        cat(sprintf("%-16s%-12.4g%-12.4g%-12.4g%-12.4g%.3g\n",as.character(names(dd[kk])),mm,ss,md,mi,ma))
    }
    cat("\nY.OBS =",ly0,"\nFactor(s) =",nz,"\n\n")
    ex<-list(nig-1)
    d1<-paste(ly0,"~")
    #for (kk in 2:nig) ex[kk]<-list(d[,kk])
    ex<-list(d[,ig])
    d2 <- paste("as.factor(",names(d[ig]),")",collapse="+")
    if (bINTER) d2 <- paste("as.factor(",names(d[ig]),")",collapse="*")
    dx<-paste(d1,d2) ;  dx<-formula(dx) ;  #print(dx)
#REPEATED MEAS. NLME
    if (pac==35) {
        library(nlme) 
        i1<-length(d) 
        di<-paste("~1|",names(d[i1]))
        dr<-formula(di)        
        #cat("\nlme(frfxed=",ly0,", random=",di,"\n")
        lme1<-lme(frfxed=dx,random=dr,method="ML",data=d)
        options(digits=3); cat("\n*****************************************************\n")
        print(summary(lme1)); ttt<-anova(lme1);
    }
    if (pac==32){
        ttt<-lm(formula=dx,data=d); ttt<-anova(ttt)  
    }
    if (pac==31){     
        ttt<-kruskal.test(formula=dx,data=d);ttt$data.name<-paste(ly0,"Fact.",nz)
    }
    cat("\n\n****************** ANOVA table **************\n")
    print(ttt)  ;   #print(summary(ttt)) ;   #print(ttt$contrasts) 
    if (!flagLATTICE) fpcomp(tac,d,dx,dd,nz,ly0)
    if (flagLATTICE) fplatt(tac,d,ig,nig,ly0) 
    readline("Continue...")
}

cont.table <- function() { 
    bb<-table(subset(d,select=names(d)))
    cat("\n\n");print(bb)
    cc<-chisq.test(bb,simulate.p.value=TRUE)
    print(cc)
    cat("EXPECTED\n"); print(cc$expected,digits=3)
    layout(1);par(3.5,4.5,.5,.5)
    assocplot(bb)
    readline("\nContinue..")
}

distrib <- function() { 
  cat(sprintf("\n%-10s%-10s%-10s%-10s%-10s%s","X","Mean","SD","Median","Min","Max\n"))
  for (ii in 1:length(d)) {
    X<-d[,ii]
    #if (flagDELDV0) X<-X[X!=0]
    nm<-names(d[ii])
    cat(sprintf("%-10s%-10.4g%-10.4g%-10.4g%-10.4g%.4g\n",nm,mean(X),sd(X),median(X),min(X),max(X)))
  }
  cat(sprintf("\n%-10s%-10s%-10s%-10s%-10s%-10s%-10s%s\n","Quantiles",".01",".025",".25",".50",".75",".975",".99"))
  for (ii in 1:length(d)) {
    X<-d[,ii]
    #if (flagDELDV0) X<-X[X!=0]
    nm<-names(d[ii])
    pp<-c(.01,.025,.25,.5,.75,.975,.99)   
    pq<-as.numeric(quantile(X,pp))
    cat(sprintf("%-10s%-10.4g%-10.4g%-10.4g%-10.4g%-10.4g%-10.4g%.4g\n",nm,pq[1],pq[2],pq[3],pq[4],pq[5],pq[6],pq[7]))
  }
  fpdist(tac,d,"","")
  readline("Continue...")
}

if (flagLATTICE) {
      library(lattice)
      trellis.device(new=FALSE,color=flagCOLOR)
      background=trellis.par.get("background")
      background$col="white"
      trellis.par.set("background",background)
      plot.line=trellis.par.get("plot.line")
      plot.line$col=1

      trellis.par.set("plot.line",plot.line)
      plot.point=trellis.par.get("plot.point")
      plot.point$col="black"
      trellis.par.set("plot.point",plot.point)
}

cat("\nFile",getwd(),"/",rfsr1,"/",rffn1)
cat("\nN",length(d[,1]),"\n")
if (pac==1) distrib()
if (pac==5) cont.table()
if (pac>20 & pac<26) regmul()
if (pac>25 & pac<30) treereg() 
if (pac>30 & pac<40) compar()
par(par(mar=c(4.1,3.1,3.1,1.1),oma=c(0,0,0,0)))

}

fp1()
rm(fp1)
rm(lyy,lxx,pac)
rm(mod,y,n,opar,ncol,nrow,mm)
rm(ii,i0,nc,nig,ly0,background)
rm(flagNM,flagLATTICE)
rm(Y0,SLOPE,r,v,pv,nr,ig,ci)






