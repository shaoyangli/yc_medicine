#NONMEM STYLE TABLE FILES

#LEGENDS
lxx<-c("")
#lxx<-c("time, days")
lyy<-c("")
#lyy<-c("plasma theophylline")
#lyy<-c("beta2-microglobulin, mg/L")
#lyy<-c("plasma acyclovir, �mol/L","aqueous humor acyclovir, �mol/L")
#lyy<-"neutrophils count/mm3"

#Draw percentile points, DEFAULT=F
flagDRPTS<-FALSE

#Draw simulated distribution points, Symbol=".", DEFAULT=F
flagDRDIST<-FALSE

### X, Y AXES TRANSFORM
#Natural values to LOG10(X) LOG10(Y)
flagLX<-FALSE
flagLY<-FALSE

#Retransform LOG values to NATURAL values (DV,PRED,RES,IPRE,IRES)
#NAT LOGS (Ln(e)=1)
flagLtoN  <-FALSE
#LOG10 (log(10)=1)
flagL10toN<-FALSE

#Print all time-DV OBS and percentiles DEFAULT=F
flagPRDVPERC<-FALSE

#ASK FOR X HEADER
flagASKx<-FALSE

############################### DO NOT MODIFY ################################
#RESERVED
flagEXCLUDED<-""
flagCOPL<-TRUE

cat("\nVISUAL PREDICTIVE CHECK")
cat("\nSIMULATION file PLUS OBSERVED DVs file")
cat("\nOriginal data file = NONMEM file created by $TABLE containing original DV\n\n")

options(warn=-1)
rr<-rn_opt(T,T);rfsp1<-rr[[1]];rfski<-rr[[2]];hd1<- rr[[3]];rm(rr)

#READ FILES. ASK SPLIT VAR
rfsr1 <- rn_dir(rfsr1)
rffn1[2] <- rn_f11("SIMULATION DATA FILE",rffn1[2])
d<-rn_ddd(rfsr1,rffn1[2],hd1[2],rfski[2],rfsp1)
cat("SIMULATION Table Header for x\n")
if (!flagASKx) cat("TIME is selected by default\n")
if ( flagASKx) rfxy[1] <- rn_h22(d,"X or TIME",rfxy[1])
if (!flagASKx) rfxy[1] <- rn_h22(d,"TIME",rfxy[1])
rfxy[2] <- rn_h22(d,"DV",rfxy[2])
rfxy<-as.integer(rfxy)

ONLYSIM<-F
rffn1[1] <- rn_f11("\nOBSERVATION DATA FILE",rffn1[1])
ONLYSIM<-(rffn1[1]=="..")
if (!ONLYSIM) {
 da<-rn_ddd(rfsr1,rffn1[1],hd1[1],rfski[1],rfsp1)
 cat("OBSERVATION Table Header for x\n")
 if (!flagASKx) cat(names(d[rfxy[1]])," is selected by default\n")
 if ( flagASKx) rfx <- rn_h22(da,"X or TIME",rfx)
 if (!flagASKx) rfx <- rn_h22(da,names(d[rfxy[1]]),rfx)
 rfy<-rn_h22(da,"DV",rfy)
}
####END READ FILES

cat("\nConditioning variable(s) for data splitting\n(Answer 0 if none)\n")
rfizs<-rn_izs(d,"SIMULATION table, HEADERS",rfizs)

ngr<-1; iz <-0; ig <-0; niz<-1
   if (rfizs[1]!=0) iz<-rn_ints(rfizs)
   if (rfizs[1]!=0) niz<-length(iz)
   ngr<-0
   if (iz>0) ngr<-length(unique(d[,iz]))
   if (ngr==0) ngr<-1
   if (ngr==0) iz <-1
   if (!ONLYSIM & iz!=0) {
     ig<-which(names(da) %in% names(d[iz]))
     if (length(ig)<niz) {
      igs<-rn_rfizs(da,"DATA table, HEADERS",igs)
      ig<-rn_ints(igs)
     }  
   }
#CHECK SPLITTING

vpc<-function () {

ncs<-length(d)
for (ii in 1:ncs) {
       d[,ii] <- as.vector(d[,ii])
       d[,ii] <- as.double(d[,ii])
}
d <- subset(d,!is.na(d[,1]))  
     
if (flagDELDV0) d <-rn_zero(d)
if (!ONLYSIM & flagDELDV0) da<-rn_zero(da)

ti1<-as.integer(rfx)
dv1<-as.integer(rfy)
ids<-as.character(rfxy[1])
id<-as.integer(rfxy[1])
nid<-length(id)

vpoints<-function(d,u1,v1) {
   tt1<-which(names(d)=="ID"); id1<-NA; if (length(tt1)>0) id1<-d$ID                    
   po1<-46; if (!flagPTS) po1=1
   x<-d[,u1];y<-d[,v1]
   if (!flagID)points(x,y,col=1,pch=po1)
   if (flagID & !is.na(id1)) text(x,y,as.character(id1),cex=.75)
   if (flagIDLINK & !is.na(id1)) {
              id<-unique(id1)               
              for (jj in 1:length(id)) {
                  di<-subset(d,d$ID==id[jj])
                  if ( length(di[,1]) >1) lines(di[,u1],di[,v1],col=5,lty=3)
              }  
   }
}

fg1<-function(xx,y1,y2,y3,X,YO, ii,nm,xu12,yu12,tr11,nmg,wx,wy,tit1){      
     par(mar=c(2.5,2.5,.5,.5),oma=c(rn_ma1+1.5,1,0,0))
     #if (tit1) par(mar=c(2.5,2.5,2.5,.5),oma=c(1,1,0,0))
     po1<-46;   if (!flagPTS) po1=1;   ilg="" 
     if (flagLX) ilg<-"x" ; if (flagLY) ilg<-"y"; 
     if (flagLX & flagLY) ilg<-("xy")
     o   <-order(xx)
     xx   <-xx[o];  y1   <-y1[o];  y2   <-y2[o];   y3   <-y3[o]
     vv<-numeric(0)
     if (ilg=="y") vv<-which((y1<0) & (y1==0)) 
     if (length(vv)>0) {
        xx<-xx[-vv]
        y1<-y1[-vv]
        y2<-y2[-vv]
        y3<-y3[-vv]
     }
     if (length(xu12)<2) xu12<-c(min(xx),max(xx))
     if (length(yu12)<2) yu12<-c(min(y1),max(y3,YO))
     plot(xx,y2, type="n",xlab="",ylab="",xlim=xu12,ylim=yu12,log=ilg)
     if (flagDRPTS) {points(xx,y1); points(xx,y2); points(xx,y3)} 
     if (tr11>0) {
        lx2<-lowess(xx,y2,f=tr11);lx1<-lowess(xx,y1,f=tr11);lx3<-lowess(xx,y3,f=tr11) 
        lines(lx2, col=Cmd,lty=Lmd,pch=".")
        lines(lx1, col=Cqt,lty=Lqt,pch=".")
	  lines(lx3, col=Cqt,lty=Lqt,pch=".")
        x  <-lx1$x;p1<-lx1$y;p2<-lx2$y;p3<-lx3$y
     }
     if (tr11==0) {
        lines(xx,y1,col=Cqt,lty=Lqt)
        lines(xx,y2,col=Cmd,lty=Lmd)
        lines(xx,y3,col=Cqt,lty=Lqt)
        x  <-xx;p1<-y1;p2<-y2;p3<-y3
     }
     dw<-data.frame(TIME.X=x,LOWER.Y=p1,MEDIAN.Y=p2,UPPER.Y=p3)
     if (flagDRDIST) points(wx,wy,pch=".")
     if (!ONLYSIM) vpoints(da,rfx,rfy) #points(X,YO, pch=po1) 
     lx<-lxx
     ly<-lyy 
     if (lx=="") lx<-names(d[rfxy[1]])
     if (ly=="") ly<-"DV"
     if (length(lxx)>1 & length(lxx)>=ii) lx<-lxx[ii]   
     if (length(lyy)>1 & length(lyy)>=ii) ly<-lyy[ii]   
     mtext(paste(lx,"  [",nmg,"]"),side=1,line=2)
     mtext(ly,side=2,line=2)
     rn_titles(rfsr1,rffn1,2,1.95)
     return(dw)
}#PLOT

xu12<-""; yu12<-""


medDV <- function(pc,lxx,lyy, tr11, rs1,nmg,rd1,ngr) {
    dd<-rs1[[1]]; X<-NULL;YO<-NULL; nm1<-"" 
    layout( matrix (1:1,1,1) )
       if (length(dd[,1])==0) next
       X<- dd[,rfxy[1]];YO<-dd[,rfxy[2]]
       xx<-unique(dd[,rfxy[1]])  ; ntt<-length(xx)
       y3<-y1<-y2<-numeric(ntt)
       fm1<-       "\n%-11s%-11s%-11.3g%-11.3g%.3g\n"
       if (ngr>1) nm1<-paste(nmg,unique(dd[,iz]),sep="")
       if (!ONLYSIM & flagPRDVPERC) if (ngr>1) cat("Sorting condition",nmg)
       if (flagPRDVPERC) cat(sprintf(fm1,"t","Size",pc[1],pc[2],pc[3]))
       for (ii in 1:ntt) {
           db<-subset(dd,dd[,rfxy[1]]==xx[ii])
           y1[ii]<-quantile(db[,rfxy[2]],pc[1])
           y3[ii]<-quantile(db[,rfxy[2]],pc[3])
           y2[ii]<-quantile(db[,rfxy[2]],pc[2])
           if (flagPRDVPERC) fm1<-"%-11.3g%-11d%-11.3g%-11.3g%.3g\n"        
           if (flagPRDVPERC) cat(sprintf(fm1,xx[ii],length(dd[,rfxy[2]]),y1[ii],y2[ii],y3[ii]))
       }
       cat("\n") ;  ss<-0 ;  fm1<- "\n%-14s%-6s%-13.3g%-s%-.3g\n"
       if (ngr>1) cat("Sorting condition",nmg)
       if (flagPRDVPERC) cat(sprintf(fm1,"t","data<",pc[1],"data>",pc[3]))

       if (!ONLYSIM) { 
         dd<-rd1[[1]]; X<- dd[,ti1]; YO<-dd$DV    
         ss <- 0;ssl <- 0; ssh <- 0; ssml <- 0;ssmh <- 0
         for (ii in 1:ntt) {
           db<-subset(dd,dd[,ti1]==xx[ii])
           yy<-db$DV
           yl<-yy[yy<y1[ii]]
           yh<-yy[yy>y3[ii]]
           sl<-length(yl); sh<-length(yh)
           ss<-ss+sl+sh
           ssl<-ssl+sl
           ssh<-ssh+sh
           n<-length(yy)
           yml<-yy[yy>y1[ii] & yy<y2[ii]]
           ymh<-yy[yy>y2[ii] & yy<y3[ii]]
           sml<-length(yml); smh<-length(ymh)
           ssml<-ssml+sml
           ssmh<-ssmh+smh
           if (flagPRDVPERC) fm1<-"%-15.3g%-9d%11d\n"        
           if (flagPRDVPERC) cat(sprintf(fm1,xx[ii],sl,sh))
          }
          cat("\nFiles",rffn1,",  Sorting condition",nmg)
          cat("\nTotal out of limits",ss,"/",length(dd[,1]),"values")
          N <- length(dd[,1]) 
          if (N>0) pcol<- 100*ss/N
          if (N>0) cpout<-(1-pc[3]) + pc[1]
          if (N>0) bb<-binom.test(ss,N,p=cpout)
          if (N>0) {
           cat(sprintf("\n\n%-15s\n%-15s%-15s%s","Exact Binomial Test, Out of limits","Expected","Observed",paste("95%",names(bb[4]))))
           cat(sprintf("\n%-15.3g%-15.3g[%-4.3g , %.3g]\n",100*cpout,pcol,100*bb[[4]][1],100*bb[[4]][2]))
           obs<-c(ssl,ssml,ssmh,ssh)
           the<-c(pc[1],pc[2]-pc[1],pc[3]-pc[2],1-pc[3])*N            
           OBS.EXP<-data.frame(OBSERVED=obs,EXPECTED=the)
           cat(sprintf("\n%s","DISTRIBUTION"))
           cat(sprintf("\n%s","----------+----------+----------+----------+----------"))
           cat(sprintf("\n%-20s%-11.3g%-11.3g%.3g","Percentile",pc[1],pc[2],pc[3]))
           cat(sprintf("\n%s","----------+----------+----------+----------+----------"))
           cat(sprintf("\n%-15s%-11g%-11g%-11g%g","N.OBS",ssl,ssml,ssmh,ssh))
           cat(sprintf("\n%s","----------+----------+----------+----------+----------"))
           cat(sprintf("\n%-15s%-11.3g%-11.3g%-11.3g%.3g","N.EXP",the[1],the[2],the[3],the[4]))
           cat(sprintf("\n%s","----------+----------+----------+----------+----------"))
           cat(sprintf("\n%-15s%-11.3g%-11.3g%-11.3g%.3g","%OBS",100*ssl/N,100*ssml/N,100*ssmh/N,100*ssh/N))
           cat(sprintf("\n%s","----------+----------+----------+----------+----------\n"))
           bb<-chisq.test(OBS.EXP)
           print(bb)
           if (sum(bb$expected<5)>1) {bb<-chisq.test(OBS.EXP,simulate.p.value = TRUE);print(bb)}
          }
       }
       fg1(xx,y1,y2,y3,X,YO, jj,nm,xu12,yu12, tr11, nmg,dd[,rfxy[1]],dd[,rfxy[2]],FALSE)
       i0 <- readline(paste("\nModif. X axis, Min Max "))
       if (i0!="") {
          xu12<-strsplit(i0,split=" ")
          xu12<-as.numeric(xu12[[1]])
       }
       i0 <- readline(paste("Modif. Y axis, Min Max "))
       if (i0!="") {
          yu12<-strsplit(i0,split=" ")
          yu12<-as.numeric(yu12[[1]])
       }
       repeat {#FINE TUNING
         cat("\nLOOP to improve graphical aspect, no input modification will stop the loop") 
         cat("\nSpline control value, v (v is the smoother span)") 
         cat("\nThis gives the proportion of points in the plot")
         cat("\nwhich influence the smooth at each value")
         cat("\nLarger values give more smoothness (typical 0.66)")
         ii0 <- readline(paste("\nv = 0 -> Interpol\nv > 0 -> Spline\nv [",tr11,"] "))
         if (ii0 != "") tr11<-as.numeric(ii0)
         dw<-fg1(xx,y1,y2,y3,X,YO, jj,nm,xu12,yu12, tr11, nmg,dd[,rfxy[1]],dd[,rfxy[2]],FALSE)         
         cd<-rn_savenm("nmVPC","DATA",rfsr1,rffn1[2],nm1,"txt")
         write.table(dw,file=cd,sep="\t",row.names=F)        
         cd<-rn_savenm("nmVPC","GRAPH",rfsr1,rffn1[2],nm1,"pdf")
         pdf(cd,onefile=T)
         fg1(xx,y1,y2,y3,X,YO, jj,nm,xu12,yu12, tr11, nmg,dd[,rfxy[1]],dd[,rfxy[2]],TRUE)
         dev.off()
         if (ii0=="") break
       }
       #if (!flagCOPL) cc<-readline(paste("Condits.",nm,"Next? (y/n) y "))
       if (jj<ngr) cc<-readline(paste("\nFiles",rffn1,", next sorting condition..."))
    return(tr11)
}

tr11<-0
if (flagL10toN) {
       d[,rfxy[2]]<-10**d[,rfxy[2]]
       da$DV     <-10**da$DV
}
if (flagLtoN) {
       d[rfxy[,2]]<-exp(d[rfxy[,2]])
       da$DV     <-exp(da$DV)
}

repeat {
     fi11<-function(nm1,deft) {
         i0<-readline(paste(nm1,"[",deft,"] "))
         if (i0 != "") deft<-i0
         return(deft)
     }     
     if (F) {
      cat("\nPercentiles for LOWER, MIDDLE, UPPER curves\n")
      pc[1]<-fi11("for LOWER  curve",rfqt[1])
      pc[2]<-fi11("for MIDDLE curve",rfqt[2])
      pc[3]<-fi11("for UPPER  curve",rfqt[3]) 
      rfqt<-as.numeric(pc)
     }
     if (T) {
      pi1<-as.numeric(rfqt[3])-as.numeric(rfqt[1])
      cat(sprintf("\nPrediction interval, PI %.3g, between lower %s and upper %s curves",pi1,rfqt[1],rfqt[3]))
      cat("\nMedian curve defined as the PI median,",rfqt[2],"\n")
      pi1<-as.numeric(fi11("PI",pi1))
      p1<-(1-pi1)/2;p3<-pi1+p1;p2<-pi1/2+p1; rfqt<-as.character(c(p1,p2,p3))
      cat(sprintf("\nLOWER %.3g, MEDIAN %.3g, UPPER %.3g percentile curves\n",p1,p2,p3))
     } 
     rs1<-rn_zi123(d, rfizs)
     if (!ONLYSIM) rd1<-rn_zi123(da,ig)
     for (jj in 1:length(rs1[[1]])) {
       s1<-rs1[[1]][jj]; d1<-NULL; if (!ONLYSIM) d1<-rd1[[1]][jj] 
       nmi<-paste(rs1[[2]][1],rs1[[3]][jj])
       tr11<-medDV(c(p1,p2,p3),lxx,lyy,tr11,s1,nmi,d1,length(rs1[[1]]))
     } 
     rm(res,jj)
     i0<-readline("\n\nREDEFINE PLOTS, CONTINUE ? [y] ")
     if (i0 != "" & i0 != "y") break
}

}#vpc()

vpc()

rm(vpc,lxx,lyy, ONLYSIM)
rm(d,da,ngr, iz , ig, niz, hd1)
rm(flagLX,flagLtoN,flagL10toN,flagEXCLUDED,flagASKx)
rm(flagDRPTS,flagDRDIST,flagCOPL,flagPRDVPERC)
par(mar=c(4.1,3.1,3.1,1.1),oma=c(0,0,0,0))
