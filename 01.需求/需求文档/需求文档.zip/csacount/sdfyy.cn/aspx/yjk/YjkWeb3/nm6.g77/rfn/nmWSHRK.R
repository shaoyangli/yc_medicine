#NONMEM TABLE FILES
flagNM<-TRUE

############################ DO NOT MODIFY ################################
#RESERVED
flagWFN<-F
flagLATTICE<-F

cat("\nFor WFN.nmgo users")
cat("\nIndicate runname (without ext.) then SPECIFIC TABLE")
cat("\nIf only runname, the .fit file will be opened by default\n")
cat("\nExample, Filename [ ]  theoph1 pkcovtable1")
cat("\nExample, Filename [ ]  theoph1\n")

cat("\nSHRINKAGE analyses for NONMEM tables data")
cat("\n$TABLE must include ETA(s) in the order of coding and IWRES")
cat("\ni.e, duplicate rows are deleted")
cat("\nTo disable this, turn the flagUNI to FALSE\n")

options(warn=-1)
rr<-rn_opt(T,T)
rfsp1<-rr[[1]]
rfski<-rr[[2]]
hd1<- rr[[3]];rm(rr)

#READ FILES. ASK SPLIT VAR
rfsr1 <- rn_dir(rfsr1)
rffn1 <- rn_f11("",rffn1)
d<-rn_ddd(rfsr1,rffn1,hd1,rfski,rfsp1);rm(hd1)
####END READ FILES
ncs<-length(d)
for (ii in 1:ncs) {
       d[,ii] <- as.vector(d[,ii])
       d[,ii] <- as.double(d[,ii])
}
d <- subset(d,!is.na(d[,1]))
d <- rn_zero(d)  
if (flagUNI) d<-unique(d)

rn_dtx <- function(rfsr1,rffn1,hd1,rfski,rfsp1,ext1,tit2) {
    cns<-character();cn1<-numeric();cc<-1;tit1<-paste(tit2,":",sep="")
    fn2<-character(2); fn2<-strsplit(rffn1,split=" ")
    fn2<-fn2[[1]]; rffn1<-fn2[1]
    cd<-rn_cd2(rfsr1,rffn1,"")
    cd3<-paste(rffn1,wfnDIR,sep=".")
    cd4<-paste(rffn1,ext1,sep=".")
    cd<-paste(rfsr1,cd3,cd4,sep="/")          
    cat("\nOpen file",cd,"\n")
    da<-readLines(cd)
    #READ COL NAMES
    for (ii in 1:length(tit1)) { for (kk in 1:length(da)) {
        da1<-da[kk];da1<-strsplit(da1,split=" "); da1<-da1[[1]]
        if (da1[1]==tit1[ii]) {
            for (jj in 1:length(da1)) if (da1[jj]!="" & da1[jj]!=tit1[ii]) {cns[cc]<-da1[jj];cc<-cc+1}
            break
        }
    } }
    tit1<-paste(tit2,"SD",sep="");cc<-1
    for (ii in 1:length(tit1)) { for (kk in 1:length(da)) {
        da1<-da[kk];da1<-strsplit(da1,split=" "); da1<-da1[[1]]
        if (da1[1]==tit1[ii]) {
           for (jj in 1:length(da1)) {
             v1<-as.numeric(da1[jj]) 
             if (!is.na(v1)) {cn1[cc]<-v1;cc<-cc+1}
           }
           break
        }#if
    } }     
    db<-data.frame(rbind(cn1));cns<-cns[1:length(cn1)];names(db)<-cns
    return(db)       
}

r_match<- function(d,nm1,ix) {
    ix<-grep(nm1,names(d))
    if (TRUE | length(ix)==0) 
    { #cat("\n\n") 
      print(paste(1:length(names(d)),names(d),sep='.'))
      i0<-readline(paste("Header number, ",nm1,"[",paste(ix,collapse=" "),"] "))
      if (i0 != "") ix<-i0
      tt1<-ix
      if (is.na(tt1)) tt1 <-0
    }
    return(tt1)
}

#READ SMR FILE NAME
dsmr <- rn_dtx(rfsr1,rffn1,hd1,rfski,rfsp1,"smr", c("ETA","ERR") )
cat("\nTable of ETASD(s)  and ERRSD(d) values from .smr file\n")
print(dsmr)

#DELETE ZERO DV VALUES
if (flagUNI) d<-unique(d)

cat("\nShrinkage of ETA(s)\n")
iiy<-r_match(d,"ETA",iy)
cat("\nHEADER number for IWRE item\n")
ix <- rn_h22(d,"IWRE",ix)

fshrk1<-function(wr1) {

   cov1n <- function(x,xl,bPDF,kk) {
     tac<-2
        hist(x,proba=T,xlab="",ylab="",main="")
        if (tac==5) {qqnorm(x);qqline(x)}
        if (tac==2) lines(density(x),col="blue")
        if (tac==3) curve( dnorm(x,mean(x),sd(x)),col="red",add=T)
        title(xlab=xl,ylab="freq. / prob.",line=2.2)         
        li11<-(.5); if (bPDF) li11<-(-1.25); 
        rn_titles(rfsr1,rffn1,1,.75)   
   }

   par(mar=c(3.5,3.5,1.2,0.5),oma=c(rn_ma1,0,0,0))
   iy<-iiy; ny<-length(iy)
   nc11<-ceiling(sqrt(ny)); nr11<-ceiling(ny/nc11)
   n<-nr11*nc11;layout( matrix (1:n,nc11,nr11) )
   if (wr1) cat(sprintf("\nN=%d, FILE: %s\n",length(d[,1]),rffn1))
   if (wr1) cat(sprintf("\n%-11s%-11s%-11s%-11s\n","Item","ETA","SD(ETAph)","shrinkage(ETA)"))
   for (kk in 1:ny) {
     y<-d[,iy[kk]];NY<-names(d[iy[kk]]);NY<-names(dsmr[kk])
     sdy<-sd(y); v <- 1 - sdy/dsmr[1,kk]
     if (wr1) cat(sprintf("%-11s%-11.3g%-11.3g%-11.3g\n",NY,dsmr[1,kk],sdy,v))
     cov1n(y,NY,!wr1,kk)
   }
   if (wr1) readline("Continue... ")
   if (ix!=0) {
    layout( matrix (1:1,1,1) )
    if (wr1) cat(sprintf("\n%-11s%-11s%-11s%-11s\n","Item","EPS","SD(IWRE)","shrinkage(EPS)"))
    y<-d[,ix];NY<-names(d[ix]);NY<-"EPS"
    sdy<-sd(y); v <- 1 - sdy
    if (wr1) cat(sprintf("%-11s%-11.3g%-11.3g%-11.3g\n",NY,"EPS",sdy,v))
    cov1n(y,NY,!wr1,kk)
   }
   par(mar=c(4.1,3.1,3.1,1.1),oma=c(0,0,0,0))
   if (wr1) readline("Continue... ")
}

fshrk1(TRUE)
cd<-rn_savenm("nmCORREL","GRAPH",rfsr1,rffn1[1],"","pdf")
pdf(cd,onefile=T)
fshrk1(FALSE)
dev.off()
     
rm(fshrk1,iiy,ii,i0,nc,dsmr)
rm(flagWFN,flagNM)
