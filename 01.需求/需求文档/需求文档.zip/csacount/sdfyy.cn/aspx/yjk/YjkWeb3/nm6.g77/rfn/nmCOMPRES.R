#LINE.COLORS identity,regression,normal,smooth,         spline
LCLR<-    c("black"   ,"red",   "red",  "darkolivegreen","blue")
#LINE.STYLES 0=none, 1=solid, 2=dashed, 3=dotted
LSTY<-    c(  1,        3,         1,     1,              1)

#TRANSFORM DATA FOR STATISTICS 
flagLOG10  <-F

#STATISTICS KRUSKAL-WALLIS TEST
flagKW  <-F
#STATISTICS ON REPEATED MEASURES USING nlme PACKAGE
flagNLME<-F

#TIGHTEN UP SPACING AND MARGINS
flagMARGINS<-T

###########                                columns definition
  dn1<-c("WRES","DV","PRED")
###########      

############################ DO NOT MODIFY ################################
#RESERVED

cat("\nCOMPARISON OF 'WRES' FROM DIFFERENT MODELLINGS")
cat("\n'WRES' DISTRIBUTIONS")
cat("\nBIAS, VARIABILITY, PRECISION BASED UPON DV.PRED\n")

options(warn=-1)
rr<-rn_opt(T,T);rfsp1<-rr[[1]];rfski<-rr[[2]];hd1<- rr[[3]];rm(rr)

#READ FILES. 
rfsr1 <- rn_dir(rfsr1);i0<-1
repeat {
  rffn11 <- rn_f11("answer .. to stop",rffn1[i0])
  if (rffn11==".." | is.na(rffn11)) {rffn1[i0]<-NA; break }
  rffn1[i0]<-rffn11;i0<-i0+1 
}
rffn1<-rffn1[!is.na(rffn1)]
####END READ FILES


if ( flagLOG10) {
   d$DV<-log10(d$DV)
   d$PRED<-log10(d$PRED)
}

fp1 <- function () {
 
coplot1f <- function(d,lzi,dn,bQU) {
    rp1<-0; co1<-1;  li1<-1; po1<-46; if (!flagPTS) po1=1  
    idxf <- which(names(d)=="FILE")
    dm<-split(d,d[,idxf]); nf1<-length(dm);

    compwres<-function(dn) {
      cat(sprintf("\n\nSTATISTICS %s, N =%d * %d\n",dn,length(d[,1])/nf1,nf1))
      if (lzi!="") cat(sprintf(", Modality %s",lzi))
      sp1<-"\n%-14s%-10s%-10s%-10s%-10s%s"
      sp2<-"\n%-14s%-10.3g%-10.3g%-10.3g%-10.3g%.3g"
      mn1<-"Median"
      if (dn=="WRES") mn1<-"-2< % <+2"
      if (dn=="WRES") sp1<-"%-14s%-10s%-7s%-13s%-10s%s"
      cat(sprintf(sp1,dn,"Mean","SD",mn1,"2.5th","97.5th"))
      x<-list()
      for (ii in 1:nf1) {
          #if (tr2 != "999") {
          if (TRUE) {
             if (dn=="WRES") {
                X<-as.numeric(dm[[ii]][,dn] )
                n1<-length(X[X< -2]);  n2<-length(X[X>  2])
                n0<-length(X);   mn1<-100*(n0-n1-n2)/n0
             }     
             if (dn=="BIAS") X<-dm[[ii]][,2]-dm[[ii]][,3]
             if (dn=="PRECISION") X<-(dm[[ii]][,2]-dm[[ii]][,3])**2
             x[[ii]]<-X;  
             if (dn!="WRES") mn1<-median(X)
             q025<-quantile(X,.025);q975<-quantile(X,.975) 
             cat(sprintf(sp2,rffn1[ii],mean(X),sd(X),mn1,q025,q975))
          } 
      }
      cat("\n"); tst1<-bartlett.test(x); tst1$data.name<-paste(rffn1)
      print(tst1)
      if (flagKW) {
         tst1<-kruskal.test(x)
         tst1$data.name<-paste(rffn1)
      }
      if (flagNLME) {
         cat("\ANOVA USING nlme PACKAGE\n")
         d1<-paste(dn,"~","FILE")
         d2<-formula(d1)
         lme1<-lme(fixed=d2,random=~1|as.factor(ID), method="ML", data=d )
         tst1<-anova(lme1)
      }
      if (flagKW | flagNLME) print(tst1)
    }#comp.wres

    reg<-function(u1,v1,lxx,lyy) {
      if (lzi!="") cat("\nModality, ",lzi)
      cat(sprintf("\n%-15s%-11s%-11s%s","File","Y0","SLOPE","r"))
      for (ii in 1:nf1) {
          #if (TRUE) { (tr2 != "999") {
          if (TRUE) { 
             x<-as.numeric(dm[[ii]][,u1])
             y<-as.numeric(dm[[ii]][,v1])
             mod<-glm(y~x)
             Y0<-coef(mod)[1];SLOPE<-coef(mod)[2]; r<-cor(x,y)
             cat(sprintf("\n%-14s%-11.3g%-11.3g%.3g",rffn1[ii],Y0,SLOPE,r))
          } 
      }     
    }#reg.dvpred
    plothist<-function(dn,dx) {
         typh<-c("percent","count","density")
         cc<-histogram(dx,data=d,type=typh[3],add=T,
                           xlab=sprintf("%s (%s)",dn,lzi),
                           panel=function(x) {                                                     
                             panel.histogram(x,breaks=NULL)
                             panel.densityplot(x,col=LCLR[4],lty=LSTY[4],plot.points=F) 
                             panel.mathdensity(dmath=dnorm,
                             args=list(mean=mean(x),sd=sd(x)),
                             col=LCLR[3],lty=LSTY[3],plot.points=F )
                           }                         
                           )
         if (!flagMARGINS) print(cc)
         if ( flagMARGINS) print(cc, pos = c(-0.01, -0.01, 1.02, 1.04))
    }#comp.wres

    plotreg<-function(dx,tr1,lxx,lyy) {
        cc<-xyplot(dx, data=d,
                  panel=function(x,y,subscripts) {
                    if (tr1!="2") tp1<-c("p")
                    if (length(grep("2",tr1))>0) tp1<-c("l")
                    if (length(grep("5",tr1))>0) tp1<-c("p","l")
                    panel.xyplot(x,y,type=tp1,pch=po1,col=co1)                     
                    if (length(grep("1",tr1))>0) panel.loess(x,y,col=LCLR[5],lty=LSTY[5])
                    if (length(grep("3",tr1))>0) panel.abline(0,1,col=LCLR[1],lty=LSTY[1])                                   
                    if (length(grep("4",tr1))>0) panel.abline(h=0,col=LCLR[1],lty=LSTY[1])
                    panel.lmline(x,y,col=LCLR[2],lty=LSTY[2])
                  }, 
                  xlab=sprintf("%s (%s)",lxx,lzi),ylab=lyy,col=co1,pch=po1)
         if (!flagMARGINS) print(cc)
         if ( flagMARGINS) print(cc, pos = c(-0.01, -0.01, 1.02, 1.04))
#rn_titles(rfsr1,rffn1,1,.5)        
                  
    }#plotreg

    lxx<-dn1[3]; lyy<-dn1[1]
    dx<-formula(paste(lyy,"~",lxx,"|","FILE",sep=" ") )
    plotreg(dx,"14",lxx,lyy)

    if (bQU) i0 <- readline("\nWRES analysis...Press KEY to go on")   
    if (bQU) cat("\n***************** WRES STATISTICS *****************\n")
    dx<-formula( paste("~",dn1[1],"|","FILE",sep=" ") )
    plothist(dn1[1],dx)
    if (bQU) compwres(dn1[1])
   
    if (bQU) i0 <- readline(paste("\nPRED.DV analysis...Press KEY to go on"))
    if (bQU) cat("\n***************** PRED.DV STATISTICS *****************\n")
    u1<-2 ; v1<-3 
    if (flagDVPRED) { u1<-3 ; v1<-2  }    
    lxx<-names(d[u1]);lyy<-names(d[v1])
    dx<-formula(paste(lyy,"~",lxx,"|","FILE",sep=" ") )
    reg(u1,v1,lxx,lyy)
    plotreg(dx,"13",lxx,lyy)
    if (bQU) compwres("BIAS") 
    if (bQU) compwres("PRECISION")
}

coplots<-function() {
  options(warn = -1)
  d<-data.frame(); nn<-0 ; bpair<-T; dn2<-dn1; nn<-0
  for (ii in 1:length(rffn1)) {
    dd<-rn_ddd(rfsr1,rffn1[ii],hd1,rfski,rfsp1)    
    if (T) dd<-rn_zero(dd)
    if (ii==1) {
       rfizs<-rn_h22(dd,"variable for data splitting (0 if none)",rfizs)
       if (rfizs[1]!="0") {iz<-rn_ints(rfizs); izn<-names(dd[iz]); dn2<-c(dn1,izn)}
    }
    dd<-subset(dd,select=dn2)
    n1<-length(dd[,1])
    if (nn>0 & n1 != nn) 
        stop("\nDATA UNPAIRED\nTABLES WERE NOT FORMED WITH THE SAME DATA\nEND OF PROGRAM\n")
    nn<-n1    
    dd<-cbind(dd,FILE=rep(rffn1[ii],nn),ID=seq(1,nn))  #cat("\n",dn2,nn,"\n")
    d<-rbind(d,dd)
  } 
  if (rfizs[1]==0) res<-rn_zi123(d,rfizs )
  if (rfizs[1]> 0) res<-rn_zi123(d,4:(3+length(izn)) )
  if (T) {
   library(lattice)
   trellis.device(new=F,color=flagCOLOR)
   background=trellis.par.get("background")
   background$col="white"
   trellis.par.set("background",background)
   rm(background)
  }
  if (flagNLME) library(nlme)
  for (jj in 1:length(res[[1]])) {
     dd<-res[[1]][jj] ;  dd<-dd[[1]]  
     lzn<-res[[2]] ; lzi<-"" 
     if (lzn!="") lzi<-paste(lzn,res[[3]][jj],sep=".")    
     dd<-subset(dd,select=c(dn1,"FILE","ID"))
     if (length(dd[,1])>1) coplot1f(dd,lzi,dn1,TRUE)
     if (F){
      cd<-rn_savenm("nmCOMPRES","GRAPH",rfsr1,rffn1[1],as.character(jj),"pdf")
      pdf(cd, onefile=TRUE)
      if (length(dd[,1])>1) coplot1f(dd,lzi,dn1,FALSE)
      dev.off()
     }
     readline("\nNext...")
  } 
  rm(res)
  return(rfizs)
}
rfizs<-coplots()
return(rfizs)
}

rfizs<-fp1()

rm(fp1,i0,dn1)
rm(flagNLME,flagKW,flagMARGINS,flagLOG10)
rm(LCLR,LSTY)
par(mar=c(4.1,3.1,3.1,1.1),oma=c(0,0,0,0))
