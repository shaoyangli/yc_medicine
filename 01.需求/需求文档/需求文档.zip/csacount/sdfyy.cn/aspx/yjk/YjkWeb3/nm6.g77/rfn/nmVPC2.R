#NONMEM STYLE TABLE FILES
#LEGENDS
lxx<-c("")
lyy<-c("")

#VPC PLOT
#LINE.STYLES 0=none, 1=solid, 2=dashed, 3=dotted
Lmed<-1; Lqt<-1

#OBSERVED LINE COLORS LOWER.QT MEDIAN SUP.QT
COmed<-"darkolivegreen"; COqt<-"darkolivegreen"

#Colors MEDIAN and UP LO QTs = quantile color menu Cqt
#LINE.COLORS  Confidence Interval LO HI
Csd<-4



#VPC2 PLOT
#MEDIAN BOUNDS, WIDTH, CI WIDTHS
Wmd<-2; Wmci<-1
#QT BOUNDS WIDTHS
Wbd<-1 ; Wbci<-1

### X, Y AXES TRANSFORM
#Natural values to LOG10(X) LOG10(Y)
flagLX<-F
flagLY<-F

#Retransform LOG values to NATURAL values (DV,PRED,RES,IPRE,IRES)
#NAT LOGS (Ln(e)=1)
flagLtoN  <-F
#LOG10 (log(10)=1)
flagL10toN<-F

#Print all time-DV OBS and percentiles DEFAULT=F
flagPRDVPERC<-F

#Log(x) or Log(TIME) scale to see time sampling distribution
#NATURAL X AXIS
optVPC2LX<-""
#X AXIS LOG SCALE
#optVPC2LX<-"x"

#ASK FOR X HEADER
flagASKx<-F

############################ DO NOT MODIFY ################################
#RESERVED

cat("\nVISUAL PREDICTIVE CHECK")
cat("\nSIMULATION file PLUS OBSERVED DVs file")
cat("\nOriginal data file = NONMEM file created by $TABLE containing original DV\n\n")

options(warn=-1)
rr<-rn_opt(T,T);rfsp1<-rr[[1]];rfski<-rr[[2]];hd1<- rr[[3]];rm(rr)

#READ FILES. ASK SPLIT VAR
rfsr1 <- rn_dir(rfsr1)
rffn1[2] <- rn_f11("SIMULATION DATA FILE",rffn1[2])
d<-rn_ddd(rfsr1,rffn1[2],hd1[2],rfski,rfsp1)
cat("SIMULATION Table Header for x\n")
if (!flagASKx) cat("TIME is selected by default\n")
if ( flagASKx) rfxy[1] <- rn_h22(d,"X or TIME",rfxy[1])
if (!flagASKx) rfxy[1] <- rn_h22(d,"TIME",rfxy[1])
rfxy[2] <- rn_h22(d,"DV",rfxy[2])
rfxy<-as.integer(rfxy)

ONLYSIM<-F
rffn1[1] <- rn_f11("\nOBSERVATION DATA FILE",rffn1[1])
ONLYSIM<-(rffn1[1]=="..")
if (!ONLYSIM) {
 da<-rn_ddd(rfsr1,rffn1[1],hd1[1],rfski,rfsp1)
 cat("OBSERVATION Table Header for x\n")
 if (!flagASKx) cat(names(d[rfxy[1]])," is selected by default\n")
 if ( flagASKx) rfx <- rn_h22(da,"X or TIME",rfx)
 if (!flagASKx) rfx <- rn_h22(da,names(d[rfxy[1]]),rfx)
 rfy<-rn_h22(da,"DV",rfy)
}
####END READ FILES

cat("\nConditioning variable(s) for data splitting\n(Answer 0 if none)\n")
rfizs<-rn_izs(d,"SIMULATION table, HEADERS",rfizs)

ngr<-1; iz <-0; ig <-0; niz<-1

ngr<-1; iz <-0; ig <-0;niz<-1
   if (rfizs[1]!=0) iz<-rn_ints(rfizs)
   if (rfizs[1]!=0) niz<-length(iz)
   ngr<-0
   if (iz>0) ngr<-length(unique(d[,iz]))
   if (ngr==0) ngr<-1
   if (ngr==0) iz <-1
   if (iz!=0) {
     igs<-frn_rfizs(da,"DATA table, HEADERS",igs)
     ig<-rn_ints(igs)
   }
#CHECK SPLITTING

vpc2<-function () {

ncs<-length(d)
for (ii in 1:ncs) {
       d[,ii] <- as.vector(d[,ii])
       d[,ii] <- as.double(d[,ii])
}
d <- subset(d,!is.na(d[,1]))      
if (flagDELDV0) d <-rn_zero(d)
if (flagDELDV0) da<-rn_zero(da)
ti1<-as.integer(rfx)
dv1<-as.integer(rfy)

#tim<-numeric()
TIM<-list()

#figs common
     sm1<-flagSMOOTH; po1<-46; if (!flagPTS) po1=1
     ilg="" ; if (flagLX) ilg<-"x"; if (flagLY) ilg<-"y"
     if (flagLX & flagLY) ilg<-"xy"

vpoints<-function(d,u1,v1) {
   tt1<-which(names(d)=="ID"); id1<-NA; if (length(tt1)>0) id1<-d$ID                    
   po1<-46; if (!flagPTS) po1=1
   x<-d[,u1];y<-d[,v1]
   if (!flagID)points(x,y,col=1,pch=po1)
   if (flagID & !is.na(id1)) text(x,y,as.character(id1),cex=.75)
   if (flagIDLINK & !is.na(id1)) {
              id<-unique(id1)               
              for (jj in 1:length(id)) {
                  di<-subset(d,d$ID==id[jj])
                  if ( length(di[,1]) >1) lines(di[,u1],di[,v1],col=5,lty=3)
              }  
   }
}


fglg<-function(ii,nmg){
     lx<-lxx;ly<-lyy
     if (lxx=="") lx<-names(da[ti1])
     if (lyy=="") ly<-"DV"
     if (length(lxx)>1 & length(lxx)>=ii) lx<-lxx[ii]   
     if (length(lyy)>1 & length(lyy)>=ii) ly<-lyy[ii]   
     mtext(paste(lx,"  [",nmg,"]"),side=1,line=2)
     mtext(ly,side=2,line=2.1)
}

fg2<-function(dfg2,ii,xu12,yu12, tr11, nmg, X,YO, dev0,tit1){  
     if (length(dev.list())==0) x11(width=5,height=5)    
     if (dev0=="") dev.set(2)
     cat("\nDevice 2\nSYMBOLS OBSERVED DATA\nLINES, LOWER, INTERMEDIATE, UPPER PERCENTILES")
     try(cat("\nBASED ON SIMULATION ",Cqt,Cmd,Cqt))
     try(cat("\nBASED ON OBSERVATION",COqt,COmed,COqt,"\n"))
     if (tr11==0) dg1<-subset(dfg2,TYPE=="RAW")
     if (tr11>0 ) dg1<-subset(dfg2,TYPE=="SMOOTH")
     if (ilg=="y") dg1<-subset(dg1,SIM.L2>0,OBS.L2>0)
     if (length(xu12)<2) xu12<-c(min(dg1$SIM.x,X,na.rm=T),max(dg1$SIM.x,X,na.rm=T))
     if (length(yu12)<2) yu12<-c(min(dg1$SIM.L2,YO,na.rm=T),max(dg1$SIM.H2,YO,na.rm=T))
     par(mar=c(2.5,2.5,.5,.5),oma=c(1,1,0,0))
     if (tit1) par(mar=c(2.5,2.5,2.5,.5),oma=c(1,1,0,0))
     plot(0,0, type="n",xlab="",ylab="",xlim=xu12,ylim=yu12,log=ilg)
     if (tit1){ mtext(side=3,paste("simulated data :",rffn1[2]),line=1.5)
                mtext(side=3,paste("observed  data :",rffn1[1]),line=0.5) }
     tr22<-factSIM*tr11 
     lines(dg1$SIM.x,dg1$SIM.L2,col=Cqt,lty=Lqt)
     lines(dg1$SIM.x,dg1$SIM.M2,col=Cmd,lty=Lmed)
     lines(dg1$SIM.x,dg1$SIM.H2,col=Cqt,lty=Lqt)
     lines(dg1$OBS.x,dg1$OBS.L2,col=COqt,lty=Lqt)
     lines(dg1$OBS.x,dg1$OBS.M2,col=COmed,lty=Lmed)
     lines(dg1$OBS.x,dg1$OBS.H2,col=COqt,lty=Lqt)
     #points(X,YO, pch=po1) 
     vpoints(da,rfx,rfy)
     fglg(ii,nmg)
}#PLOT


fg3<-function(dfg3,ii,xu12,yu12, tr11, nmg, dev0,tit1){      
     cat("\nDevice 3. SIMULATED DATA\nWITH BOOTSTRAPPED CONFIDENCE INTERVAL")
     cat("\nLINES, LOWER, INTERMEDIATE, UPPER PERCENTILES")
     try(cat("\nSIMULATION ",Csd,Cmd,Csd,"\n"))
     if (length(dev.list())==1) x11(width=5,height=5)
     if (dev0=="") dev.set(3)
     if (tr11==0) ds<-subset(dfg3,TYPE=="RAW")
     if (tr11> 0) ds<-subset(dfg3,TYPE=="SMOOTH")
     if (ilg=="y") ds<-subset(ds,SIM.L1>0)
     x<-ds$SIM.x
     if (length(xu12)<2) xu12<-c(min(x,na.rm=T),max(x,na.rm=T))
     if (length(yu12)<2) yu12<-c(min(ds$SIM.L1,na.rm=T),max(ds$SIM.H3,na.rm=T))
     par(mar=c(2.5,2.5,.5,.5),oma=c(1,1,0,0))
     if (tit1) par(mar=c(2.5,2.5,1.5,.5),oma=c(1,1,0,0))
     plot(0,0, type="n",xlab="",ylab="",xlim=xu12,ylim=yu12,log=ilg)
     if (tit1) mtext(side=3,paste("simulated data :",rffn1[2]),line=.5)
     tr22<-factSIM*tr11 
     lines(x,ds$SIM.L2,col=Csd,lwd=Wbd)
     lines(x,ds$SIM.M2,col=Cmd,lwd=Wmd)
     lines(x,ds$SIM.H2,col=Csd,lwd=Wbd)
     lines(x,ds$SIM.L1,col=Csd,lty=3,lwd=Wbci)
     lines(x,ds$SIM.M1,col=Cmd,lty=2,lwd=Wmci)
     lines(x,ds$SIM.H1,col=Csd,lty=3,lwd=Wbci)
     lines(x,ds$SIM.L3,col=Csd,lty=3,lwd=Wbci)
     lines(x,ds$SIM.M3,col=Cmd,lty=2,lwd=Wmci)
     lines(x,ds$SIM.H3,col=Csd,lty=3,lwd=Wbci)
     fglg(ii,nmg)
}#PLOT

fg4<-function(dfg2,dfg3,ii,xu12,yu12, tr11, nmg,dev0,tit1){      
     cat("\nDevice 4.OBS.SIM.\nOBSERVED DATA, LOWER, INTERMEDIATE, UPPER PERCENTILES")
     try(cat("\nOBSERVED, PC CURVES",Csd,Cmd,Csd))
     cat("\rfBOOTSTRAPPED CONFIDENCE INTERVAL FROM SIMULATED DATA\n")
     if (length(dev.list())==2) x11(width=5,height=5)
     if (dev0=="") dev.set(4)
     if (tr11==0) ds<-subset(dfg3,TYPE=="RAW")
     if (tr11>0 ) ds<-subset(dfg3,TYPE=="SMOOTH")
     if (tr11==0) d1<-subset(dfg2,TYPE=="RAW")
     if (tr11>0 ) d1<-subset(dfg2,TYPE=="SMOOTH")
     if (ilg=="y") ds<-subset(dsim,SIM.L1>0)
     if (length(xu12)<2) xu12<-c(min(ds$SIM.x,na.rm=T),max(ds$SIM.x,na.rm=T))
     if (length(yu12)<2) yu12<-c(min(ds$SIM.L1,na.rm=T),max(ds$SIM.H3,na.rm=T))
     par(mar=c(2.5,2.5,.5,.5),oma=c(1,1,0,0))
     if (tit1) par(mar=c(2.5,2.5,2.5,.5),oma=c(1,1,0,0))
     plot(0,0, type="n",xlab="",ylab="",xlim=xu12,ylim=yu12,log=ilg)
     if (tit1){ mtext(side=3,paste("simulated data :",rffn1[2]),line=1.5)
             mtext(side=3,paste("observed  data :",rffn1[1]),line=0.5) }
     tr22<-factSIM*tr11 
     lines(d1$OBS.x,d1$OBS.L2,col=Csd,lwd=Wbd)
     lines(d1$OBS.x,d1$OBS.M2,col=Cmd,lwd=Wmd)
     lines(d1$OBS.x,d1$OBS.H2,col=Csd,lwd=Wbd)
     lines(ds$SIM.x,ds$SIM.L1,col=Csd,lty=3,lwd=Wbci)
     lines(ds$SIM.x,ds$SIM.M1,col=Cmd,lty=2,lwd=Wmci)
     lines(ds$SIM.x,ds$SIM.H1,col=Csd,lty=3,lwd=Wbci)
     lines(ds$SIM.x,ds$SIM.L3,col=Csd,lty=3,lwd=Wbci)
     lines(ds$SIM.x,ds$SIM.M3,col=Cmd,lty=2,lwd=Wmci)
     lines(ds$SIM.x,ds$SIM.H3,col=Csd,lty=3,lwd=Wbci)
     fglg(ii,nmg)
}#PLOT

fg2DATA<-function(tr11,ds,d1){    
     tr22<-factSIM*tr11; sm1<-flagSMOOTH
     les<-max(length(ds[,1]));leo<- max(length(d1[,1]))
     d11<-d1; if (les-leo>0) d11[(leo+1):les,]<-NA
     dss<-ds; if (leo-les>0) dss[(les+1):leo,]<-NA
     dfg2<-cbind(TYPE="RAW",dss,d11);rm(dss,d11)
     if (tr11>0) {
        L2<-rn_smooth0(sm1,tr22,ds$SIM.x,ds$SIM.L2)$y
        M2<-rn_smooth0(sm1,tr22,ds$SIM.x,ds$SIM.M2)
        H2<-rn_smooth0(sm1,tr22,ds$SIM.x,ds$SIM.H2)$y
        ds2<-data.frame(SIM.x=M2$x,SIM.L2=L2,SIM.M2=M2$y,SIM.H2=H2)
        L2<-rn_smooth0(sm1,tr22,d1$OBS.x,d1$OBS.L2)$y
        M2<-rn_smooth0(sm1,tr22,d1$OBS.x,d1$OBS.M2)
        H2<-rn_smooth0(sm1,tr22,d1$OBS.x,d1$OBS.H2)$y
        do2<-data.frame(OBS.x=M2$x,OBS.L2=L2,OBS.M2=M2$y,OBS.H2=H2)
        if (les-leo>0) do2[(leo+1):les,]<-NA
        if (leo-les>0) ds2[(les+1):leo,]<-NA
        dfg2<-rbind(dfg2,cbind(TYPE="SMOOTH",ds2,do2)) 
     }
     return(dfg2)
}#PLOT


fg3DATACI<-function(tr11,dci,dsim){      
     tr22<-factSIM*tr11; sm1<-flagSMOOTH
     x<-dci$x
     names(dci)<-paste("SIM",names(dci),sep=".")
     dfg3<-cbind(TYPE="RAW",dsim,subset(dci,select=-1))
     if (tr11>0) {
        SIM.L1<-rn_smooth0(sm1,tr22,x,dci$SIM.L1)$y
        L2<-rn_smooth0(sm1,tr22,x,dsim$SIM.L2)$y
        SIM.L3<-rn_smooth0(sm1,tr22,x,dci$SIM.L3)$y
        SIM.H1<-rn_smooth0(sm1,tr22,x,dci$SIM.H1)$y
        H2<-rn_smooth0(sm1,tr22,x,dsim$SIM.H2)$y
        SIM.H3<-rn_smooth0(sm1,tr22,x,dci$SIM.H3)$y
        SIM.M1<-rn_smooth0(sm1,tr22,x,dci$SIM.M1)$y
        M2<-rn_smooth0(sm1,tr22,x,dsim$SIM.M2)
        SIM.M3<-rn_smooth0(sm1,tr22,x,dci$SIM.M3)$y
        d2<-data.frame(TYPE="SMOOTH",SIM.x=M2$x,SIM.L2=L2,SIM.M2=M2$y,SIM.H2=H2,SIM.L1,SIM.L3,SIM.M1,SIM.M3,SIM.H1,SIM.H3)
        dfg3<-rbind(dfg3,d2)
     }
     return(dfg3)
}#

mkTclass <- function(xx,xtc,tim,yy) {
         fpl1<-function(tim) {
               par(mar=c(3.5,3.5,.5,.5),oma=c(0,0,0,0))
               layout(matrix(1:2,2,1))
               nt<-length(tim);y1<-rep(c(1,.9,.8),round(nt/2));y1<-y1[1:nt]
               plot(xx,yy,xlab="",ylab="",log=optVPC2LX)
               title(xlab=names(da[ti1]),ylab="DV",line=2.1)
               abline(v=tim,col="blue",lty=3)
               text(x=tim,y=max(yy)*y1,sprintf("%.3g",tim),cex=.75) 
               hist(tim,main="",xlab="",ylab="")
               title(xlab=names(da[ti1]),ylab="Frequency",line=2.1)
               layout(1)
         }          
         fgrp1<-function(xtc,tim){
            n1<-1;cat(sprintf("\n%-14s%-8s%-8s%-8s%s",names(da[ti1]),"from","to","N","mid.t"))
            for (icl in 1:length(tim)) {
                n2 <- max(which(xx<=tim[icl]))
                xtc[n1:n2] <- median(xx[n1:n2]) #sum(xx[n1:n2])/(n2-n1+1)  
                #cat(sprintf("\n<=%-14.4g%-8d%-8d%d",tim[icl],n1,n2,n2-n1+1))
                cat(sprintf("\n<=%-14.4g%-8.3g%-8.3g%-8d%.3g",tim[icl],xx[n1],xx[n2],n2-n1+1,xtc[n1]))
                n1 <- (n2+1)
             }
             return(xtc)
         }
         n10 <- 10
         ntot<-length(xx) 
         n11 <- floor(ntot/n10)-1 #n11 = nb of time classes >=10
         if (n11<2) n11<-2
         nrst<- (ntot %% n10) 
         ii<-0;tg1<-1;n1<-1
         xtc<-as.numeric(xtc)
         #q<-seq(0.05,1,le=n11); cc<-quantile(d$TIME,q); tim<-as.numeric(cc)
         n1 <- 1;
         if (length(tim)==0) for (icl in 1:n11) {
             n2 <- icl*n10 
             if (icl>n11-nrst) n2 <- n1 +n10
             if (icl==n11) n2 <- ntot
             xtc[n1:n2] <- median(xx[n1:n2])#sum(xx[n1:n2])/(n2-n1+1)  
             n1 <- n2+1
             tim[icl]<-xx[n2]
         }
         tim<-unique(tim)
         repeat {  
            fpl1(tim)
            if (length(tim)>1) tim0<-tim
            n11<-length(tim)
            xtc<-fgrp1(xtc,tim)
            #if (flagAUTOGROUP) return(tim,xtc)
            cat("\nBreaks for",n11,"groups values")
            cat("\n\nIndicate the upper limits of each ",names(da[ti1])," group")
            cat("\nActual default values are:\n[",tim0,"]")
            cat("\nNew values must be separated by a space\n")
            i0<-readline("ENTER to accept the [default] or new values\n")
            if (i0=="") return(list(tim,xtc))
            if (i0!="") {
                i0<-strsplit(i0,split=" ")
                tim0<-as.numeric(i0[[1]])  
            }
            tim<-tim0; fpl1(tim); xtc<-fgrp1(xtc,tim)
            i0<-readline("\n\nAccept this time grouping [y] ")
            if (!(i0 != "" & i0 != "y")) break
        }#repeat  
        return(list(tim,xtc))
}

mktgroups <- function (d,iz,jj) {   
       dz<-1     
       dd<-d    
       if (iz>0) dz<-unique(d[,iz])
       if (iz>0) dd<-subset(d,d[,iz]==dz[jj]) 
       return(dd)
}

mkPERC <- function(dd,ti1,dv1,xt0,pc,nm1) {
       x<-unique(xt0) ; ntt<-length(x)
       L2<-numeric(ntt); M2<-numeric(ntt); H2<-numeric(ntt)
       if (flagPRDVPERC) fm1<-"%-11.4g%-11d%-11.3g%-11.3g%.3g\n"        
       for (ii in 1:ntt) {
           dt<-subset(dd,dd[,ti1]==x[ii]) 
           L2[ii]<-quantile(dt[,dv1],pc[1])
           M2[ii]<-quantile(dt[,dv1],pc[2])
           H2[ii]<-quantile(dt[,dv1],pc[3])
           if (flagPRDVPERC) cat(sprintf(fm1,x[ii],length(dt[,dv1]),L2[ii],M2[ii],H2[ii]))
       }
       d2<-data.frame(x,L2,M2,H2);names(d2)<-paste(nm1,names(d2),sep=".")
       return(d2)
}

cal.conf.int <- function(pc,dd,ti1,dv1,xt0,rfBOOT,conf11) {
       ptm<-proc.time()
       try(library(boot))
       xt<-unique(xt0);  ntt<-length(xt)
       y3lo<-numeric(ntt); y1lo<-numeric(ntt)
       y2lo<-numeric(ntt); y3hi<-numeric(ntt)
       y1hi<-numeric(ntt); y2hi<-numeric(ntt)
       for (ii in 1:ntt) {
           dt<-subset(dd,dd[,ti1]==xt[ii])
           x<-dt[,dv1]   
           cat("\n.Computing...",ii,"of",ntt)
           y<-boot(x, function(x,i) quantile(x[i],pc),R=rfBOOT) 
           yci<-boot.ci(y, conf=conf11, t0 = y$t0[1], t = y$t[,1],type="perc")
           y1lo[ii]<-yci$perc[4];y1hi[ii]<-yci$perc[5]
           yci<-boot.ci(y, t0 = y$t0[2], t = y$t[,2],type="perc")
           y2lo[ii]<-yci$perc[4];y2hi[ii]<-yci$perc[5]
           yci<-boot.ci(y, t0 = y$t0[3], t = y$t[,3],type="perc")
           y3lo[ii]<-yci$perc[4];y3hi[ii]<-yci$perc[5]
       }
       cat("\n\nCPU TIME",(proc.time()-ptm)[1]/60,"min\n\n")
       #return(list(xt,y1lo,y1hi,y2lo,y2hi,y3lo,y3hi))
       return(data.frame(x=xt,L1=y1lo,L3=y1hi,M1=y2lo,M3=y2hi,H1=y3lo,H3=y3hi)) 
}

medDV <- function(pc,lxx,lyy,xu12,yu12, tr11, nmz,TIM,conf11) {
    nr11<-1;nc11<-1
    layout( matrix (1:nr11*nc11,nr11,nc11) )
    for (jj in 1:ngr) {
       nmg<-"";nm1<-""
       if (length(TIM)< jj) tim<-numeric()
       if (length(TIM)>=jj) tim<-TIM[[jj]]
       d<-d[order(d[,rfxy[1]]),]
       dd<-mktgroups(d,iz,jj)
       if (length(dd[,1])==0) next 
       if (ngr>1) nmg<-paste(nmz,unique(dd[,iz]))
       if (ngr>1) nm1<-paste(nm1,unique(dd[,iz]),sep="")
       if (ngr>1) cat("\nSorting condition",nmg)         
       fm1<-"\n%-11s%-11sDV[%-8.3gDV[%-8.3gDV[%.3g]\n"
       if (flagPRDVPERC) cat(sprintf(fm1,"t","N",pc[1],pc[2],pc[3]))
       dpsim<-mkPERC(dd,rfxy[1],rfxy[2],dd[,rfxy[1]],pc,"SIM")
       da<-da[order(da[,ti1]),]
       dv<-mktgroups(da,ig,jj)
       xx<- dv[,ti1];       yy<- dv[,dv1];       xtc <- xx
       res<-mkTclass(xx,xtc,tim,yy)
       tim<-res[[1]];       xtc<-res[[2]];       cat("\n") 
       dv<-cbind(dv,XTC=xtc)
       ti11<-length(dv)
       dpobs<-mkPERC(dv,ti11,dv1,xtc,pc,"OBS")
       #PLOTS
       dfg2<-fg2DATA(tr11,dpsim,dpobs)
       fg2(dfg2,ii,xu12,yu12, tr11, nmg, xx,yy,"",F)      
       cat("\n\nConf. Intervals lines based on simulations\nThis may be computer-intensive")
       cat("\n\nThe process can be seen by clicking in the window or descending the vertical scroller")
       cat("\nThe bootstrap will proceed only if n.resamplings > 9")
       i0<-readline(sprintf("\nNumber of resamplings [ %d ] ",rfBOOT))      
       if (i0!="") rfBOOT<-as.integer(i0)
       bBOOT <- rfBOOT > 9
       if (bBOOT) {
          i0<-readline(sprintf("\nConfidence Interval (0.01 - 0.99) [ %.4g ] ",conf11))      
          if (i0!="") conf11<-as.numeric(i0)
          try(library(boot))
          dci<-cal.conf.int(pc,dd,rfxy[1],rfxy[2],dd[,rfxy[1]],rfBOOT,conf11)
          dfg3<-fg3DATACI(tr11,dci,dpsim)
          fg3(dfg3, jj,xu12,yu12, tr11, nmg,"",F)
          fg4(dfg2,dfg3,ii,xu12,yu12, tr11, nmg,"",F)  
       }
       i0 <- readline(paste("\nModif. X axis, Min Max "))
       if (i0!="") {
          xu12<-strsplit(i0,split=" ")
          xu12<-as.numeric(xu12[[1]])
       }
       i0 <- readline(paste("Modif. Y axis, Min Max "))
       if (i0!="") {
          yu12<-strsplit(i0,split=" ")
          yu12<-as.numeric(yu12[[1]])
       }
       repeat { #TUNING
        cat("\nLOOP to improve graphical aspect, no input modification will stop the loop") 
        cat("\nSpline control value, v (v is the smoother span)") 
        cat("\nThis gives the proportion of points in the plot")
        cat("\nwhich influence the smooth at each value")
        cat("\nLarger values give more smoothness (typical 0.66)")
        ii0 <- readline(paste("\nv = 0 -> Interpol\nv > 0 -> Spline\nv [",tr11,"] "))
        if (ii0 != "") tr11<-as.numeric(ii0)
        dfg2<-fg2DATA(tr11,dpsim,dpobs)
        fg2(dfg2,ii,xu12,yu12, tr11, nmg, xx,yy,"",F)      
        if (bBOOT) {
           dfg3<-fg3DATACI(tr11,dci,dpsim)
           fg3(dfg3, jj,xu12,yu12, tr11, nmg,"",F)
           fg4(dfg2,dfg3,ii,xu12,yu12, tr11, nmg,"",F)     
        }
        if (ii0 == "") break
       }

       cd<-rn_savenm("nmVPC2","DATA_FIG2",rfsr1,rffn1[2],nm1,"txt")        
       write.table(dfg2,file=,cd,sep="\t",row.names=F)
       if (bBOOT){ 
         cd<-rn_savenm("nmVPC2","DATA_FIG3_CI",rfsr1,rffn1[2],nm1,"txt")        
         write.table(dfg3,file=,cd,sep="\t",row.names=F)
       }  
       if (T) {
        n1<-sprintf("GRAPH_%s_nmVPC2.pdf",nmg);cd<-paste(rfsr1,n1,sep="/")                 
        cd<-rn_savenm("nmVPC2","GRAPH",rfsr1,rffn1[2],nm1,"pdf")        
        pdf(cd, onefile=T)
        fg2(dfg2,ii,xu12,yu12, tr11, nmg, xx,yy,"pdf",T)      
        if (bBOOT) fg3(dfg3, jj,xu12,yu12, tr11, nmg,"pdf",T)
        if (bBOOT) fg4(dfg2,dfg3,ii,xu12,yu12, tr11, nmg,"pdf",T)     
        dev.off()
       }
       TIM[[jj]]<-tim
       if (jj<ngr) cc<-readline(paste("\nFiles",rffn1,", next sorting condition..."))
    }#jj 1 ngr 
    return(list(tr11,TIM,rfBOOT,conf11))
}

xu12<-"";yu12<-""
tr11<-0
conf11<-0.95
if (flagL10toN) {
       d[,rfxy[2]]<-10**d[,rfxy[2]]
       da$DV     <-10**da$DV
}
if (flagLtoN) {
       d[rfxy[,2]]<-exp(d[rfxy[,2]])
       da$DV     <-exp(da$DV)
}

repeat {
     nmz<-""
     if (ngr[1]>1) nmz<-names(da[ig])
     fi11<-function(nm1,deft) {
         i0<-readline(paste(nm1,"[",deft,"] "))
         if (i0 != "") deft<-i0
         return(deft)
     }     
     if (F) {
      cat("\nPercentiles for LOWER, MIDDLE, UPPER curves\n")
      pc[1]<-fi11("for LOWER  curve",rfqt[1])
      pc[2]<-fi11("for MIDDLE curve",rfqt[2])
      pc[3]<-fi11("for UPPER  curve",rfqt[3]) 
      rfqt<-as.numeric(pc)
     }
     if (T) {
      pi1<-as.numeric(rfqt[3])-as.numeric(rfqt[1])
      cat(sprintf("\nPrediction interval, PI %.3g, between lower %s and upper %s curves",pi1,rfqt[1],rfqt[3]))
      cat("\nMedian curve defined as the PI median,",rfqt[2],"\n")
      pi1<-as.numeric(fi11("PI",pi1))
      p1<-(1-pi1)/2;p3<-pi1+p1;p2<-pi1/2+p1; rfqt<-as.character(c(p1,p2,p3))
      cat(sprintf("\nLOWER %.3g, MEDIAN %.3g, UPPER %.3g percentile curves\n",p1,p2,p3))
     } 
     res<-medDV(c(p1,p2,p3),lxx,lyy,xu12,yu12,tr11,nmz,TIM,conf11) 
     tr11<-res[[1]];TIM<-res[[2]];rfBOOT<-res[[3]];conf11<-res[[4]]
     i0<-readline("\n\nREDEFINE PLOTS, CONTINUE ? [y] ")
     if (i0 != "" & i0 != "y") break
}
}

vpc2()

rm(vpc2,d,da,ngr,iz ,ig, niz, hd1, lxx,lyy, ONLYSIM)
rm(Wmd,Wmci,Wmed,Wbd,Wbci,COmed,COqt,hd1)
rm(optVPC2LX,flagASKx)
rm(flagPRDVPERC,flagLX,flagLY,flagLtoN,flagL10toN)
rm(Clo,Chi,Llo,Lmed,Lhi)
par(mar=c(4.1,3.1,3.1,1.1),oma=c(0,0,0,0))
