#NONMEM TABLE FILES
flagNM<-TRUE

############################ DO NOT MODIFY ################################
#RESERVED

cat("\nFor WFN.nmgo users")
cat("\nIndicate runname (without ext.) then SPECIFIC TABLE")
cat("\nIf only runname, the .fit file will be opened by default\n")
cat("\nExample, Filename [ ]  theoph1 pkcovtable1")
cat("\nExample, Filename [ ]  theoph1\n")

cat("\nCORRELATIONS/ANOVA analyses for NONMEM tables data")
cat("\nThe TABLE data is reduced to 1 UNIQUE occurence of each specific data row")
cat("\ni.e, duplicate rows are deleted")
cat("\nTo disable this, turn the flagUNI to FALSE\n")

options(warn=-1)
rr<-rn_opt(T,T);rfsp1<-rr[[1]];rfski<-rr[[2]];hd1<- rr[[3]];rm(rr)

#READ FILES. ASK SPLIT VAR
rfsr1 <- rn_dir(rfsr1);rffn1 <- rn_f11("",rffn1)
d<-rn_ddd(rfsr1,rffn1,hd1,rfski,rfsp1);rm(hd1)
####END READ FILES
ncs<-length(d)
for (ii in 1:ncs) {
       d[,ii] <- as.vector(d[,ii])
       d[,ii] <- as.double(d[,ii])
}
d <- subset(d,!is.na(d[,1]))  

#DELETE ZERO DV VALUES
if (flagUNI) d<-unique(d)

cat("\nHEADER number for Y variable\n")
cat("answer 999 to rn_ the covariance matrix between items selected to the next prompt\n")
cat("\n");rfy<-rn_h22(d,"for Y variable(s)",rfy)
iiy<-rn_ints(as.character(rfy))
cat("\n");rfizs<-rn_h22(d,"for X variable(s)",rfizs)
iz<-rn_ints(rfizs)

if (TRUE) {

cat("\nDelete zeros for",names(d[iz]))
i0<-readline("\n(y/n)? n ")
if (i0 == "") i0<-"n"
if (i0 == "y") for (ii in 1:length(iz)) {d<-subset(d, d[,iz[ii]] != 0)}
if (iiy[1]!=999) {
   i0 <- readline(paste("\Delete zeros for",names(d[iiy]),"(y/n)? n "))
   if (i0 == "") i0<-"n"
   if (i0 == "y") for (ii in 1:length(iy)) {d<-subset(d, d[,iiy[ii]]!= 0)}
}
}

if (iiy[1]!=999) {
 i0 <- readline(paste("\n6.REGRESSION (6k for Kendall or 6s for Spearman)\n7.ANOVA\n[",rfrp1,"] "))
 if (i0 != "") rfrp1<-i0
 bcor<-(length((which("6"==rfrp1)))==1); baov<-(length((which("7"==rfrp1)))==1)
 rfrp11<-"7" ; if (bcor) rfrp11<-"6" ; rm(bcor,baov)
}#999

cov1n <- function(x,y,xl,yl,a,b,r,mod,bPDF,ii,kk) {
        tt1<-which(names(d)=="ID"); id1<-NA; if (length(tt1)>0) id1<-(d$ID)               
        ilg<-""; rfpo1<-46;if (!flagPTS) rfpo1=1;if (flagID & !is.na(id1)) rfpo1<-"." 
        plot(x,y,type="n",xlab="",ylab="",log=ilg)
        if (!flagID) points(x,y,pch=rfpo1)
        mu<-a + b*x          
        if (!is.na(a) & !is.na(b)) abline(coef(mod),col=Crg,lty=Lrg)
        ss<-paste("r",format(r,digits=3))
        title(ss,cex.main=.9,font.main=1,adj=0)
        if (FALSE) {
             vv<-var(y);qlow<-qnorm(.05,mu,sqrt(vv));qhig<-qnorm(.95,mu,sqrt(vv))
        }
        if (FALSE) {
          pp=predict.lm(mod,interval=c("confidence"),level=.95)
          qlow<-pp[,2]; qhig<-pp[,3]
        }
        lines(lowess(x,y),col=Csl,lty=Lsl)
        #lines(x,y,col=0,lty=Lsl,panel.smooth(x,y,span=rfSMOOTH,col.smooth=Csl,lty.smooth=Lsl,,pch=""))
        if (flagIDLINK & !is.na(id1)) {
           id<-unique(id1)               
           for (jj in 1:length(id)) {
               dd<-subset(d,d$ID==id[jj])
               if (length(dd[,1])>1) lines(dd[,iz[ii]],dd[,iiy[kk]],col=5,lty=3,pch=po1)
           }  
        }
        if (flagID & !is.na(id1)) text(x,y,as.character(id1),cex=.75)
        title(xlab=xl,ylab=yl,line=2)
        li11<-(.5); if (bPDF) li11<-(-1.25); 
        rn_titles(sr1,fn1,1,.75)   
}

fp1n<-function(wr1) {
   par(mar=c(3.5,3.5,1.2,0.5),oma=c(rn_ma1,0,0,0))
   iy<-iiy; ny<-length(iy); nc<-length(iz)*ny 
   nc11<-ceiling(sqrt(nc)); nr11<-ceiling(nc/nc11)
   #n<-nr11*nc11;layout( matrix (1:n,nc11,nr11) )
   n<-nr11*nc11;layout( matrix (1:n,nr11,nc11) )
   bcor<-(length((which("6"==rfrp1)))==1)
   for (kk in 1:ny) {
     y<-d[,iy[kk]];NY<-names(d[iy[kk]])
     if (bcor & wr1) cat(sprintf("\nN=%d, FILE: %s\n",length(y),rffn1))
     if (bcor & wr1) cat(sprintf("\n%-11s%-11s%-11s%-11s%-11s%s\n","Y","X","Y0","SLOPE","r","p"))
     for (ii in 1:length(iz)) {
       x<-d[,iz[ii]]; NX<-names(d[iz[ii]]); names(x)<-NX
       if  (bcor) {
          mod<-glm(y~x);Y0<-coef(mod)[1];SLOPE<-coef(mod)[2]
          if (rfrp1=="6") {
             r <-cor.test(x,y,method="pearson")
             ci<-r[]$conf.int
          }
          if (rfrp1=="6k" ) r <-cor.test(x,y,method="kendall")
          if (rfrp1=="6s" ) r <-cor.test(x,y,method="spearman")
          pv<-(r[]$p.value); nr<-names(r[]$estimate)
          v <-as.numeric(r[]$estimate)
          if (wr1) cat(sprintf("%-11s%-11s%-11.3g%-11.3g%-11.3g%.3g\n",NY,NX,Y0,SLOPE,v,pv))
          cov1n(x,y,NX,NY,Y0,SLOPE,v,mod,!wr1,ii,kk)
       }
       if (wr1 & rfrp1=="7") {
          mod<-lm(y~as.factor(x)); ttt<-(anova(mod))
          cat("\nVariable",NY,", Factor ",names(d[iz[ii]]),unique(x),"\n")
          print(ttt); cc<-boxplot(y~as.factor(x));#print(cc) 
          title(xlab=NX,ylab=NY,line=2)
          li11<-(.5);if (!wr1) li11<-(-1.25); rn_titles(rfsr1,rffn1,1,.75)   
       }                          
     } 
     if (rfrp1=="8" & ii>1) break
   }
   par(mar=c(4.1,3.1,3.1,1.1),oma=c(0,0,0,0))
   if (!wr1) readline("Continue... ")
}

if (iiy[1]!=999) {
    fp1n(TRUE)
    cd<-rn_savenm("nmCORREL","GRAPH",rfsr1,rffn1[1],"","pdf")
    pdf(cd,onefile=T)
    fp1n(FALSE)
    dev.off()
}       

if (iiy[1]==999) {
    d<-subset(d,select=iz)			
    pairs(d,panel=panel.smooth,col.smooth=Csl)
    rn_titles(rfsr1,rffn1,1,.5)
    mod<-cor(d)
    print(mod,digits=3)
    cd<-rn_savenm("nmCORMAT","GRAPH",rfsr1,rffn1[1],"","pdf")
    pdf(cd,onefile=T)
    pairs(d,panel=panel.smooth,col.smooth=Csl)
    rn_titles(rfsr1,rffn1,1,-1.25)
    dev.off()
}

rfrp1<-rfrp11;# rm(rfrp11)
rm(cov1n,mod,y,n,opar,nc11,nr11)
rm(iiy,ii,i0,nc)
rm(Y0,SLOPE,r,v,pv,nr,iz)
