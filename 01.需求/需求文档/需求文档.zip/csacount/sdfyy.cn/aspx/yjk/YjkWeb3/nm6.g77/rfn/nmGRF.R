#NONMEM TABLE FILES
flagNM<-TRUE

#ONLY ONE SCREEN
flagCOPL<-TRUE

############################ DO NOT MODIFY ################################
#RESERVED
flagWFN<-F

cat("\nFor WFN.nmgo users")
cat("\nIndicate runname (without ext.) then SPECIFIC TABLE")
cat("\nIf only runname, the .fit file will be opened by default\n")
cat("\nExample, Filename [ ]  theoph1 pkcovtable1")
cat("\nExample, Filename [ ]  theoph1\n")

#RESERVED
options(warn=-1)
rr<-rn_opt(T,T);rfsp1<-rr[[1]];rfski<-rr[[2]];hd1<- rr[[3]];rm(rr)

#READ FILES. ASK SPLIT VAR
rfsr1 <- rn_dir(rfsr1);rffn1 <- rn_f11("",rffn1)
d<-rn_ddd(rfsr1,rffn1,hd1,rfski,rfsp1);rm(hd1)
####END READ FILES

cat("\n")
rfxy[1] <- rn_h22(d,"for abscissa x",rfxy[1])
rfxy[2] <- rn_h22(d,"for ordinate y",rfxy[2])
ixy<-as.integer(rfxy)
lxx<-names(d)[ixy[1]]
lyy<-names(d)[ixy[2]]

rfizs <- rn_h22(d,"for line (individual) interpolation (0 if none)",rfizs)
rfigs <- rn_h22(d,"conditioning values to split the data",rfigs)
i0 <- readline(paste("\nDelete zeros for Y (y/n)? y "))
if (i0 == "") i0<-"y"
if (i0=="y") d<-subset(d, d[,ixy[2]] != 0)
i0 <- readline(paste("Delete zeros for X (y/n)? y "))
if (i0 == "") i0<-"y"
if (i0=="y") d<-subset(d, d[,ixy[1]] != 0)


fp1 <- function() {
repeat {
 i0 <- readline(paste("\nPlot type\n0.Points\n1.Spline\n2.Interpol (spaghetti)\n3.y=x\n4.y=0\n5.Pts-Interpol\n6.y=a + b.x\n[",rftr1,"] "))
 if (i0 != "") rftr1<-i0
 i0 <- readline(paste("\n0.NoTransf\n1.Log(y)\n2.Log(x)\n3.Log(x,y)\n[",rfrp1,"]"))
 if (i0 != "") rfrp1<-i0
 i0 <- readline(paste("\nSymbols\n1-25.Symbols\n28. '.'\n33.Differents\n[",rfpo1,"] "))
 if (i0 != "") rfpo1<-i0
 i0 <- readline(paste("\nLine Type\n1.Solid\n2.Dashed\n3.Dotted\n[",rfli1,"] "))
 if (i0 != "") rfli1<-i0
 i0 <- readline(paste("\nLine Color\n1.black\n2.red\n3.green\n4.blue\n5.lightblue\n6.purple\n7.yellow\n8.lightgray\n33.Differents\n[",rfco1,"] "))
 if (i0 != "") rfco1<-i0
 cat("\n")

 iz<-rn_ints(rfizs);niz<-length(iz)
 ig<-rn_ints(rfigs); nig<-length(ig)
 ntt<-1;lzz<-NULL
 if (ig[1] > 0) {
  for (ii in 1:nig) {
   lz0 = names(d)[ig[ii]];   ntk<-length(unique(d[,ig[ii]]))
   ntt<-ntt*ntk;  lzz<-c(lzz,lz0)    
  }
  cat("\n","Total nb. of modalities",ntt,"\n"); rm(ii,lz0,ntk) 
 }

 ilg=""; if (rfrp1==1) ilg="y"; if (rfrp1==2) ilg="x"; if (rfrp1==3) ilg="xy"; if (rfrp1==9) ilg="10"
 if (!flagCOPL) layout( 1 )
 if ( flagCOPL) {
           c11<-ceiling(sqrt(ntt));  r11<-ceiling(ntt/c11)
           n<-r11*c11; layout( matrix (1:n,r11,c11) ) 
 }
 if (FALSE) {
  tac<-strsplit(paste(rftr1,collapse=" ")," ")
  tac<-as.integer(tac[[1]])
  coo<-rn_ints(rfco1)
  if (is.na(coo)) coo<-1
  ltac<-length(tac)
  if (length(rfco1)<ltac) coo[length(coo)+1:ltac]<-coo[length(coo)]
  lii<-strsplit(paste(rfli1,collapse=" ")," ")
  lii<-as.integer(lii[[1]])
  if (length(lii)<ltac) lii[length(lii)+1:ltac]<-lii[length(lii)]
 }
 tac<-as.integer(rftr1);coo<-as.integer(rfco1);lii<-as.integer(rfli1)
 px<-as.integer(rfpo1)
 if (px == 28) rfpo1<-"."
 else rfpo1<-px

 fp<-function(dd, nm,ig,xu12,yu12) {
        x<-dd[,ixy[1]]; y<-dd[,ixy[2]]
        x12<-c(min(x),max(x));y12<-c(min(y),max(y))
        if (xu12!="") x12<-xu12
        if (yu12!="") y12<-yu12
        plot(x,y, type="n",xlim=x12,ylim=y12,xlab="",ylab="",log=ilg)
        nid<-1  ;  exx<-list()
        if (iz[1]>0) {
          for (kk in 1:niz) exx[kk]<-list(dd[,iz[kk]])        
          w1<-split(x,exx);w2<-split(y,exx)
          nw<-names(w1);nid<-length(nw)
        } 
        xx   <-x;  yy   <-y 
        for (kk in 1:nid) {      
         if (nid>1) {  xx<-w1[[kk]]; yy<-w2[[kk]] } 
         o   <-order(xx); xx   <-xx[o]; yy   <-yy[o]
         if (rfco1==33) coo<-kk ; if (rfli1==33) lii<-kk 
         po2<-rfpo1 ; kk0<-floor(kk/25); kk0<-kk-kk0*25
         if (rfpo1==33) po2<-kk0 
         
         ii0<-1 
         if (length(which(tac==2))==0) points(xx,yy,pch=po2)
         if (length(which(tac==1))>0) {
            lines(lowess(xx,yy, f=rfSMOOTH),col=coo[ii0],lty=lii[ii0])
            #lines(xx,yy,col=0,lty=lii[ii0],panel.smooth(x,y,span=rfSMOOTH,col.smooth=co2[ii0]))
            ii0<-ii0+1}
         if (length(which(tac==2))>0 | length(which(tac==5))>0 ) {
            lines(xx,yy,col=coo[ii0],lty=lii[ii0])
            ii0<-ii0+1} 
         if (length(which(tac==3))>0) {
            abline(0,1,col=coo[ii0],lii[ii0])
            ii0<-ii0+1}
         if (length(which(tac==4))>0) {
            abline(h=0,col=coo[ii0],lty=lii[ii0])
            ii0<-ii0+1}
         if (length(which(tac==6))>0) {
            if ((ilg == "" | ilg == "xy") & length(xx)>2) {
                mod<-lm(yy~xx); a<-coef(mod)[1]; b<-coef(mod)[2]; mu<-a+b*xx
                if (FALSE) {
                 vv<-var(yy); q.05<-qnorm(.05,mu,sqrt(vv)); q.95<-qnorm(.95,mu,sqrt(vv))
                 if (ilg=="") lines(xx,q.05,col=col.qt1)
                 if (ilg=="") lines(xx,q.95,col=col.qt1)
                }
                abline(a,b,col=coo[ii0]); ii0<-ii0+1
            }
         }
       }
       mtext(nm,side=3,line=.1,cex=.9)  
       mtext(lxx,side=1,line=0,outer=T,cex=.9)
       mtext(lyy,side=2,line=0,outer=T,cex=.9)
       rn_titles(rfsr1,rffn1,1,1.95)
 }
 igd<-""  
 if (ig[1]>0) {
     ex<-list(nig)
     for (kk in 1:nig) ex[kk]<-list(d[,ig[kk]])
     dd<-split(d, ex)
     igd<-dd$ig
 }
 for (ii in 1:ntt) {
        nm<-"";xu12<-""; yu12<-""
        i0 <- readline(paste("\nX axix Legend [",lxx,"]\n"))
        if (i0 != "") lxx<-i0
        i0 <- readline(paste("Y axis Legend [",lyy,"]\n"))
        if (i0 != "") lyy<-i0
        repeat { 
          xu2<-xu12;yu2<-yu12;nm<-""  
          if (ig[1]>0) {
           ni<-strsplit(names(dd[ii]),split="\\.")
           for (jj in 1:nig) nm<-paste(nm,lzz[jj],ni[jj])
          }
          if (ig[1]>0) fp(dd[[ii]], nm, igd, xu12,yu12)
          else fp(d, nm, igd, xu12,yu12)
          cd<-rn_savenm("nmGRF","GRAPH",rfsr1,rffn1,nm,"pdf")
          pdf(cd,onefile=T)
          if (ig[1]>0) fp(dd[[ii]], nm, igd, xu12,yu12)
          else fp(d, nm, igd, xu12,yu12)
          dev.off()
        
          i0 <- readline(paste("\nModif. X axis, Min Max "))
          if (i0!="") {
            xu12<-strsplit(i0,split=" ")
            xu12<-as.numeric(xu12[[1]])
          }
          i0 <- readline(paste("Modif. Y axis, Min Max "))
          if (i0!="") {
            yu12<-strsplit(i0,split=" ")
            yu12<-as.numeric(yu12[[1]])
          }
          bb<-((xu12==xu2) & (yu12==yu2))
          if (sum(bb)/length(bb)==1) break
        }
        cc<-"y" 
        if (!flagCOPL) cc<-readline(paste("Condits.",nm,"Next? (y/n) y "))
        if (cc=="") cc<-"y";if (cc!="y") break         
 }    
cc<-readline("Redo plot (y/n) [ n ] ")
return(list(rftr1,rfco1,rfli1,rfrp1))
if (cc!="y") break
}
}


par(mar=c(2.1,2.1,1.2,0.2),oma=c(rn_ma1+1.1,1.1,0,0))
res<-fp1()
rftr1<-res[[1]];rfco1<-res[[2]];rfli1<-res[[3]];rfrp1<-res[[4]];rm(res)
rm(fp1) ; rm(i0,ixy)
rm(flagWFN,flagNM,flagCOPL)
par(mar=c(4.1,3.1,3.1,1.1),oma=c(0,0,0,0))


