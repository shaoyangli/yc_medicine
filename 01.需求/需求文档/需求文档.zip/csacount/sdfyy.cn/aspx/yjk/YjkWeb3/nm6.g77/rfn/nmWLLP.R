############################ DO NOT MODIFY ################################
#NONMEM TABLE FILES
flagNM<-F

#RESERVED
flagWFN<-T
#END.RESERVED
cat("\nLOG LIKELIHOOD PROFILE utility connected to nmllp\n")
options(warn=-1)
rr<-rn_opt(T,T);rfsp1<-rr[[1]];rfski<-rr[[2]];hd1<- rr[[3]];rm(rr)

#READ FILES. ASK SPLIT VAR
rfsr1 <- rn_dir(rfsr1); 
cat("1st prompt > enter the runname\n2nd prompt > enter the parameter name\n")
rffn1 <- rn_f11("",rffn1)
####END READ FILES
i0<-readline(cat("\nPARAMETER name [",rf_pn1,"] "))
if (i0!="") rf_pn1<-i0 

fp1 <- function(ids,izs,tr1) {

   gr1<-function(x,y) {  
     plot(x,y,xlab="",ylab="")
     lines(x,y,col=4)
     mi1<-min(y)
     y4<-mi1+3.84
     abline(h=mi1,lty=2,col=1)
     abline(h=y4,lty=3,col=1)
     lxx<-rf_pn1
     lyy<-"Obj"
     mtext(lxx,side=1,line=2.25)  
     mtext(lyy,side=2,line=2.25)  
     for (ii in 1:(length(x)-1)) {
         p<-(y[ii+1]-y[ii])/(x[ii+1]-x[ii])
         y0<-y[ii]-p*x[ii]
         x4<-(y4-y0)/p
         if (x4>x[ii] & x4<x[ii+1]) { 
            abline(v=x4,col=2)
            cat(sprintf("\nCrossing %.4g at %s = %.4g",y4,lxx,x4))
         } 
         #if (x4>x[ii] & x4<x[ii+1]) arrows(x4,y4,x4,min(y),col=2)
     }
     cat("\n") 
    } 
    rp1<-0;    po<-1;    tr0<-0
    cat("\nFolders for LLP analysis\n")
    pt1<-paste(getwd(),rfsr1,sep="/")
    pn1<-paste("_",rf_pn1,sep="")
    fi<-grep(pattern=pn1,dir(path=pt1))        
    ff<-dir(pt1)[fi]
    pn2<-paste(".",wfnDIR,sep="")
    fi<-grep(pattern=pn2,ff)     
    ff<-ff[fi]   
    print(ff)
    #GET OFV VALUES
    n2<-length(ff)
    x<-numeric(n2)
    y<-numeric(n2)
    for (ii in 1:n2) {
        f1<-paste(pt1,"/",ff[ii],sep="")
        f2<-sub(pattern=wfnDIR,replacement="smy",ff[ii])
        f1<-paste(f1,f2,sep="/") 
        d1<-read.table(f1,header=TRUE,comment.char="",fill=TRUE)
        x[ii]<-as.numeric(d1[toupper(rf_pn1)])
        y[ii]<-as.numeric(d1$Obj)
     }
     o<-order(x);x<-x[o];y<-y[o]
     par(mar=c(3.5,2.5,1.1,.1),oma=c(0,1.5,.1,.1))
     layout( 1 ); gr1(x,y)
     readline("\nZoom...\n")
     mi1<-min(y)+2*3.84;     y2 <- y[y<mi1]
     o <- y < min(y)+2*3.84;  x2<-x[o]
     gr1(x2,y2)
     #   arrows(zx1,0.6*max(r$density),z01,min(r$density),col="red")
     # mtext(lti,side=3,line=-1)  
     par(mar=c(4.1,4.1,3.1,1.1),oma=c(0,0,0,0))
     return(list(ids,izs,tr1))
}

rps<-fp1(ids,izs,tr1)
rm(fp1,rps)
rm(i0,tot)
rm(sok,nok,d1)
rm(flagNM,flagWFN)
