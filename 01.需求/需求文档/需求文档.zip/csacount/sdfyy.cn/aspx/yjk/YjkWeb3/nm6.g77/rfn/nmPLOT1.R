#REGRESSION OMITTING INTERCEPT
flagNOINTERC<-FALSE

############################ DO NOT MODIFY ################################
#RESERVED
options(warn=-1)
rr<-rn_opt(T,T);rfsp1<-rr[[1]];rfski<-rr[[2]];hd1<- rr[[3]];rm(rr)

#READ FILES. ASK SPLIT VAR
rfsr1 <- rn_dir(rfsr1);rffn1 <- rn_f11("",rffn1)
d<-rn_ddd(rfsr1,rffn1,hd1,rfski,rfsp1);rm(hd1)
####END READ FILES

rfx <- rn_h22(d,"DV",rfx)
if (TRUE) d<-rn_zero(d)

rfizs<-rn_h22(d,"variable for data splitting (0 if none)",rfizs)

fp1<-function () {

fg1 <- function(u1,v1, eq1, bQU) {
       tt1<-which(names(d)=="ID"); id1<-NA; if (length(tt1)>0) id1<-d$ID               
       po1<-46; if (!flagPTS) po1=1;if (flagID & !is.na(id1)) po1<-"." 
       rp1<-0 ; li1<-1; ilg<-"" ; rfx<-as.integer(rfx)
       x<-d[,u1];y<-d[,v1];xl<-names(d[u1]);yl<-names(d[v1])
       plot(x,y,type="n",xlab="",ylab="",lty=li1,pch=po1,log=ilg)
       points(x,y,col=1,pch=po1)
       if (flagID & !is.na(id1)) text(x,y,as.character(id1),cex=.75)
       mod<-lm(y~x);     if ( flagNOINTERC) mod<-lm(y~x - 1)
       a<-coef(mod)[1] ; if (!flagNOINTERC) b<-coef(mod)[2]
       mu<-a + b*x
       if (FALSE) {
             vv<-var(y)
             qlow<-qnorm(.05,mu,sqrt(vv))
             qhig<-qnorm(.95,mu,sqrt(vv))
           lines(x,qlow,col=Cqt,lty=Lqt); lines(x,qhig,col=Cqt,lty=Lqt)
       }
       if (FALSE) {
           pp=predict.lm(mod,interval=c("confidence"),level=.95)
           qlow<-pp[,2];  qhig<-pp[,3]
           lines(x,qlow,col=Cqt,lty=Lqt); lines(x,qhig,col=Cqt,lty=Lqt)
       }
       if (flagIDLINK & !is.na(id1)) {
              id<-unique(id1)               
              for (jj in 1:length(id)) {
                  di<-subset(d,d$ID==id[jj])
                  if ( length(di[,1]) >1) lines(di[,u1],di[,v1],col=5,lty=3)
              }  
       }
       ss<-sprintf("\ny= %.3g + %.3g*x   r= %.3g   N= %i\n",a,b,cor(x, y),length(x) )
       abline(0,1,col=Cid,lty=Lid);  abline(mod,col=Crg,lty=Lrg)
       #if (is.na(a)==F & is.na(b)==F) abline(mod,col=col.reg,lty=2)
       lines(col=Csl,lty=Lsl,lowess(x,y))
       #lines(x,y,panel.smooth(x,y,span=0.5),lty=li1,col=Csl,lty=Lsl)
       #if (eq1) mtext(ss,side=3,line=0,adj=0,cex=.75)
       if (bQU) print(summary(mod))
       title(xlab=xl,ylab=yl,line=2)
}


nmplot1<-function(u1,v1,lzi,bQU) {  
#par(mar=c(3.5,3.5,1.2,0.5),oma=c(rn_ma1,0,0,0))
   fg1(u1,v1, TRUE, bQU)
   x<-d[,u1];y<-d[,v1]; mtext(side=3,outer=T,lzi,u1,v1)
rn_titles(rfsr1,rffn1,1,.75)                
   if (bQU) i0 <- readline(paste("\n","Cook's distance plot (y/n)? n "))
   if (i0 == "") i0<-"n"
   if (i0 == "y" | !bQU) {
     layout(matrix(1:1,1,1))
     if (!flagNOINTERC) regression<-lm(y~x)
     if ( flagNOINTERC) regression<-lm(y~x - 1)
     plot(cooks.distance(regression),type="h",main="Cook's distance plot",font.main=1,cex.main=.75)
     mtext(side=3,outer=T,lzi)
rn_titles(rfsr1,rffn1,1,.5)                
   }
   if (bQU) i0 <- readline(paste("\n","Diagnostic plots (y/n)? n "))
   if (i0 == "") i0<-"n"
   if (i0 == "y" | !bQU) {
        par(mar=c(4.1,4.1,.75,.75),oma=c(rn_ma1,0,1,0))
        layout(matrix(1:4,2,2))
        plot(x,y)
        if (!flagNOINTERC) mo<-lm(y~x)
        if ( flagNOINTERC) mo<-lm(y~x-1)
        abline(mo)
        Residuals<-mo$residuals
        Fitted<-mo$fitted
        plot(Fitted,Residuals)
        abline(h=0)
        hist(Residuals,main="")
        qqnorm(Residuals,main="",xlab="",ylab="")
        qqline(Residuals)
        title(xlab="Theoretical Quantiles",ylab="Sample Quantiles")
        rm(Residuals,Fitted,mo)
        mtext(side=3,outer=T,lzi)
   }
}

nmplots1<-function(d,lzi,bQU) {
  lzi<-paste(lzi,names(d),sep=".")
  d<-d[[1]]
  if (length(d[,1])>1) { 
     d1<-which(names(d)=="DV")
     p1<-which(names(d)=="PRED")
     u1<-d1;v1<-p1
     if (flagDVPRED) {u1<-p1;v1<-d1}
     p2<-which(names(d)=="IPRE")
     bIPRED<-(length(p2)>0)
par(mar=c(3.3,3.3,.75,.75),oma=c(rn_ma1,0,1,0))
     if (bIPRED) {
       u2<-d1;v2<-p2
       if (flagDVPRED) {u2<-p2;v2<-d1}
       layout(matrix(1:2,1,2))
       fg1(u1,v1,FALSE,bQU)
       fg1(u2,v2,FALSE,bQU)
       mtext(side=3,outer=T,lzi)
rn_titles(rfsr1,rffn1,1,.5)                
     }
     if (bQU) readline("Next...PRESS Enter")
par(mar=c(3.1,3.1,1.1,1.1),oma=c(rn_ma1,0,1,0))
     layout(matrix(1:1,1,1))
     nmplot1(u1,v1,paste("PRED",lzi,sep=" "),bQU)
rn_titles(rfsr1,rffn1,1,.5)                
     if (bIPRED) {
       q1<-""; layout(matrix(1:1,1,1))
       if (bQU) q1 <- readline(cat("\nSee IPRED... plots (y/n) [y] "))
       if (q1 == "") q1<-"y"
       if (q1 == "y") nmplot1(u2,v2,paste("IPRED",lzi,sep=" "),bQU)
rn_titles(rfsr1,rffn1,1,.5)                
     }
     if (bQU) readline("Next condtion...")
  } 
}

res<-rn_zi123(d,rfizs)
for (jj in 1:length(res[[1]])) {
     nmplots1(res[[1]][jj],res[[2]],TRUE)
     cd<-rn_savenm("nmPLOT1","GRAPH",rfsr1,rffn1[1],as.character(jj),"pdf")
     pdf(cd, onefile=TRUE)
     nmplots1(res[[1]][jj],res[[2]],FALSE)
     dev.off()
}

}

fp1()
rm(fp1)
#par(mar=c(3.1,3.1,3.1,1.1),oma=c(0,0,0,0))
