#NONMEM TABLE FILES
flagNM<-F

#SELECT COLOR, LINESTYLE
flagCUSTOM<-F

#RESERVED#############DO NOT MODIFY#####################################

cat("\nWINGS WFN.nmbs users")
cat("\nIndicate ctl runname (without .ctl )")

#READ FILES. ASK SPLIT VAR
rfsr1 <- rn_dir2(rfsr1,".bs")
rffn1 <- rn_f11("",rffn1)

cd3<-""; cd4<-""; sr01<-""
if (TRUE) {sr01<-paste(rfsr1,sep="/")
        cd3<-paste(rffn1[1],"bs",sep=".")
        cd4<-paste(rffn1[1],"txt",sep=".")
        cd<-paste(sr01,cd3,cd4,sep="/")    
}
cat("\nWFN OPTION, Try opening",cd3,cd4," files ...\n")
cat("\nOpen file",cd,"\n\n")
d<-try(read.table(cd,header=T,skip=0,comment.char="",na=c(".","NA"),fill=T),silent=T)
rm(cd,cd3,cd4,sr01)


fp1 <- function(rfids,rfizs,rftr1) {

tot<-length(d[,1])
d1<-logical(tot)
sok<-sprintf("\n%-10s%-10s%s\n","Total","Cov.OK.0","Min.SUCCESSFUL")
nok<-length(d$Cov[d$Cov=="OK"])
if (nok==0) sok<-sprintf("%s%-10i%-10i%i\n",sok,tot,length(d$Cov[d$Cov=="NONE"]),length(d$Min[d$Min=="MINIMIZATION_SUCCESSFUL_"]))
if (nok> 0) sok<-sprintf("%s%-10i%-10i%i\n",sok,tot,length(d$Cov[d$Cov=="OK"]),  length(d$Min[d$Min=="MINIMIZATION_SUCCESSFUL_"]))

    if (FALSE) {
    for (ii in 1:length(d)) {
       d[,ii] <- as.vector(d[,ii])
       d[,ii] <- as.double(d[,ii])
    }
    cat(sprintf("\n%d RECORD(S) with NA values have been deleted from the file\n\n",length(subset(d,!is.na(d[,1])))))     
    d <- subset(d,!is.na(d[,1]))     }
    d<-subset(d,select=c(-1,-Eval,-Sig,-Sub,-Eval,-Obs)) 
    tot<-length(d[,1])
    d1<-logical(tot)
    sok<-sprintf("\n%-10s%-10s%s\n","Total","Cov.OK.0","Min.SUCCESSFUL")
    nok<-length(d$Cov[d$Cov=="OK"])
    if (nok==0) sok<-sprintf("%s%-10i%-10i%i\n",sok,tot,length(d$Cov[d$Cov=="NONE"]),length(d$Min[d$Min=="MINIMIZATION_SUCCESSFUL_"]))
    if (nok> 0) sok<-sprintf("%s%-10i%-10i%i\n",sok,tot,length(d$Cov[d$Cov=="OK"]),  length(d$Min[d$Min=="MINIMIZATION_SUCCESSFUL_"]))

    infx<-"n"; supx<-"n"; rp1<-0; po<-1
   
    gr1 <- function(X,lxx,tst2) {
        if (rftr1=="0") {
           hist(X,proba=F,main="",xlab="",ylab="")
           title(xlab=lxx,ylab="",line=2)
           return("frequency")   
        }
        if (rftr1=="1") {
           hist(X,proba=T,main="",xlab="",ylab="")
           if (tst2) lines(density(X,bw=max(X)/24),col="blue")
           title(xlab=lxx,ylab="",line=2)
           return("probability")
        }
        if (rftr1=="2"){
           hist(X,proba=T,main="",xlab="",ylab="")
           title(xlab=lxx,ylab="",line=2)
           if (tst2) m1<-mean(X)
           if (tst2) sd1<-sd(X)
           if (tst2) xxx<-seq(m1-2*sd1,m1+2*sd1,4*sd1/200)
           if (tst2) lines(xxx,dnorm(xxx,mean(X),sqrt(var(X))),col="red")
           return("probability")
        }   
        if (rftr1=="3") {
           qqnorm(X,main="",xlab="",ylab="")
           qqline(X)
           title(xlab=paste(lxx,"Theoret. Qls"),ylab="",line=2)
           return("Sample Quantiles")
        }
        if (rftr1=="4") {
           plot(ecdf(X),do.points=F,verticals=T,main="",xlab="",ylab="")
           title(xlab=lxx,ylab="",line=2)
           return("Proportion<=Estimate")
        }
        if (rftr1=="5") {
           boxplot(X,main="",xlab="",ylab="")
           title(xlab=lxx,line=.5)
           return("")
        }
    }#gr1

    out1 <- function(id,d1,pdf1) {
      pp<-c(.025,.05,.25,.5,.75,.95,.975)             
      PPi<-character(); MMi<-character()
      PPi[1]<-sprintf("%-10s%-10g%-10g%-10g%-10g%-10g%-10g%g","Quantiles",pp[1],pp[2],pp[3],pp[4],pp[5],pp[6],pp[7])
      MMi[1]<-sprintf("%-10s%-10s%-10s%-10s%-10s%s","X","Mean","SD","Median","Min","Max")
      kk<-0
      for (ii in 1:length(id)) {
          X<-as.numeric(d1[[id[ii]]])
          tst2<-length(unique(X))>2
          if (tst2) kk<-kk+1        
      }#ii loop
      nc11<-ceiling(sqrt(kk));nr11<-ceiling(kk/nc11)
      layout(matrix(1:(nc11*nr11),ncol=nc11,nrow=nr11))
      kk<-1
      for (ii in 1:length(id)) {
          X<-as.numeric(d1[[id[ii]]])
          if (infx != "n") X<-X[X > infx]
          if (supx != "n") X<-X[X < supx]
          tst2<-length(unique(X))>2
          if (!tst2) next
          kk<-kk+1
          nm<-names(d[id[ii]])
          MMi[kk]<-sprintf("%-10s%-10.3g%-10.3g%-10.3g%-10.3g%.3g",nm,mean(X),sd(X),median(X),min(X),max(X))
          pq<-as.numeric(quantile(X,pp))
          PPi[kk]<-sprintf("%-10s%-10.3g%-10.3g%-10.3g%-10.3g%-10.3g%-10.3g%.3g",nm,pq[1],pq[2],pq[3],pq[4],pq[5],pq[6],pq[7])
          lyy=gr1(X,names(d[id[ii]]),tst2)  
      }#ii loop
      mtext(lyy,side=2,line=0,outer=T)          
      if (!pdf1) {  
       rn_titles(rfsr1,rffn1,1,.75) 
       cat(sprintf("\nFILE: %s",rffn1))
       cat(paste("\n",MMi))
       cat("\n",paste("\n",PPi))
       cat("\n\nN =",length(X)," / total bootstraps =",tot,"\n")  
       cd<-rn_savenm("nmWBS","DATA",rfsr1,rffn1,"par","txt")
       write.table(MMi, file = cd,row.names=F,quote=F,sep="\t")
       cd<-rn_savenm("nmWBS","DATA",rfsr1,rffn1,"qt","txt")
       write.table(PPi, file = cd,row.names=F,quote=F,sep="\t")
      }
    }#out1           

    repeat {
      dm<-as.character(unique(d$Min))
      ii<-length(dm)
      s1<-0
      sdm<-as.character(d$Min)
      if (ii>10) {
         t1<-"MINIMIZATION_TERMINATED";t2<-"MINIMIZATION_SUCCESSFUL"
         t3<-"PARAMETER_ESTIMATE_IS_NEAR_ITS_BOUNDARY"
         cat("Minimization types for analysis are too numerous",ii)
         cat(sprintf("\nTypes will be limited to\n->%s\n->%s\n->%s\n",t1,t2,t3))
         v3<-grep(pattern=t3,sdm);sdm[v3]<-"PAR_ESTIMATE_IS_NEAR_ITS_BOUNDARY"
         v2<-grep(pattern=t2,sdm);sdm[v2]<-t2
         v1<-grep(pattern=t1,sdm);sdm[v1]<-t1
         d$Min<-sdm
      }
      dm<-unique(sdm) 
      cat(sprintf("\n%-6s%-6s%s","Ref.","N","Response"))     
      for (ii in 1:length(dm)) {
          d0<-length(d$Min[d$Min==dm[ii]]) 
          cat(sprintf("\n%-6i%-6i%s",ii,d0,dm[ii]))
      }
      iz0 <- readline(paste("\nSelect Minimization types for analysis (all=999)\nAnswer 0 to STOP [",rfizs,"] "))
      if (iz0 == "0") break
      if (iz0 != "") rfizs<-iz0
      if (iz0 == "999") {
         rfizs<-""
         for (ii in 1:length(dm)) rfizs<-paste(rfizs,as.character(ii))
      }
      i0<-strsplit(rfizs,split=" ")
      i0<-as.integer(i0[[1]]) 
      d1<-FALSE 
      for (ii in 1:length(i0)) d1<-(d1 | d$Min==dm[i0[ii]])      

      print(paste(1:length(names(d)),names(d),sep='.'))
      cat("\nHEADER number(s) for variables X")
      id0 <- readline(paste("\nAnswer 0 to STOP, HEADERS [",rfids,"] "))
      if (id0 != "") rfids<-id0
      if (rfids[1]!="0") irfids<-rfids    
      if (id0 == "0") break
      i0<-strsplit(rfids,split="-")
      if (length(i0[[1]])<2) i0<-strsplit(rfids,split=":")
      if (length(i0[[1]])>1) {
         i0<-as.integer(i0[[1]])
         n1<-as.integer(i0[1])
         n2<-as.integer(i0[2])
         id<-n1:n2
      } 
      else {
        i0<-strsplit(rfids,split=" ")
        id<-as.integer(i0[[1]])
      }
      if (id[1]==0) break
      if (!flagCUSTOM) rftr1<-2
      if ( flagCUSTOM) { 
       tr0 <- readline(paste("\n0.Histogram\n1.Histogram-Smooth\n2.Hist/Normal\n3.Quantiles\n4.Cumm. Empirical Distr.\n5.Boxplots\n[",rftr1,"] "))
       if (tr0 != "") rftr1<-tr0
       tr0<-rftr1
      }
      par(mar=c(3.5,2.5,.5,.5),oma=c(0+rn_ma1,1.5,.1,.1))
      d<-cbind(d,TEST=d1)
      d1<-subset(d,d$TEST)
      out1(id,d1,FALSE)
      if (TRUE) {
          cd<-rn_savenm("nmWBS","GRAPH",rfsr1,rffn1,"","pdf")
          pdf(cd,onefile=FALSE)
          par(mar=c(3.5,2.5,.5,.5),oma=c(0+rn_ma1,1.5,.1,.1))
          out1(id,d1,TRUE)
          rn_titles(rfsr1,rffn1,1,1)   
          dev.off()
      }
      if (length(id)==1) {
         repeat { 
         infx <- readline(paste("\nDelete x values < min (value/n) ? [n] "))
         if (infx == "") infx<-"n"
         if (infx != "n") infx<-as.numeric(infx)
         supx <- readline(paste("Delete x values > max (value/n) ? [n] "))
         if (supx == "") supx<-"n"
         if (supx != "n") supx<-as.numeric(supx)
         if ((infx=="n") & (supx=="n")) break
         out1(id,d1) 
         }
      }
      d$Min<-sdm
      rm(sdm)  
      d<-subset(d,select=c(-TEST))
    }#repeat
    par(mar=c(4.1,3.1,3.1,1.1),oma=c(0,0,0,0))
    return(list(irfids,rfizs,rftr1))
}

rps<-fp1(rfids,rfizs,rftr1)
rfids<-rps[[1]];rfizs<-rps[[2]];rftr1<-rps[[3]]

rm(fp1,rps)
rm(flagNM,flagCUSTOM)

