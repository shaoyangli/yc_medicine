USE [ProjectYJK]
GO

/****** Object:  Table [dbo].[INRUD_Use_method]    Script Date: 04/16/2015 12:06:02 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[INRUD_Use_method](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[num] [nvarchar](20) NULL,
	[method] [nvarchar](20) NULL,
	[frequency] [nvarchar](20) NULL,
	[use_antibio] [nvarchar](20) NULL,
	[useCsAdate] [nvarchar](20) NULL,
	[Tg] [nvarchar](20) NULL,
	[redcell] [nvarchar](20) NULL,
	[usemedDate] [nvarchar](20) NULL,
	[usemedTime] [nvarchar](20) NULL,
	[dose] [nvarchar](20) NULL,
	[Last_con] [nvarchar](20) NULL,
	[Pre_con] [nvarchar](20) NULL,
	[RBC] [nvarchar](20) NULL,
	[TBIL] [nvarchar](20) NULL,
	[ALT] [nvarchar](20) NULL,
	[AST] [nvarchar](20) NULL,
	[DrugType] [nvarchar](50) NULL,
	[User_Group] [nvarchar](50) NULL
) ON [PRIMARY]

GO


