using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Diagnostics;
using System.IO;
using System.Text.RegularExpressions;
using WebUI;
namespace YJKManage.Web.TDM
{
    public partial class CsAcount : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string account = SessionState.Account;
            TextBox2.Text = account;
            TextBox2.Text = "sdfyy";
        }


        protected void Count()
        {
            //��dos����·��
            Process p = new Process();
            p.StartInfo.FileName = "cmd.exe";
            //p.StartInfo.Arguments = "/k c:\\nm6.g77\\wfn614\\bin\\wfn.bat";
            p.StartInfo.Arguments = "/k D:\\sdfyy.cn\\aspx\\yjk\\YjkWeb3\\nm6.g77\\wfn614\\bin\\wfn.bat";
            p.StartInfo.UseShellExecute = false;
            p.StartInfo.RedirectStandardInput = true;
            p.StartInfo.RedirectStandardOutput = true;
            p.StartInfo.CreateNoWindow = true;
            p.Start();
            //string dir = "cd C:\\nm6.g77\\YCCsA";
            //p.StandardInput.WriteLine("C:");

            //���ݵ�¼ҽԺ�ҵ���ӦĿ¼�µĳ���
            p.StandardInput.WriteLine("D:");
            string dir = "cd D:\\sdfyy.cn\\aspx\\yjk\\YjkWeb3\\nm6.g77\\" + TextBox2.Text + "\\YCCsA";
            p.StandardInput.WriteLine(dir);
            p.StandardInput.WriteLine("nmgo yccsa.ctl");
            p.StandardInput.WriteLine("exit");
            string output = p.StandardOutput.ReadToEnd();
            
            //p.WaitForExit(600000);
            //�鿴һ��������ݣ���¼���ü������
            TextBox1.Text = output;
            int t=int.Parse(count_times.Text)+1;
            count_times.Text = t.ToString();
            
        }


        protected void Write_file()
        {
           
            //д���ļ�
            //string dir = "C:/nm6.g77/YCCsA/YCCsA.csv";
            string dir = "D:/sdfyy.cn/aspx/yjk/YjkWeb3/nm6.g77/" + TextBox2.Text + "/YCCsA/YCCsA.csv";
            StreamWriter sw = new StreamWriter((dir), false, System.Text.Encoding.Default);
            try
            {
                sw.Write(TextBox1.Text);
                sw.Close();
                Response.Write("<b>�ļ�д��ɹ���</b>");
                Label17.Text = dir;
            }
            catch
            {
                Response.Write("<b>�ļ�д��ʧ�ܣ�</b>");
            }
        }

        protected void Read_File()
        {
            //��ȡ������

            //string dir = "C:/nm6.g77/YCCsA/YCCsA.g77/yccsa.fit";
            string dir = "D:/sdfyy.cn/aspx/yjk/YjkWeb3/nm6.g77/" + TextBox2.Text + "/YCCsA/YCCsA.g77/yccsa.fit";
            StreamReader sr = new StreamReader((dir),System.Text.Encoding.Default);
            try
            {
                string input;
                while ((input=sr.ReadLine()) != null)
                {
                    input = input.Replace("<br>", "\r\n");
                    TextBox1.Text = input;  //��ȡ���һ��
                }
                
                sr.Close();
                string str = TextBox1.Text;
                string[] sArray = Regex.Split(str, "  ", RegexOptions.IgnoreCase);//����ȡ���������ݰ��ո�ֿ����ֱ��������
                foreach (string i in sArray);                
                str = sArray[6];  //ȡ�����ֵ
                string[] s2 = Regex.Split(str, "E+", RegexOptions.IgnoreCase);//�ֱ��ȡ���ֵ���ݴη�ֵ
                foreach (string i in sArray) ;
                double pre_result = float.Parse(s2[0]) * Math.Pow(10,double.Parse(s2[1]));//��������ֵ
                txt_preCon.Text = pre_result.ToString().Substring(0,6);
                if (Record.Text == "1" && float.Parse(txt_preCon.Text) < float.Parse(txt_expHighCon.Text))
                {
                    result.Text = result.Text + "\r\n" + txt_dose.Text + ":" + txt_preCon.Text;
                }
                Response.Write("<b>�ļ���ȡ�ɹ�!</b>");
                Label17.Text = dir;
            }
            catch
            {
                Response.Write("<b>�ļ���ȡʧ��!</b>");
                Label17.Text = dir;
            }
        }

        protected void Get_Para()
        {
            string CMT, RATE, DV, WT, HCT, ATF, DT, TG, MDV, MDV2;
            //��ȡ�������
                if (CheckData())
                {
                    string dat1 = txt_usemedDate.Text;
                    string t = txt_usemedTime.Text;
                    string AMT = txt_dose.Text;
                    if (dw_method.Text == "�ڷ�")
                    {
                        CMT = "1";
                    }
                    else
                    {
                        CMT = "2";
                    }
                    if (dw_frequency.Text == "24H��ע")
                    {
                        float ra = (float.Parse(txt_dose.Text) / 24);//��Ϊ24Сʱ��ע����rateֵΪ��ҩ������24
                        RATE = ra.ToString();
                    }
                    else
                    {
                        RATE = "";
                    }
                    if (dw_Tg.Text == "<2.3")
                    {
                        TG = "0";
                    }
                    else
                    {
                        TG = "1";
                    }


                    WT = txt_Whight.Text;
                    HCT = txt_redcell.Text;
                    if (dw_use_antibio.Text == "ʹ��")
                    {
                        ATF = "1";
                    }
                    else
                    {
                        ATF = "0";
                    }
                    if (dw_useCsAdate.Text == ">30")
                    {
                        DT = "1";
                    }
                    else
                    {
                        DT = "0";
                    }
                    MDV = "1";
                    DV = txt_Con.Text;


                    TextBox1.Text = "#ID,DAT2,TIME,AMT,CMT,RATE,DV,MDV,WT,HCT,ATF,DT,TG";
                    if (dw_frequency.Text == "Q12H")  //��ΪQ12H��ҩ����ÿ����д��������ҩ��Ϣ����9��00��21��00
                    {
                        Regex r = new Regex(@"(\d+)");
                        Match m = r.Match(txt_usemedTime.Text);//ȡ��ҩʱ������ֵ
                        int tt = int.Parse(m.ToString()) + 12;
                        string t2 = tt.ToString() + txt_usemedTime.Text.Substring((m.Length), 3);
                        string t3 = txt_bloodTime.Text;
                        string dat2 = txt_usemedDate.Text;
                        string dat3 = txt_bloodDate.Text;
                        TimeSpan dt = DateTime.Parse(dat3) - DateTime.Parse(dat2);//������ҩ����
                        string L = dt.Days.ToString();
                        //׼��д����Ϣ
                        for (int i = 1; i <= int.Parse(L); i++)
                        {
                            TextBox1.Text = TextBox1.Text + "\r\n" + "1," + dat2 + "," + t + "," + AMT + "," + CMT + "," + RATE + ",," + MDV + "," + WT + "," + HCT + "," + ATF + "," + DT + "," + TG;
                            TextBox1.Text = TextBox1.Text + "\r\n" + "1," + dat2 + "," + t2 + "," + AMT + "," + CMT + "," + RATE + ",," + MDV + "," + WT + "," + HCT + "," + ATF + "," + DT + "," + TG;
                            dat2 = DateTime.Parse(dat2).AddDays(1).ToShortDateString();
                        }

                        if (txt_Con.Text == "")
                        {
                            MDV2 = "1";
                        }
                        else
                        {
                            MDV2 = "0";
                        }
                        if (DateTime.Compare(DateTime.Parse(t3), DateTime.Parse(t)) <= 0)//�жϳ�Ѫʱ����ڸ�ҩʱ����ǰ��
                        {
                            TextBox1.Text = TextBox1.Text + "\r\n" + "1," + dat3 + "," + t3 + ",,2,," + DV + "," + MDV2 + "," + WT + "," + HCT + "," + ATF + "," + DT + "," + TG + "\r\n";
                        }
                        else
                        {
                            TextBox1.Text = TextBox1.Text + "\r\n" + "1," + dat3 + "," + t + "," + AMT + "," + CMT + "," + RATE + ",," + MDV + "," + WT + "," + HCT + "," + ATF + "," + DT + "," + TG;
                            TextBox1.Text = TextBox1.Text + "\r\n" + "1," + dat3 + "," + t3 + ",,2,," + DV + "," + MDV2 + "," + WT + "," + HCT + "," + ATF + "," + DT + "," + TG + "\r\n";
                        }
                    }
                    else if (dw_frequency.Text == "24H��ע" || dw_frequency.Text == "QD")
                    {
                        string t3 = txt_bloodTime.Text;
                        string dat2 = txt_usemedDate.Text;
                        string dat3 = txt_bloodDate.Text;
                        TimeSpan dt = DateTime.Parse(dat3) - DateTime.Parse(dat2);
                        string L = dt.Days.ToString();
                        for (int i = 1; i <= int.Parse(L); i++)
                        {
                            TextBox1.Text = TextBox1.Text + "\r\n" + "1," + dat2 + "," + t + "," + AMT + "," + CMT + "," + RATE + ",," + MDV + "," + WT + "," + HCT + "," + ATF + "," + DT + "," + TG;
                            dat2 = DateTime.Parse(dat2).AddDays(1).ToShortDateString();
                        }

                        if (txt_Con.Text == "")
                        {
                            MDV2 = "1";
                        }
                        else
                        {
                            MDV2 = "0";
                        }
                        if (DateTime.Compare(DateTime.Parse(t3), DateTime.Parse(t)) <= 0)
                        {
                            TextBox1.Text = TextBox1.Text + "\r\n" + "1," + dat3 + "," + t3 + ",,2,," + DV + "," + MDV2 + "," + WT + "," + HCT + "," + ATF + "," + DT + "," + TG + "\r\n";
                        }
                        else
                        {
                            TextBox1.Text = TextBox1.Text + "\r\n" + "1," + dat3 + "," + t + "," + AMT + "," + CMT + "," + RATE + ",," + MDV + "," + WT + "," + HCT + "," + ATF + "," + DT + "," + TG;
                            TextBox1.Text = TextBox1.Text + "\r\n" + "1," + dat3 + "," + t3 + ",,2,," + DV + "," + MDV2 + "," + WT + "," + HCT + "," + ATF + "," + DT + "," + TG + "\r\n";
                        }
                    }

                }

            
        }

        private bool CheckData()
        {
            if (dw_method.Text == "��ѡ��")
            {
                return false;
            }

            if(dw_frequency.Text == "��ѡ��")
            {
                return false;
            }

            if(dw_use_antibio.Text == "��ѡ��")
            {
                return false;
            }

            if(dw_useCsAdate.Text == "��ѡ��")
            {
                return false;
            }
            if(dw_Tg.Text == "��ѡ��")
            {
                return false;
            }
            if(txt_redcell.Text == "")
            {
                return false;
            }
            if(txt_usemedDate.Text == "")
            {
                return false;
            }
            if(txt_usemedTime.Text == "")
            {
                return false;
            }
            if(txt_dose.Text == "")
            {
                return false;
            }
            if(txt_interval.Text == "")
            {
                return false;
            }
            if(txt_bloodDate.Text == "")
            {
                return false;
            }
            if(txt_bloodTime.Text == "")
            {
                return false;
            }
            if(txt_expLowCon.Text =="")
            {
                return false;
            }
            if(txt_expHighCon.Text == "")
            {
                return false;
            }
            return true;
        }

        protected void Count_min()//������Сֵ
        {
            
            if (float.Parse(txt_preCon.Text) <= float.Parse(txt_expLowCon.Text))//���Ԥ��ֵС����С����ֵ������ԭ��ҩ��������������һ���������������������
            {
                int new_dose=int.Parse(txt_dose.Text) + int.Parse(txt_interval.Text);
                txt_dose.Text =new_dose.ToString();
                key.Text = "1";//״̬��¼��״̬1����ҩԤ��ֵ������С������
            }
            else if (float.Parse(txt_preCon.Text) > float.Parse(txt_expLowCon.Text))//���Ԥ��ֵ������С����ֵ
            {
                if (key.Text  == "1")//�����״̬1�����ģ���˸�ҩ����Ϊ��С��ҩ��
                {
                    txt_MinDose.Text = txt_dose.Text;
                    key.Text = "0";
                    Response.Write("�������С��ҩ��");
                    result.Text = txt_MinDose.Text + ":" + txt_preCon.Text;
                    Record.Text = "1";
                    key.Text = "2"; //״̬��¼��״̬2���ø�ҩ������������ֵ��Χ֮��
                    int new_dose = int.Parse(txt_dose.Text) + int.Parse(txt_interval.Text);
                    txt_dose.Text = new_dose.ToString();
                }
                else//���Ԥ��ֵ������С����ֵ
                {
                    int new_dose = int.Parse(txt_dose.Text) - int.Parse(txt_interval.Text);
                    txt_dose.Text = new_dose.ToString();
                    key.Text = "2";                   
                }            
            }
        }

        protected void Count_max()//��������ҩ��
        {
            if (float.Parse(txt_preCon.Text) > float.Parse(txt_expHighCon.Text))
            {
                int new_dose = int.Parse(txt_dose.Text) - int.Parse(txt_interval.Text);
                txt_MaxDose.Text = new_dose.ToString();
                Response.Write("���������ҩ��");
                key.Text = "0";
                Record.Text = "0";
            }
            else 
            {
 
                    int new_dose = int.Parse(txt_dose.Text) + int.Parse(txt_interval.Text);
                    txt_dose.Text = new_dose.ToString();
                    key.Text = "2";

            }
        }

        protected void Get_Data(object sender, EventArgs e)
        {
            while (txt_MaxDose.Text == "")
            {
                Get_Para();
                Write_file();
                Count();
                Read_File();
                if (txt_preCon.Text != "")
                {
                    if (txt_MinDose.Text != "")
                    {
                        Count_max();
                    }
                    else
                    {
                        Count_min();
                    }
                }
            }
        }

        protected void Pre_Data(object sender, EventArgs e)
        {
          
                Get_Para();
                Write_file();
                Count();
                Read_File();

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Get_Para();
            Write_file();
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Count();
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Read_File();
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            Get_Para();
        }

 


    }
}
